import SwiftUI

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var license = LicenseManager()
    @StateObject private var appAccess = AppAccessManager()

    var body: some View {
        ZStack {
            if appAccess.canUseApp {
                if license.isUnlocked {
                    CustomLayoutView()
                        .environmentObject(license)
                        .transition(.opacity)
                } else {
                    LicenseGateView()
                        .environmentObject(license)
                        .transition(.opacity)
                }
            } else {
                AppAccessGateView(state: appAccess.state) {
                    await appAccess.refresh()
                }
                .transition(.opacity)
            }

            if appAccess.canUseApp, let info = license.celebration {
                LicenseUnlockCelebration(info: info)
                    .transition(.opacity)
                    .zIndex(3)
            }
        }
        .animation(.easeInOut(duration: 0.35), value: appAccess.state)
        .animation(.easeInOut(duration: 0.4), value: license.isUnlocked)
        .preferredColorScheme(.dark)
        .task { await appAccess.startIfNeeded() }
        .task { await appAccess.monitor() }
        .task(id: appAccess.canUseApp) {
            guard appAccess.canUseApp else { return }
            await license.startIfNeeded()
            await license.monitor()
        }
        .onChange(of: scenePhase) { _, phase in
            guard phase == .active else { return }
            Task {
                await appAccess.refresh()
                guard appAccess.canUseApp else { return }
                await license.handleForeground()
            }
        }
    }
}
