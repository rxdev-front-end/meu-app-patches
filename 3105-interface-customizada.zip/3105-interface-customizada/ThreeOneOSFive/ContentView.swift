import SwiftUI

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var license = LicenseManager()

    var body: some View {
        ZStack {
            if license.isUnlocked {
                CustomLayoutView()
                    .environmentObject(license)
                    .transition(.opacity)
            } else {
                LicenseGateView()
                    .environmentObject(license)
                    .transition(.opacity)
            }

            if let info = license.celebration {
                LicenseUnlockCelebration(info: info)
                    .transition(.opacity)
                    .zIndex(3)
            }
        }
        .animation(.easeInOut(duration: 0.4), value: license.isUnlocked)
        .preferredColorScheme(.dark)
        .task { await license.startIfNeeded() }
        .task { await license.monitor() }
        .onChange(of: scenePhase) { _, phase in
            guard phase == .active else { return }
            Task { await license.handleForeground() }
        }
    }
}
