import SwiftUI
import UniformTypeIdentifiers

struct CustomLayoutView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var patchStore: PatchProjectStore
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator

    @State private var isImporting = false
    @State private var toggleOverrides: [UUID: Bool] = [:]
    @State private var workingIDs = Set<UUID>()

    private let navy = Color(red: 0.015, green: 0.035, blue: 0.105)
    private let blue = Color(red: 0.20, green: 0.52, blue: 0.98)

    var body: some View {
        TabView {
            patchesPage
                .tabItem {
                    Label("Sexy Store", systemImage: "square.stack.3d.up.fill")
                }
        }
        .tint(blue)
        .preferredColorScheme(.dark)
        .fileImporter(
            isPresented: $isImporting,
            allowedContentTypes: [.data],
            allowsMultipleSelection: false,
            onCompletion: handleImport
        )
        .patchStorePresentation(patchStore)
        .alert(item: $patchStore.alert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text("OK"))
            )
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { _ in
            guard let request = patchDraftCoordinator.importRequest else { return }
            patchStore.importPackage(from: request.source)
            patchDraftCoordinator.clearImport()
        }
        .onChange(of: patchStore.items.map(\.id)) { _ in
            toggleOverrides = toggleOverrides.filter { id, _ in
                patchStore.items.contains(where: { $0.id == id })
            }
        }
    }

    private var patchesPage: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.025, green: 0.075, blue: 0.19), navy, Color.black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                header

                if patchStore.items.isEmpty {
                    emptyState
                } else {
                    ScrollView(showsIndicators: false) {
                        LazyVStack(spacing: 12) {
                            ForEach(patchStore.items) { item in
                                patchRow(item)
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 18)
                        .padding(.bottom, 24)
                    }
                }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    private var header: some View {
        HStack(alignment: .center) {
            Text("Sexy Store")
                .font(.system(size: 32, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .accessibilityAddTraits(.isHeader)

            Spacer()

            Button {
                isImporting = true
            } label: {
                Image(systemName: "plus")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 46, height: 46)
                    .background(.ultraThinMaterial, in: Circle())
                    .overlay(Circle().strokeBorder(.white.opacity(0.14), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Importar patch")
        }
        .padding(.horizontal, 22)
        .padding(.top, 12)
        .padding(.bottom, 12)
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Spacer()
            Image(systemName: "square.stack.3d.up")
                .font(.system(size: 42, weight: .light))
                .foregroundStyle(blue.opacity(0.9))
                .symbolRenderingMode(.hierarchical)
            Text("Nenhum patch importado")
                .font(.system(size: 17, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.75))
            Spacer()
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .accessibilityElement(children: .combine)
    }

    private func patchRow(_ item: PatchLibraryItem) -> some View {
        HStack(spacing: 14) {
            Text(item.project?.name ?? item.packageURL.deletingPathExtension().lastPathComponent)
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(2)
                .multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity, alignment: .leading)

            Toggle(
                item.project?.name ?? item.packageURL.lastPathComponent,
                isOn: Binding(
                    get: { toggleOverrides[item.id] ?? isApplied(item) },
                    set: { setEnabled($0, for: item) }
                )
            )
            .labelsHidden()
            .tint(blue)
            .disabled(item.project == nil || workingIDs.contains(item.id) || patchStore.isBusy)
            .accessibilityLabel(item.project?.name ?? item.packageURL.lastPathComponent)
        }
        .padding(.horizontal, 17)
        .padding(.vertical, 15)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .strokeBorder(.white.opacity(0.09), lineWidth: 1)
        }
        .shadow(color: .black.opacity(0.18), radius: 14, y: 7)
    }

    private func handleImport(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            guard let url = urls.first else { return }
            patchStore.importPackage(at: url)
        case .failure(let error):
            let cocoaError = error as NSError
            guard !(error is CancellationError), cocoaError.code != 3072 else { return }
            patchStore.presentImportError(.unsupportedFormat)
        }
    }

    private func isApplied(_ item: PatchLibraryItem) -> Bool {
        DevicePatchService.latestReceipt(projectID: item.id) != nil
    }

    private func setEnabled(_ enabled: Bool, for item: PatchLibraryItem) {
        guard !workingIDs.contains(item.id), !patchStore.isBusy else { return }
        toggleOverrides[item.id] = enabled
        workingIDs.insert(item.id)

        Task.detached(priority: .userInitiated) {
            do {
                if enabled {
                    guard let baseProject = item.project else {
                        throw PatchPackageError.invalidProject
                    }
                    let project = item.summary.schemaVersion >= 2 && item.canInspectContents
                        ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                        : baseProject
                    _ = try DevicePatchService.apply(project: project)
                } else if let receipt = DevicePatchService.latestReceipt(projectID: item.id) {
                    try DevicePatchService.restore(receipt: receipt)
                }
                await MainActor.run {
                    patchStore.reload()
                    toggleOverrides[item.id] = nil
                    workingIDs.remove(item.id)
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    toggleOverrides[item.id] = nil
                    workingIDs.remove(item.id)
                    patchStore.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    toggleOverrides[item.id] = nil
                    workingIDs.remove(item.id)
                    patchStore.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: enabled ? "patch.error.apply" : "patch.error.restore"
                    )
                }
            }
        }
    }
}
