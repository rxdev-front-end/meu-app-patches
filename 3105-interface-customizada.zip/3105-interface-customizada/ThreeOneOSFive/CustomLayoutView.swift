import SwiftUI

struct CustomLayoutView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var patchStore: PatchProjectStore
    @StateObject private var luccheseAPI = LuccheseAPI()

    @State private var toggleOverrides: [UUID: Bool] = [:]
    @State private var workingIDs = Set<UUID>()
    @State private var toggleConfirmation: PendingToggleConfirmation?
    @State private var injectionState: InjectionState?
    @State private var isLaunching = true
    @State private var backgroundShift = false

    private let navy = Color(red: 0.008, green: 0.018, blue: 0.065)
    private let blue = Color(red: 0.12, green: 0.40, blue: 1.0)

    var body: some View {
        TabView {
            patchesPage
                .tabItem { Label("Patches", systemImage: "square.stack.3d.up.fill") }
            tutorialPage
                .tabItem { Label("Tutorial", systemImage: "book.closed.fill") }
            announcementsPage
                .tabItem { Label("Avisos", systemImage: "bell.fill") }
        }
        .tint(blue)
        .preferredColorScheme(.dark)
        .patchStorePresentation(patchStore)
        .alert(item: Binding(
            get: {
                guard patchStore.alert?.messageKey == "patch.imported_message",
                      luccheseAPI.automaticImportPackageID != nil else { return patchStore.alert }
                return nil
            },
            set: { patchStore.alert = $0 }
        )) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(LuccheseActivationBlock(rawValue: alert.messageKey)?.message ?? alert.message(language: language)),
                dismissButton: .default(Text("OK"))
            )
        }
        .onChange(of: patchStore.alert?.id) { _, _ in
            handleAutomaticImportAlertChange()
        }
        .onChange(of: patchStore.passwordRequest?.summary.packageID) { _, _ in
            handlePasswordRequestChange()
        }
        .onChange(of: scenePhase) { _, phase in
            handleScenePhaseChange(phase)
        }
        .task {
            await runSynchronizationLoop()
        }
        .overlay {
            if let injectionState {
                InjectionOverlay(state: injectionState)
                    .transition(.opacity)
                    .zIndex(2)
            }
        }
        .overlay {
            if isLaunching {
                StoreLaunchOverlay()
                    .transition(.opacity)
                    .zIndex(3)
            }
        }
        .alert(item: $toggleConfirmation) { confirmation in
            if confirmation.isBlocked {
                return Alert(
                    title: Text("Um patch por vez"),
                    message: Text("Desative e restaure o patch ativo antes de ativar outro."),
                    dismissButton: .default(Text("OK"))
                )
            }
            if confirmation.isEnabling {
                let textoAlerta = "Deseja aplicar “\(confirmation.displayName)” agora?"
                return Alert(
                    title: Text("Aplicar patch?"),
                    message: Text(textoAlerta),
                    primaryButton: .default(Text("Aplicar")) {
                        setEnabled(true, for: confirmation.item, remoteID: confirmation.remoteID, name: confirmation.displayName)
                    },
                    secondaryButton: .cancel(Text("Cancelar"))
                )
            }
            let textoRestaurar = "Deseja restaurar os arquivos e desativar “" + confirmation.displayName + "”?"
            return Alert(
                title: Text("Restaurar patch?"),
                message: Text(textoRestaurar),
                primaryButton: .destructive(Text("Restore")) {
                    setEnabled(false, for: confirmation.item, remoteID: confirmation.remoteID, name: confirmation.displayName)
                },
                secondaryButton: .cancel(Text("Cancelar"))
            )
        }
    }

    private var patchesPage: some View {
        ZStack {
            background
            VStack(spacing: 0) {
                header
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 18) {
                        collectionHeading
                        if luccheseAPI.catalog.isEmpty {
                            emptyCatalogState
                        } else {
                            LazyVStack(spacing: 12) {
                                ForEach(luccheseAPI.catalog) { remote in
                                    remotePatchRow(remote)
                                        .transition(.opacity.combined(with: .move(edge: .top)))
                                }
                            }
                            .animation(.spring(response: 0.38, dampingFraction: 0.86), value: luccheseAPI.catalog.map(\.id))
                        }
                        if !orphanedAppliedItems.isEmpty {
                            VStack(alignment: .leading, spacing: 10) {
                                Text("Restauração pendente")
                                    .font(.system(size: 11, weight: .bold, design: .rounded))
                                    .tracking(1.4)
                                    .foregroundStyle(.orange.opacity(0.9))
                                ForEach(orphanedAppliedItems) { item in
                                    orphanedPatchRow(item)
                                        .transition(.opacity.combined(with: .move(edge: .top)))
                                }
                            }
                        }
                        developerSignature
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 16)
                    .padding(.bottom, 28)
                }
                .refreshable { await refreshFromAPI() }
            }
        }
        .onAppear {
            backgroundShift = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                withAnimation(.easeOut(duration: 0.45)) { isLaunching = false }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    private var announcementsPage: some View {
        ZStack {
            background
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 14) {
                    HStack(alignment: .center) {
                        Text("Avisos")
                            .font(.system(size: 27, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                        Spacer()
                        Button {
                            Task { await refreshFromAPI() }
                        } label: {
                            Image(systemName: "arrow.clockwise")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundStyle(.white)
                                .frame(width: 42, height: 42)
                                .background(.ultraThinMaterial, in: Circle())
                        }
                        .accessibilityLabel("Atualizar avisos")
                    }
                    .padding(.top, 20)

                    HStack {
                        Text(LuccheseDeviceInfo.description)
                        Spacer(minLength: 8)
                        Text(syncStatusText)
                    }
                    .font(.system(size: 10, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.58))

                    if !LuccheseAPI.isIOSSupported {
                        Text("Versão do iOS não suportada")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.orange)
                    }

                    if luccheseAPI.announcements.isEmpty {
                        VStack(spacing: 10) {
                            Image(systemName: "bell.badge")
                                .font(.system(size: 28, weight: .light))
                                .foregroundStyle(blue)
                            Text(luccheseAPI.errorMessage ?? "Nenhum aviso disponível.")
                                .font(.system(size: 14, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.70))
                                .multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 38)
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                    } else {
                        ForEach(luccheseAPI.announcements) { announcement in
                            VStack(alignment: .leading, spacing: 8) {
                                Text(announcement.title)
                                    .font(.system(size: 16, weight: .semibold, design: .rounded))
                                    .foregroundStyle(.white)
                                Text(announcement.message)
                                    .font(.system(size: 14, weight: .regular, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.80))
                                    .fixedSize(horizontal: false, vertical: true)
                                Text(formattedAnnouncementDate(announcement.createdAt))
                                    .font(.system(size: 10, weight: .medium, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.42))
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(16)
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(.white.opacity(0.09), lineWidth: 1))
                        }
                    }
                    developerSignature
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 28)
            }
            .refreshable { await refreshFromAPI() }
        }
        .onAppear { Task { await refreshFromAPI() } }
        .toolbar(.hidden, for: .navigationBar)
    }

    private var tutorialPage: some View {
        ZStack {
            background
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 22) {
                    HStack(spacing: 14) {
                        Image(systemName: "book.closed.fill")
                            .font(.system(size: 21, weight: .semibold))
                            .foregroundStyle(.white)
                            .frame(width: 50, height: 50)
                            .background(blue.opacity(0.8), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                            .shadow(color: blue.opacity(0.32), radius: 18, y: 7)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Tutorial")
                                .font(.system(size: 27, weight: .bold, design: .rounded))
                                .foregroundStyle(.white)
                            Text("LUCCHESE STORE")
                                .font(.system(size: 10, weight: .bold, design: .rounded))
                                .tracking(2.3)
                                .foregroundStyle(Color(red: 0.58, green: 0.76, blue: 1.0))
                        }
                    }
                    .padding(.top, 20)

                    VStack(alignment: .leading, spacing: 18) {
                        Text("COMO USAR")
                            .font(.system(size: 11, weight: .bold, design: .rounded))
                            .tracking(2.2)
                            .foregroundStyle(.white.opacity(0.5))
                        tutorialStep(number: "01", text: "Entre no Free Fire e aguarde o carregamento até 40%.", symbol: "gamecontroller.fill")
                        tutorialStep(number: "02", text: "Volte ao aplicativo e ative o patch desejado.", symbol: "switch.2")
                        tutorialStep(number: "03", text: "Retorne ao jogo e, quando chegar ao lobby, desative o patch.", symbol: "arrow.uturn.backward")
                    }
                    .padding(20)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).strokeBorder(.white.opacity(0.09), lineWidth: 1))

                    HStack(alignment: .top, spacing: 13) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.system(size: 19, weight: .semibold))
                            .foregroundStyle(Color(red: 1.0, green: 0.72, blue: 0.28))
                        Text("Usar de forma indevida pode ocasionar banimentos.")
                            .font(.system(size: 14, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.88))
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(17)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.orange.opacity(0.10), in: RoundedRectangle(cornerRadius: 19, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 19, style: .continuous).strokeBorder(Color.orange.opacity(0.20), lineWidth: 1))

                    developerSignature
                        .padding(.top, 4)
                        .padding(.bottom, 24)
                }
                .padding(.horizontal, 20)
            }
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    private var header: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle().fill(.ultraThinMaterial)
                    .overlay(Circle().strokeBorder(.white.opacity(0.14), lineWidth: 1))
                Circle().fill(LinearGradient(colors: [blue.opacity(0.34), blue.opacity(0.08)], startPoint: .topLeading, endPoint: .bottomTrailing))
                Image(systemName: "person.fill")
                    .font(.system(size: 24, weight: .medium))
                    .foregroundStyle(.white)
            }
            .frame(width: 54, height: 54)
            .shadow(color: blue.opacity(0.18), radius: 16, y: 7)

            VStack(alignment: .leading, spacing: 4) {
                Text("Patches")
                    .font(.system(size: 27, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .accessibilityAddTraits(.isHeader)
                Text("LUCCHESE STORE")
                    .font(.system(size: 11, weight: .bold, design: .rounded))
                    .tracking(3.1)
                    .foregroundStyle(Color(red: 0.50, green: 0.70, blue: 1.0))
                Text(LuccheseDeviceInfo.description)
                    .font(.system(size: 9, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55))
            }

            Spacer(minLength: 4)
            Button {
                Task { await refreshFromAPI() }
            } label: {
                Group {
                    if luccheseAPI.isRefreshing || luccheseAPI.isSynchronizing || patchStore.isBusy {
                        ProgressView().tint(.white)
                    } else {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundStyle(.white)
                    }
                }
                .frame(width: 46, height: 46)
                .background(.ultraThinMaterial, in: Circle())
                .overlay(Circle().strokeBorder(.white.opacity(0.14), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .disabled(luccheseAPI.isRefreshing || luccheseAPI.isSynchronizing || patchStore.isBusy)
            .accessibilityLabel("Atualizar patches e avisos")
        }
        .padding(.horizontal, 22)
        .padding(.top, 12)
        .padding(.bottom, 15)
    }

    private var collectionHeading: some View {
        HStack(alignment: .center, spacing: 8) {
            VStack(alignment: .leading, spacing: 4) {
                Text("CATÁLOGO DA LUCCHESE STORE")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(.white.opacity(0.48))
                Text(patchCountText)
                    .font(.system(size: 15, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.86))
            }
            Spacer(minLength: 0)
            HStack(spacing: 6) {
                Image(systemName: LuccheseAPI.isIOSSupported ? "checkmark.seal.fill" : "xmark.seal.fill")
                Text(LuccheseAPI.isIOSSupported ? "iOS compatível" : "iOS incompatível")
            }
            .font(.system(size: 10, weight: .semibold, design: .rounded))
            .foregroundStyle(LuccheseAPI.isIOSSupported ? Color.green : Color.orange)
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .background((LuccheseAPI.isIOSSupported ? Color.green : Color.orange).opacity(0.11), in: Capsule())
        }
        .padding(.horizontal, 2)
    }

    private var patchCountText: String {
        let count = luccheseAPI.catalog.count
        if count == 0 { return "Nenhum patch publicado" }
        return count == 1 ? "1 patch publicado" : "\(count) patches publicados"
    }

    private var syncStatusText: String {
        if luccheseAPI.isRefreshing || luccheseAPI.isSynchronizing { return "Sincronizando…" }
        if luccheseAPI.networkAvailable { return "Catálogo atualizado" }
        return luccheseAPI.errorMessage ?? "API indisponível"
    }

    private func formattedAnnouncementDate(_ value: String) -> String {
        let fractionalFormatter = ISO8601DateFormatter()
        fractionalFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let date = fractionalFormatter.date(from: value) ?? ISO8601DateFormatter().date(from: value)
        return date?.formatted(date: .abbreviated, time: .shortened) ?? value
    }

    private var emptyCatalogState: some View {
        VStack(spacing: 13) {
            Image(systemName: luccheseAPI.isRefreshing ? "arrow.triangle.2.circlepath" : "square.stack.3d.up")
                .font(.system(size: 32, weight: .light))
                .foregroundStyle(blue.opacity(0.95))
                .symbolRenderingMode(.hierarchical)
                .frame(width: 70, height: 70)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 23, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 23, style: .continuous).strokeBorder(.white.opacity(0.09), lineWidth: 1))
            Text(luccheseAPI.errorMessage ?? "Nenhum patch publicado ainda")
                .font(.system(size: 17, weight: .semibold, design: .rounded))
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)
            Text("Os patches enviados pelo painel aparecerão aqui automaticamente.")
                .font(.system(size: 13, weight: .regular, design: .rounded))
                .foregroundStyle(.white.opacity(0.58))
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 22)
        .padding(.vertical, 36)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).strokeBorder(.white.opacity(0.09), lineWidth: 1))
    }

    private func remotePatchRow(_ remote: LuccheseRemotePatch) -> some View {
        let item = localItem(for: remote)
        return HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: "square.stack.3d.up.fill")
                        .font(.system(size: 17, weight: .medium))
                        .foregroundStyle(Color(red: 0.58, green: 0.76, blue: 1.0))
                        .frame(width: 42, height: 42)
                        .background(LinearGradient(colors: [blue.opacity(0.28), blue.opacity(0.10)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    VStack(alignment: .leading, spacing: 5) {
                        Text(remote.name)
                            .font(.system(size: 15, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(2)
                        HStack(spacing: 7) {
                            statusBadge(remote.status)
                            riskBadge(remote.risk)
                        }
                        if let note = remote.note, !note.isEmpty {
                            Text(note)
                                .font(.system(size: 11, weight: .regular, design: .rounded))
                                .foregroundStyle(.white.opacity(0.58))
                                .lineLimit(3)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        if item == nil {
                            Text(remote.status == .ativo ? "Sincronizando pacote…" : "Disponível quando o painel ativar este patch")
                                .font(.system(size: 10, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.43))
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            Spacer(minLength: 0)
            if let item {
                Toggle(
                    remote.name,
                    isOn: Binding(
                        get: { toggleOverrides[item.id] ?? isApplied(item) },
                        set: { requestToggle($0, for: item, remoteID: remote.id, name: remote.name) }
                    )
                )
                .labelsHidden()
                .tint(blue)
                .disabled(
                    item.project == nil || !workingIDs.isEmpty || patchStore.isBusy ||
                        (!isApplied(item) && (remote.status != .ativo || !luccheseAPI.networkAvailable))
                )
                .accessibilityLabel(remote.name)
            } else {
                Toggle(remote.name, isOn: .constant(false))
                    .labelsHidden()
                    .tint(blue)
                    .disabled(true)
                    .accessibilityLabel("\(remote.name), ainda não sincronizado")
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 13)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 21, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 21, style: .continuous).strokeBorder(.white.opacity(0.085), lineWidth: 1))
        .shadow(color: blue.opacity(0.06), radius: 18, y: 8)
    }

    private func orphanedPatchRow(_ item: PatchLibraryItem) -> some View {
        HStack(spacing: 12) {
            Image(systemName: "arrow.uturn.backward.circle.fill")
                .font(.system(size: 20, weight: .medium))
                .foregroundStyle(.orange.opacity(0.92))
                .frame(width: 44, height: 44)
                .background(Color.orange.opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            VStack(alignment: .leading, spacing: 5) {
                Text(canonicalName(for: item))
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                Text("Removido do catálogo · restaure para finalizar")
                    .font(.system(size: 10, weight: .medium, design: .rounded))
                    .foregroundStyle(.orange.opacity(0.84))
            }
            Spacer(minLength: 4)
            Toggle(
                canonicalName(for: item),
                isOn: Binding(
                    get: { true },
                    set: { if !$0 { requestToggle(false, for: item, remoteID: nil, name: canonicalName(for: item)) } }
                )
            )
            .labelsHidden()
            .tint(blue)
            .disabled(!isApplied(item) || !workingIDs.isEmpty || patchStore.isBusy)
            .accessibilityLabel("Restaurar \(canonicalName(for: item))")
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 13)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 21, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 21, style: .continuous).strokeBorder(Color.orange.opacity(0.20), lineWidth: 1))
    }

    private func statusBadge(_ status: LucchesePatchStatus) -> some View {
        let color: Color = status == .ativo ? .green : (status == .atualizando ? .orange : .gray)
        return HStack(spacing: 4) {
            Circle().fill(color).frame(width: 5, height: 5)
            Text(status.rawValue.capitalized)
        }
        .font(.system(size: 9, weight: .semibold, design: .rounded))
        .foregroundStyle(color)
        .padding(.horizontal, 8)
        .padding(.vertical, 5)
        .background(color.opacity(0.11), in: Capsule())
    }

    private func riskBadge(_ risk: Bool) -> some View {
        HStack(spacing: 4) {
            Image(systemName: risk ? "exclamationmark.triangle.fill" : "checkmark.shield.fill")
            Text(risk ? "Risco" : "Sem risco")
        }
        .font(.system(size: 9, weight: .semibold, design: .rounded))
        .foregroundStyle(risk ? Color.orange : Color.green)
        .padding(.horizontal, 8)
        .padding(.vertical, 5)
        .background((risk ? Color.orange : Color.green).opacity(0.10), in: Capsule())
    }

    private func localItem(for remote: LuccheseRemotePatch) -> PatchLibraryItem? {
        guard let id = luccheseAPI.internalID(for: remote.id) else { return nil }
        return patchStore.items.first(where: { $0.id == id })
    }

    private var orphanedAppliedItems: [PatchLibraryItem] {
        let currentRemoteIDs = Set(luccheseAPI.catalog.map(\.id))
        let managedLocalIDs: Set<UUID> = Set(luccheseAPI.mappings.compactMap { remoteID, localID in
            guard currentRemoteIDs.contains(remoteID) else { return nil }
            return UUID(uuidString: localID)
        })
        return patchStore.items.filter { isApplied($0) && !managedLocalIDs.contains($0.id) }
    }

    private func canonicalName(for item: PatchLibraryItem) -> String {
        item.project?.name ?? item.packageURL.deletingPathExtension().lastPathComponent
    }

    private func isApplied(_ item: PatchLibraryItem) -> Bool {
        DevicePatchService.latestReceipt(projectID: item.id) != nil
    }

    private func hasAnotherAppliedPatch(excluding item: PatchLibraryItem) -> Bool {
        patchStore.items.contains { other in
            other.id != item.id && DevicePatchService.latestReceipt(projectID: other.id) != nil
        }
    }

    private func requestToggle(_ enabled: Bool, for item: PatchLibraryItem, remoteID: String?, name: String) {
        guard workingIDs.isEmpty, !patchStore.isBusy else { return }
        if enabled {
            Task {
                if let block = await LuccheseActivationPolicy.blockReason(
                    for: item.id,
                    remoteID: remoteID,
                    api: luccheseAPI,
                    store: patchStore
                ) {
                    if block == .anotherPatchActive {
                        presentToggleConfirmation(item, enabled: true, remoteID: remoteID, name: name, blocked: true)
                    } else {
                        patchStore.alert = PatchStoreAlert(titleKey: "common.failed", messageKey: block.rawValue)
                    }
                    return
                }
                presentToggleConfirmation(item, enabled: true, remoteID: remoteID, name: name)
            }
        } else {
            presentToggleConfirmation(item, enabled: false, remoteID: remoteID, name: name)
        }
    }

    private func presentToggleConfirmation(
        _ item: PatchLibraryItem,
        enabled: Bool,
        remoteID: String?,
        name: String,
        blocked: Bool = false
    ) {
        toggleConfirmation = PendingToggleConfirmation(
            item: item,
            displayName: name,
            remoteID: remoteID,
            isEnabling: enabled,
            isBlocked: blocked || (enabled && hasAnotherAppliedPatch(excluding: item))
        )
    }

    private func setEnabled(_ enabled: Bool, for item: PatchLibraryItem, remoteID: String?, name: String) {
        guard workingIDs.isEmpty, !patchStore.isBusy else { return }
        guard !enabled || !hasAnotherAppliedPatch(excluding: item) else {
            presentToggleConfirmation(item, enabled: true, remoteID: remoteID, name: name, blocked: true)
            return
        }
        if enabled, item.project == nil {
            patchStore.alert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.invalid_project")
            return
        }

        toggleOverrides[item.id] = enabled
        workingIDs.insert(item.id)
        withAnimation(.easeInOut(duration: 0.25)) {
            injectionState = enabled ? .applying : .restoring
        }

        Task.detached(priority: .userInitiated) {
            do {
                if enabled {
                    if let block = await LuccheseActivationPolicy.blockReason(
                        for: item.id,
                        remoteID: remoteID,
                        api: luccheseAPI,
                        store: patchStore
                    ) {
                        await MainActor.run {
                            toggleOverrides[item.id] = nil
                            workingIDs.remove(item.id)
                            injectionState = nil
                            patchStore.alert = PatchStoreAlert(titleKey: "common.failed", messageKey: block.rawValue)
                        }
                        return
                    }
                    guard let baseProject = item.project else { throw PatchPackageError.invalidProject }
                    let project = item.summary.schemaVersion >= 2 && item.canInspectContents
                        ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                        : baseProject
                    _ = try DevicePatchService.apply(project: project)
                } else if let receipt = DevicePatchService.latestReceipt(projectID: item.id) {
                    try DevicePatchService.restore(receipt: receipt)
                }

                await MainActor.run {
                    patchStore.reload()
                    if !enabled,
                       let pair = luccheseAPI.mappings.first(where: { UUID(uuidString: $0.value) == item.id }),
                       !luccheseAPI.catalog.contains(where: { $0.id == pair.key }) {
                        LuccheseCatalogSync.removeOrphanAfterRestore(remoteID: pair.key, api: luccheseAPI, store: patchStore)
                    }
                    toggleOverrides[item.id] = nil
                    workingIDs.remove(item.id)
                    withAnimation(.easeOut(duration: 0.25)) { injectionState = nil }
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    toggleOverrides[item.id] = nil
                    workingIDs.remove(item.id)
                    withAnimation(.easeOut(duration: 0.25)) { injectionState = nil }
                    patchStore.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    toggleOverrides[item.id] = nil
                    workingIDs.remove(item.id)
                    withAnimation(.easeOut(duration: 0.25)) { injectionState = nil }
                    patchStore.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: enabled ? "patch.error.apply" : "patch.error.restore"
                    )
                }
            }
        }
    }

    private func refreshFromAPI() async {
        async let noticeRefresh: Void = luccheseAPI.refreshAnnouncements()
        await LuccheseCatalogSync.synchronize(api: luccheseAPI, store: patchStore)
        await noticeRefresh
    }

    private func handleScenePhaseChange(_ phase: ScenePhase) {
        guard phase == .active else { return }
        Task { await refreshFromAPI() }
    }

    private func handleAutomaticImportAlertChange() {
        guard patchStore.alert?.messageKey == "patch.imported_message",
              luccheseAPI.consumeAutomaticImportSuccessAlert() else { return }
        patchStore.alert = nil
    }

    private func handlePasswordRequestChange() {
        guard patchStore.passwordRequest?.summary.packageID == nil else { return }
        let installedIDs: Set<UUID> = Set(patchStore.items.map(\.id))
        luccheseAPI.clearAutomaticImportIfMissing(installedIDs: installedIDs)
    }

    private func runSynchronizationLoop() async {
        await refreshFromAPI()
        while !Task.isCancelled {
            try? await Task.sleep(nanoseconds: 15_000_000_000)
            guard !Task.isCancelled else { continue }
            guard scenePhase == .active else { continue }
            await refreshFromAPI()
        }
    }

    private func tutorialStep(number: String, text: String, symbol: String) -> some View {
        HStack(alignment: .top, spacing: 13) {
            ZStack {
                Circle().fill(blue.opacity(0.17))
                Text(number)
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .foregroundStyle(Color(red: 0.62, green: 0.79, blue: 1.0))
            }
            .frame(width: 34, height: 34)
            VStack(alignment: .leading, spacing: 7) {
                Image(systemName: symbol)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Color(red: 0.58, green: 0.76, blue: 1.0))
                Text(text)
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.9))
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
    }

    private var developerSignature: some View {
        HStack(spacing: 4) {
            Text("Desenvolvido por").foregroundStyle(.white.opacity(0.45))
            Text("@lucchese").foregroundStyle(Color(red: 0.58, green: 0.76, blue: 1.0))
        }
        .font(.system(size: 12, weight: .semibold, design: .rounded))
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
    }

    private var background: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.015, green: 0.12, blue: 0.36), navy, Color(red: 0.005, green: 0.008, blue: 0.025)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            Circle()
                .fill(blue.opacity(0.22))
                .frame(width: 320, height: 320)
                .blur(radius: 100)
                .offset(x: backgroundShift ? 150 : 110, y: backgroundShift ? -305 : -345)
            Circle()
                .fill(Color.cyan.opacity(0.11))
                .frame(width: 250, height: 250)
                .blur(radius: 95)
                .offset(x: backgroundShift ? -145 : -175, y: backgroundShift ? 135 : 80)
        }
        .animation(.easeInOut(duration: 8).repeatForever(autoreverses: true), value: backgroundShift)
        .ignoresSafeArea()
    }
}

private struct PendingToggleConfirmation: Identifiable {
    let id = UUID()
    let item: PatchLibraryItem
    let displayName: String
    let remoteID: String?
    let isEnabling: Bool
    let isBlocked: Bool
}

private enum InjectionState: Equatable {
    case applying
    case restoring

    var title: String { self == .applying ? "INJETANDO" : "RESTAURANDO" }
    var subtitle: String {
        self == .applying ? "Aplicando patch com segurança…" : "Restaurando os arquivos originais…"
    }
}

private struct StoreLaunchOverlay: View {
    @State private var isAnimating = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.015, green: 0.12, blue: 0.36), Color(red: 0.008, green: 0.018, blue: 0.065), .black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            VStack(spacing: 20) {
                ZStack {
                    Circle().stroke(.white.opacity(0.08), lineWidth: 1).frame(width: 112, height: 112)
                    Circle()
                        .trim(from: 0.08, to: 0.78)
                        .stroke(AngularGradient(colors: [.cyan.opacity(0.15), Color(red: 0.25, green: 0.56, blue: 1), .white], center: .center), style: StrokeStyle(lineWidth: 3, lineCap: .round))
                        .frame(width: 112, height: 112)
                        .rotationEffect(.degrees(isAnimating ? 360 : 0))
                        .animation(.linear(duration: 1.5).repeatForever(autoreverses: false), value: isAnimating)
                    Circle()
                        .fill(Color(red: 0.10, green: 0.38, blue: 0.95).opacity(0.22))
                        .frame(width: 76, height: 76)
                        .scaleEffect(isAnimating ? 1.08 : 0.92)
                        .animation(.easeInOut(duration: 1.1).repeatForever(autoreverses: true), value: isAnimating)
                    Image(systemName: "square.stack.3d.up.fill")
                        .font(.system(size: 28, weight: .medium))
                        .foregroundStyle(.white)
                        .shadow(color: .cyan.opacity(0.7), radius: 16)
                }
                VStack(spacing: 7) {
                    Text("LUCCHESE STORE")
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                        .tracking(3)
                        .foregroundStyle(.white)
                    Text("INICIALIZANDO")
                        .font(.system(size: 10, weight: .semibold, design: .rounded))
                        .tracking(2.6)
                        .foregroundStyle(Color(red: 0.58, green: 0.76, blue: 1.0))
                }
            }
        }
        .onAppear { isAnimating = true }
        .accessibilityElement(children: .combine)
    }
}

private struct InjectionOverlay: View {
    let state: InjectionState
    @State private var isAnimating = false

    var body: some View {
        ZStack {
            Rectangle().fill(.black.opacity(0.48)).background(.ultraThinMaterial).ignoresSafeArea()
            VStack(spacing: 18) {
                ZStack {
                    Circle().stroke(.white.opacity(0.10), lineWidth: 1).frame(width: 116, height: 116)
                    Circle()
                        .trim(from: 0.06, to: 0.72)
                        .stroke(AngularGradient(colors: [.cyan.opacity(0.12), Color(red: 0.20, green: 0.48, blue: 1), .white], center: .center), style: StrokeStyle(lineWidth: 3, lineCap: .round))
                        .frame(width: 116, height: 116)
                        .rotationEffect(.degrees(isAnimating ? 360 : 0))
                        .animation(.linear(duration: 1.25).repeatForever(autoreverses: false), value: isAnimating)
                    Circle()
                        .fill(Color(red: 0.12, green: 0.42, blue: 1).opacity(0.20))
                        .frame(width: 82, height: 82)
                        .scaleEffect(isAnimating ? 1.10 : 0.90)
                        .animation(.easeInOut(duration: 0.9).repeatForever(autoreverses: true), value: isAnimating)
                    Image(systemName: state == .applying ? "bolt.fill" : "arrow.uturn.backward")
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundStyle(.white)
                        .shadow(color: .cyan.opacity(0.72), radius: 17)
                }
                VStack(spacing: 7) {
                    Text(state.title)
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .tracking(3)
                        .foregroundStyle(.white)
                    Text(state.subtitle)
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.66))
                        .multilineTextAlignment(.center)
                }
                ProgressView().tint(Color(red: 0.58, green: 0.76, blue: 1.0)).padding(.top, 2)
            }
            .padding(28)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).strokeBorder(.white.opacity(0.13), lineWidth: 1))
            .shadow(color: Color.blue.opacity(0.22), radius: 35, y: 12)
            .padding(.horizontal, 38)
        }
        .onAppear { isAnimating = true }
        .accessibilityElement(children: .combine)
    }
}
