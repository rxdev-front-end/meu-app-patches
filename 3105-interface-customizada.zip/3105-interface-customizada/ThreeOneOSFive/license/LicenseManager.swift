import Combine
import Foundation
import UIKit

/// Orquestra o fluxo de licença: ativação, validação de rotina, bloqueio e
/// tolerância offline. Toda a lógica roda na MainActor para alimentar a UI.
@MainActor
final class LicenseManager: ObservableObject {
    enum Lock: Equatable {
        /// Nenhuma key salva: a tela pede a key.
        case noKey
        /// A key foi recusada pelo servidor (expirada, revogada, outro aparelho…).
        case rejected(LicenseFailure)
        /// Não foi possível confirmar a licença (rede, servidor, rate limit…).
        case unavailable(LicenseFailure)
    }

    enum Phase: Equatable {
        case checking
        case locked(Lock)
        case unlocked(isOffline: Bool)
    }

    enum UnlinkState: Equatable {
        case idle
        case working
        case success
        case failed(String)
    }

    @Published private(set) var phase: Phase = .checking
    @Published private(set) var info: LicenseInfo?
    @Published private(set) var storedKey: String?
    @Published private(set) var isWorking = false
    @Published private(set) var lastFailure: LicenseFailure?
    @Published private(set) var celebration: LicenseInfo?
    @Published private(set) var unlinkState: UnlinkState = .idle
    @Published private(set) var lastCheckDate: Date?
    @Published private(set) var notice: String?

    private let client = LuccheseLicenseClient()
    private static let cacheKey = "Lucchese.License.cache.v2"
    /// Polling rápido enquanto o app está ativo; o iOS pode suspender a rede em background.
    private static let heartbeatInterval: UInt64 = 15 * 1_000_000_000

    private var hasStarted = false
    private var celebrationTask: Task<Void, Never>?

    // MARK: Derivados

    var isUnlocked: Bool {
        if case .unlocked = phase { return true }
        return false
    }

    var isOfflineUnlock: Bool {
        if case .unlocked(let offline) = phase { return offline }
        return false
    }

    var maskedKey: String {
        guard let storedKey else { return "—" }
        return Self.mask(storedKey)
    }

    var statusChipText: String {
        guard isUnlocked else { return "Bloqueado" }
        if isOfflineUnlock { return "Offline" }
        guard let info else { return "Ativa" }
        guard let days = info.daysRemaining else { return "Ativa" }
        if days <= 0 { return "Hoje" }
        return "\(days)d"
    }

    var expiryDescription: String {
        guard let expiresDate = info?.expiresDate else { return "Sem data de expiração" }
        return LicenseDate.medium(expiresDate)
    }

    var planDescription: String {
        guard let planDays = info?.planDays else { return "—" }
        return planDays == 1 ? "1 dia" : "\(planDays) dias"
    }

    var lastCheckDescription: String {
        guard let lastCheckDate else { return "—" }
        return LicenseDate.medium(lastCheckDate)
    }

    // MARK: Ciclo de vida

    func startIfNeeded() async {
        guard !hasStarted else { return }
        hasStarted = true

        storedKey = LicenseKeychain.readKey()
        info = Self.loadCache()

        guard storedKey != nil else {
            info = nil
            phase = .locked(.noKey)
            return
        }

        if let info, info.isExpired {
            phase = .locked(.rejected(.keyExpired))
            return
        }

        // Se a última verificação está dentro da tolerância, libera na hora e
        // confirma com o servidor em seguida (sem tela de espera).
        if let info, info.isActive, info.isWithinGrace(LuccheseLicenseConfiguration.offlineGrace) {
            phase = .unlocked(isOffline: true)
        } else {
            phase = .checking
        }

        await validateStoredKey()
    }

    /// Valida a key salva. Usado na abertura, ao voltar do background e no heartbeat.
    func validateStoredKey() async {
        guard let key = storedKey, !isWorking else { return }
        isWorking = true
        defer { isWorking = false }

        do {
            let fresh = try await client.validate(key: key, hwid: LicenseHWID.value)
            apply(fresh)
            lastFailure = nil
            phase = .unlocked(isOffline: false)
        } catch let failure as LicenseFailure {
            handle(failure)
        } catch {
            handle(.serverError)
        }
    }

    func handleForeground() async {
        guard hasStarted else { return }
        switch phase {
        case .unlocked:
            await validateStoredKey()
        case .locked(.unavailable):
            await validateStoredKey()
        case .locked, .checking:
            return
        }
    }

    /// Polling de status: revalida a cada 15 segundos enquanto o app/licença estiver ativo.
    func monitor() async {
        while !Task.isCancelled {
            try? await Task.sleep(nanoseconds: Self.heartbeatInterval)
            guard !Task.isCancelled else { return }
            guard isUnlocked else { continue }
            if let info, info.isExpired {
                phase = .locked(.rejected(.keyExpired))
                continue
            }
            await validateStoredKey()
        }
    }

    // MARK: Ações da interface

    func activate(rawKey: String) async {
        guard !isWorking else { return }
        notice = nil
        let key = Self.normalize(rawKey)
        guard !key.isEmpty else {
            lastFailure = .emptyKey
            return
        }

        let previousPhase = phase
        isWorking = true
        lastFailure = nil
        defer { isWorking = false }

        do {
            let fresh = try await client.activate(key: key, hwid: LicenseHWID.value)
            LicenseKeychain.saveKey(key)
            storedKey = key
            apply(fresh)
            phase = .unlocked(isOffline: false)
            celebrate(fresh)
        } catch let failure as LicenseFailure {
            lastFailure = failure
            phase = previousPhase
        } catch {
            lastFailure = .serverError
            phase = previousPhase
        }
    }

    /// Volta para o formulário de key sem apagar a key salva.
    func showKeyEntry() {
        lastFailure = nil
        notice = nil
        unlinkState = .idle
        phase = .locked(.noKey)
    }

    /// Remove a key apenas deste aparelho (não afeta o painel).
    func forgetLicense() {
        LicenseKeychain.deleteKey()
        Self.clearCache()
        storedKey = nil
        info = nil
        lastFailure = nil
        notice = nil
        unlinkState = .idle
        lastCheckDate = nil
        phase = .locked(.noKey)
    }

    func requestUnlink(key rawKey: String) async {
        let key = Self.normalize(rawKey)
        guard !key.isEmpty else {
            unlinkState = .failed("Nenhuma key informada.")
            return
        }
        guard unlinkState != .working else { return }
        unlinkState = .working
        do {
            try await client.unlinkHWID(key: key, hwid: LicenseHWID.value)
            LicenseKeychain.deleteKey()
            Self.clearCache()
            storedKey = nil
            info = nil
            lastCheckDate = nil
            lastFailure = nil
            unlinkState = .success
            notice = "Aparelho desvinculado. Ative a key novamente para liberar o acesso."
            phase = .locked(.noKey)
        } catch let failure as LicenseFailure {
            unlinkState = .failed(failure.detail ?? failure.title)
        } catch {
            unlinkState = .failed("Não foi possível desvincular agora. Tente novamente.")
        }
    }

    // MARK: Internos

    private func apply(_ fresh: LicenseInfo) {
        var updated = fresh
        updated.validatedAt = Date()
        info = updated
        lastCheckDate = updated.validatedAt
        Self.saveCache(updated)
    }

    private func handle(_ failure: LicenseFailure) {
        lastFailure = failure

        if failure.isConnectivityIssue {
            // Tolerância offline: mantém liberado enquanto estiver dentro da janela.
            if let info, info.isActive, !info.isExpired,
               info.isWithinGrace(LuccheseLicenseConfiguration.offlineGrace) {
                phase = .unlocked(isOffline: true)
            } else {
                phase = .locked(.unavailable(failure))
            }
            return
        }

        if failure == .keyRevoked || failure == .keyNotFound {
            LicenseKeychain.deleteKey()
            Self.clearCache()
            storedKey = nil
            info = nil
        }
        phase = .locked(.rejected(failure))
    }

    private func celebrate(_ fresh: LicenseInfo) {
        celebration = fresh
        celebrationTask?.cancel()
        celebrationTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 1_700_000_000)
            guard !Task.isCancelled else { return }
            self?.celebration = nil
        }
    }

    // MARK: Utilidades

    static func normalize(_ raw: String) -> String {
        let upper = raw.uppercased()
        let filtered = upper.filter { $0.isLetter || $0.isNumber || $0 == "-" }
        return String(filtered.prefix(48))
    }

    static func mask(_ key: String) -> String {
        let parts = key.split(separator: "-", maxSplits: 1)
        guard let prefix = parts.first, key.count > 8 else { return key }
        return "\(prefix)-••••••••"
    }

    private static func saveCache(_ info: LicenseInfo) {
        guard let data = try? JSONEncoder().encode(info) else { return }
        UserDefaults.standard.set(data, forKey: cacheKey)
    }

    private static func loadCache() -> LicenseInfo? {
        guard let data = UserDefaults.standard.data(forKey: cacheKey) else { return nil }
        return try? JSONDecoder().decode(LicenseInfo.self, from: data)
    }

    private static func clearCache() {
        UserDefaults.standard.removeObject(forKey: cacheKey)
    }
}
