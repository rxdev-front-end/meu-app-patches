import SwiftUI
import UIKit

/// Painel de licença aberto pelo selo no topo da tela principal.
struct LicenseDetailsSheet: View {
    @EnvironmentObject private var license: LicenseManager
    @Environment(\.dismiss) private var dismiss

    @State private var copiedKey = false
    @State private var copiedHWID = false
    @State private var confirmRemove = false

    var body: some View {
        ZStack {
            LicenseAuroraBackground()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 16) {
                    header
                    statusCard
                    detailsCard
                    actionsCard
                }
                .padding(.horizontal, 20)
                .padding(.top, 22)
                .padding(.bottom, 34)
            }
        }
        .preferredColorScheme(.dark)
        .presentationDetents([.large])
        .presentationDragIndicator(.visible)
        .confirmationDialog(
            "Remover licença deste aparelho?",
            isPresented: $confirmRemove,
            titleVisibility: .visible
        ) {
            Button("Remover", role: .destructive) {
                license.forgetLicense()
                dismiss()
            }
            Button("Cancelar", role: .cancel) {}
        } message: {
            Text("A key continua válida no painel. Você poderá ativá-la de novo depois.")
        }
    }

    // MARK: Cabeçalho

    private var header: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 15, style: .continuous)
                    .fill(LicensePalette.accent.opacity(0.24))
                Image(systemName: "key.fill")
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundStyle(.white)
            }
            .frame(width: 48, height: 48)

            VStack(alignment: .leading, spacing: 3) {
                Text("Licença")
                    .font(.system(size: 24, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text("LUCCHESE STORE")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(2.4)
                    .foregroundStyle(LicensePalette.highlight)
            }

            Spacer(minLength: 0)

            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(.white.opacity(0.75))
                    .frame(width: 34, height: 34)
                    .background(Circle().fill(Color.white.opacity(0.08)))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Fechar")
        }
    }

    // MARK: Status

    private var statusCard: some View {
        LicenseGlassCard {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 8) {
                    Image(systemName: statusSymbol)
                        .font(.system(size: 11, weight: .bold))
                    Text(statusTitle)
                        .font(.system(size: 11, weight: .bold, design: .rounded))
                        .tracking(1.2)
                }
                .foregroundStyle(statusTint)
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(Capsule().fill(statusTint.opacity(0.14)))

                HStack(alignment: .firstTextBaseline, spacing: 6) {
                    Text(bigNumber)
                        .font(.system(size: 38, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    Text(bigCaption)
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.6))
                }

                Text("Expira em \(license.expiryDescription)")
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55))
            }
        }
    }

    private var statusSymbol: String {
        if license.isOfflineUnlock { return "wifi.slash" }
        return license.isUnlocked ? "checkmark.seal.fill" : "lock.fill"
    }

    private var statusTitle: String {
        if license.isOfflineUnlock { return "ATIVA · VERIFICAÇÃO PENDENTE" }
        return license.isUnlocked ? "LICENÇA ATIVA" : "BLOQUEADA"
    }

    private var statusTint: Color {
        if license.isOfflineUnlock { return LicensePalette.warning }
        return license.isUnlocked ? LicensePalette.success : LicensePalette.danger
    }

    private var bigNumber: String {
        guard let days = license.info?.daysRemaining else { return "—" }
        return "\(days)"
    }

    private var bigCaption: String {
        guard let days = license.info?.daysRemaining else { return "dias restantes" }
        return days == 1 ? "dia restante" : "dias restantes"
    }

    // MARK: Detalhes

    private var detailsCard: some View {
        LicenseGlassCard {
            VStack(spacing: 0) {
                row(
                    icon: "key.fill",
                    title: "Key",
                    value: license.maskedKey,
                    monospaced: true,
                    copyValue: license.storedKey
                )
                divider
                row(
                    icon: "calendar",
                    title: "Plano",
                    value: license.planDescription
                )
                divider
                row(
                    icon: "iphone",
                    title: "HWID",
                    value: LicenseHWID.short,
                    monospaced: true,
                    copyValue: LicenseHWID.value
                )
                divider
                row(
                    icon: "clock.arrow.circlepath",
                    title: "Última verificação",
                    value: license.lastCheckDescription
                )
            }
        }
    }

    private var divider: some View {
        Rectangle()
            .fill(Color.white.opacity(0.07))
            .frame(height: 1)
            .padding(.vertical, 11)
    }

    private func row(
        icon: String,
        title: String,
        value: String,
        monospaced: Bool = false,
        copyValue: String? = nil
    ) -> some View {
        HStack(spacing: 11) {
            Image(systemName: icon)
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(LicensePalette.highlight)
                .frame(width: 18)

            Text(title)
                .font(.system(size: 12, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.55))

            Spacer(minLength: 8)

            Text(value)
                .font(
                    monospaced
                        ? .system(size: 12, weight: .semibold, design: .monospaced)
                        : .system(size: 12, weight: .semibold, design: .rounded)
                )
                .foregroundStyle(.white.opacity(0.9))
                .lineLimit(1)
                .truncationMode(.middle)

            if let copyValue {
                Button {
                    UIPasteboard.general.string = copyValue
                    withAnimation(.easeOut(duration: 0.2)) {
                        if icon == "key.fill" { copiedKey = true } else { copiedHWID = true }
                    }
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    Task {
                        try? await Task.sleep(nanoseconds: 1_600_000_000)
                        withAnimation(.easeOut(duration: 0.2)) {
                            if icon == "key.fill" { copiedKey = false } else { copiedHWID = false }
                        }
                    }
                } label: {
                    Image(systemName: copyIcon(for: icon))
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.55))
                        .frame(width: 26, height: 26)
                        .background(Circle().fill(Color.white.opacity(0.07)))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Copiar \(title)")
            }
        }
    }

    private func copyIcon(for icon: String) -> String {
        if icon == "key.fill" {
            return copiedKey ? "checkmark" : "doc.on.doc"
        }
        return copiedHWID ? "checkmark" : "doc.on.doc"
    }

    // MARK: Ações

    private var actionsCard: some View {
        VStack(spacing: 10) {
            Button {
                Task { await license.validateStoredKey() }
            } label: {
                HStack(spacing: 9) {
                    if license.isWorking {
                        ProgressView().tint(.white).scaleEffect(0.85)
                    } else {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 14, weight: .bold))
                    }
                    Text(license.isWorking ? "Verificando…" : "Verificar agora")
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                }
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 50)
                .background(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .fill(
                            LinearGradient(
                                colors: LicensePalette.buttonGradient,
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .shadow(color: LicensePalette.accent.opacity(0.35), radius: 16, y: 7)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .strokeBorder(.white.opacity(0.16), lineWidth: 1)
                )
            }
            .buttonStyle(.plain)
            .disabled(license.isWorking)

            Button {
                license.showKeyEntry()
                dismiss()
            } label: {
                Text("Trocar de key")
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.88))
                    .frame(maxWidth: .infinity)
                    .frame(height: 46)
                    .background(
                        RoundedRectangle(cornerRadius: 15, style: .continuous)
                            .fill(Color.white.opacity(0.07))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 15, style: .continuous)
                            .strokeBorder(.white.opacity(0.12), lineWidth: 1)
                    )
            }
            .buttonStyle(.plain)

            Button {
                confirmRemove = true
            } label: {
                Text("Remover deste aparelho")
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(LicensePalette.danger.opacity(0.9))
                    .frame(maxWidth: .infinity)
                    .frame(height: 42)
            }
            .buttonStyle(.plain)

            Text("A licença é revalidada automaticamente a cada 15 segundos enquanto o app estiver aberto. Sem internet, o acesso continua por até \(Int(LuccheseLicenseConfiguration.offlineGrace / 60)) minutos após a última verificação.")
                .font(.system(size: 10.5, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.38))
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.top, 4)
        }
    }
}
