import Combine
import Foundation
import SwiftUI
import UIKit
import Darwin

// MARK: - Configuração do controle global

enum AppControlConfiguration {
    /// URL de origem pública do painel; deve ser preenchida após a publicação.
    static let baseURL: URL? = {
        guard let raw = Bundle.main.object(forInfoDictionaryKey: "LUCCHESE_APP_CONTROL_BASE_URL") as? String else {
            return nil
        }
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty,
              let url = URL(string: value),
              let components = URLComponents(url: url, resolvingAgainstBaseURL: false),
              components.scheme?.lowercased() == "https",
              components.host != nil,
              components.user == nil,
              components.password == nil,
              components.query == nil,
              components.fragment == nil else {
            return nil
        }
        return url
    }()
}

// MARK: - Contrato público de bootstrap

private enum AppServiceMode: String, Decodable {
    case normal
    case updating
    case oldVersion = "old_version"
    case offline
}

private struct AppBootstrapResponse: Decodable {
    struct Device: Decodable {
        let hwid: String
        let banned: Bool
        let banReason: String?
    }

    let ok: Bool
    let mode: AppServiceMode
    let message: String?
    let device: Device
}

private struct AppBootstrapPayload: Encodable {
    let hwid: String
    let deviceModel: String
    let iosVersion: String
    let appVersion: String
    let buildNumber: String
}

private enum AppControlClientError: Error {
    case notConfigured
    case deviceIdentityUnavailable
    case invalidResponse
    case serverUnavailable
}

private struct AppControlClient {
    func bootstrap() async throws -> AppBootstrapResponse {
        guard let baseURL = AppControlConfiguration.baseURL,
              let hwid = LicenseHWID.value.nilIfEmpty else {
            throw AppControlClientError.notConfigured
        }
        let endpoint = baseURL.appendingPathComponent("api/app/bootstrap")
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.timeoutInterval = 10
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let payload = AppBootstrapPayload(
            hwid: hwid,
            deviceModel: Self.deviceModel,
            iosVersion: UIDevice.current.systemVersion,
            appVersion: Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0",
            buildNumber: Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "0"
        )
        request.httpBody = try JSONEncoder().encode(payload)
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
                throw AppControlClientError.serverUnavailable
            }
            let result = try JSONDecoder().decode(AppBootstrapResponse.self, from: data)
            guard result.ok, result.device.hwid.uppercased() == hwid.uppercased() else {
                throw AppControlClientError.invalidResponse
            }
            return result
        } catch let error as AppControlClientError {
            throw error
        } catch {
            throw AppControlClientError.serverUnavailable
        }
    }

    private static var deviceModel: String {
        let marketingName = UIDevice.current.model
        var size: size_t = 0
        guard sysctlbyname("hw.machine", nil, &size, nil, 0) == 0, size > 0 else {
            return marketingName
        }
        var machine = [CChar](repeating: 0, count: Int(size))
        guard sysctlbyname("hw.machine", &machine, &size, nil, 0) == 0 else {
            return marketingName
        }
        let modelCode = String(cString: machine)
        return "\(marketingName) (\(modelCode))"
    }
}

private extension String {
    var nilIfEmpty: String? { isEmpty ? nil : self }
}

// MARK: - Gate do serviço

@MainActor
final class AppAccessManager: ObservableObject {
    enum State: Equatable {
        case checking
        case allowed
        case updating(String)
        case oldVersion(String)
        case offline(String)
        case banned(String?)
        case unavailable
    }

    @Published private(set) var state: State = .checking
    private let client = AppControlClient()
    private var hasStarted = false
    private var isChecking = false
    private static let heartbeatInterval: UInt64 = 15 * 1_000_000_000

    var canUseApp: Bool {
        if case .allowed = state { return true }
        return false
    }

    func startIfNeeded() async {
        guard !hasStarted else { return }
        hasStarted = true
        // Acessa o identificador imediatamente, antes da tela de key.
        guard !LicenseHWID.value.isEmpty else {
            state = .unavailable
            return
        }
        await refresh()
    }

    func refresh() async {
        guard !isChecking else { return }
        isChecking = true
        defer { isChecking = false }
        do {
            let result = try await client.bootstrap()
            if result.device.banned {
                state = .banned(result.device.banReason)
                return
            }
            switch result.mode {
            case .normal:
                state = .allowed
            case .updating:
                state = .updating(result.message ?? "O app está atualizando. Contate o suporte.")
            case .oldVersion:
                state = .oldVersion(result.message ?? "Nova versão disponível para baixar. Contate o suporte.")
            case .offline:
                state = .offline(result.message ?? "App offline. Aguardando o proprietário religar o app.")
            }
        } catch {
            // Fail closed: sem confirmação do backend, nenhuma área do app é exposta.
            state = .unavailable
        }
    }

    func monitor() async {
        while !Task.isCancelled {
            try? await Task.sleep(nanoseconds: Self.heartbeatInterval)
            guard !Task.isCancelled else { return }
            guard UIApplication.shared.applicationState == .active else { continue }
            await refresh()
        }
    }
}

// MARK: - Tela de acesso controlado

struct AppAccessGateView: View {
    let state: AppAccessManager.State
    let onRetry: () async -> Void
    @State private var isRetrying = false

    private var presentation: (title: String, message: String, symbol: String, tint: Color, canRetry: Bool) {
        switch state {
        case .checking:
            return ("Verificando acesso", "Aguarde enquanto confirmamos o status do serviço e deste aparelho.", "arrow.triangle.2.circlepath", LicensePalette.highlight, false)
        case .allowed:
            return ("Acesso liberado", "", "checkmark.shield.fill", LicensePalette.success, false)
        case .updating(let message):
            return ("Estamos atualizando", message, "wrench.and.screwdriver.fill", LicensePalette.warning, false)
        case .oldVersion(let message):
            return ("Nova versão disponível", message, "arrow.down.app.fill", LicensePalette.highlight, false)
        case .offline(let message):
            return ("App offline", message, "wifi.slash", LicensePalette.highlight, false)
        case .banned(let reason):
            let detail = reason?.trimmingCharacters(in: .whitespacesAndNewlines)
            let message = detail?.isEmpty == false ? "Este dispositivo foi banido. \(detail!)" : "Este dispositivo foi banido. Contate o suporte."
            return ("Dispositivo banido", message, "hand.raised.fill", LicensePalette.danger, false)
        case .unavailable:
            return ("Não foi possível verificar", "Conecte-se à internet e tente novamente. O app permanece bloqueado até o servidor confirmar o acesso.", "exclamationmark.icloud.fill", LicensePalette.highlight, true)
        }
    }

    var body: some View {
        let visual = presentation
        ZStack {
            LicenseAuroraBackground()
            VStack(spacing: 22) {
                LicenseBrandMark(size: 86)
                VStack(spacing: 8) {
                    Text("LUCCHESE STORE")
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .tracking(5)
                        .foregroundStyle(.white.opacity(0.95))
                    Text("CONTROLE DE ACESSO")
                        .font(.system(size: 9, weight: .semibold, design: .rounded))
                        .tracking(3.2)
                        .foregroundStyle(LicensePalette.highlight.opacity(0.85))
                }
                LicenseGlassCard {
                    VStack(spacing: 16) {
                        Image(systemName: visual.symbol)
                            .font(.system(size: 28, weight: .semibold))
                            .foregroundStyle(visual.tint)
                            .frame(width: 62, height: 62)
                            .background(visual.tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 19, style: .continuous))
                            .overlay(RoundedRectangle(cornerRadius: 19, style: .continuous).stroke(visual.tint.opacity(0.23), lineWidth: 1))
                        Text(visual.title)
                            .font(.system(size: 21, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .multilineTextAlignment(.center)
                        Text(visual.message)
                            .font(.system(size: 14, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.68))
                            .multilineTextAlignment(.center)
                            .lineSpacing(4)
                        if case .checking = state {
                            ProgressView().tint(LicensePalette.highlight).padding(.top, 2)
                        } else if visual.canRetry {
                            Button {
                                guard !isRetrying else { return }
                                isRetrying = true
                                Task {
                                    await onRetry()
                                    isRetrying = false
                                }
                            } label: {
                                HStack(spacing: 9) {
                                    if isRetrying { ProgressView().tint(.white) } else { Image(systemName: "arrow.clockwise") }
                                    Text(isRetrying ? "Verificando…" : "Tentar novamente")
                                }
                                .font(.system(size: 14, weight: .bold, design: .rounded))
                                .foregroundStyle(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                                .background(LinearGradient(colors: LicensePalette.buttonGradient, startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                            }
                            .buttonStyle(.plain)
                            .disabled(isRetrying)
                            .padding(.top, 2)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                }
                .frame(maxWidth: 410)
                HStack(spacing: 7) {
                    Image(systemName: "lock.shield.fill")
                    Text("Acesso protegido pela Lucchese Store")
                }
                .font(.system(size: 10, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.43))
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 34)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(LicensePalette.navy.ignoresSafeArea())
        .preferredColorScheme(.dark)
    }
}
