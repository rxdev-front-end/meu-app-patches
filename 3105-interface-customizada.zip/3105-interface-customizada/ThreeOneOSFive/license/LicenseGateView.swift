import SwiftUI
import UIKit

// MARK: - Paleta

enum LicensePalette {
    static let navy = Color(red: 0.008, green: 0.018, blue: 0.065)
    static let accent = Color(red: 0.12, green: 0.40, blue: 1.0)
    static let highlight = Color(red: 0.58, green: 0.76, blue: 1.0)
    static let success = Color(red: 0.30, green: 0.85, blue: 0.60)
    static let warning = Color(red: 1.0, green: 0.72, blue: 0.28)
    static let danger = Color(red: 1.0, green: 0.44, blue: 0.44)

    static let buttonGradient = [
        Color(red: 0.18, green: 0.48, blue: 1.0),
        Color(red: 0.06, green: 0.26, blue: 0.86)
    ]

    static func tint(for failure: LicenseFailure) -> Color {
        switch failure {
        case .keyExpired, .rateLimited:
            return warning
        case .keyNotFound, .hwidMismatch, .inactive:
            return warning
        case .keyRevoked, .invalidAPIKey, .notConfigured:
            return danger
        case .offline, .serverError, .invalidResponse, .emptyKey:
            return highlight
        }
    }
}

// MARK: - Fundo

struct LicenseAuroraBackground: View {
    @State private var shift = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.015, green: 0.12, blue: 0.36),
                    LicensePalette.navy,
                    Color(red: 0.005, green: 0.008, blue: 0.025)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            Circle()
                .fill(LicensePalette.accent.opacity(0.26))
                .frame(width: 340, height: 340)
                .blur(radius: 110)
                .offset(x: shift ? 150 : 110, y: shift ? -320 : -360)
            Circle()
                .fill(Color.cyan.opacity(0.12))
                .frame(width: 260, height: 260)
                .blur(radius: 100)
                .offset(x: shift ? -150 : -180, y: shift ? 150 : 90)
            Circle()
                .fill(LicensePalette.accent.opacity(0.13))
                .frame(width: 220, height: 220)
                .blur(radius: 95)
                .offset(x: shift ? 70 : 130, y: shift ? 330 : 280)
        }
        .animation(.easeInOut(duration: 9).repeatForever(autoreverses: true), value: shift)
        .onAppear { shift = true }
        .ignoresSafeArea()
    }
}

// MARK: - Cartão de vidro

struct LicenseGlassCard<Content: View>: View {
    private let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 26, style: .continuous)
                    .strokeBorder(.white.opacity(0.10), lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(0.32), radius: 24, y: 12)
    }
}

// MARK: - Tremida

struct LicenseShake: GeometryEffect {
    var animatableData: CGFloat

    func effectValue(size: CGSize) -> ProjectionTransform {
        ProjectionTransform(
            CGAffineTransform(translationX: 9 * sin(animatableData * .pi * 3), y: 0)
        )
    }
}

// MARK: - Marca

struct LicenseBrandMark: View {
    var size: CGFloat = 104
    @State private var spin = false

    var body: some View {
        ZStack {
            Circle()
                .fill(LicensePalette.accent.opacity(0.16))
                .frame(width: size * 0.72, height: size * 0.72)
                .blur(radius: 18)
            Circle()
                .stroke(.white.opacity(0.08), lineWidth: 1)
                .frame(width: size, height: size)
            Circle()
                .trim(from: 0.06, to: 0.74)
                .stroke(
                    AngularGradient(
                        colors: [.cyan.opacity(0.10), Color(red: 0.25, green: 0.56, blue: 1), .white],
                        center: .center
                    ),
                    style: StrokeStyle(lineWidth: 2.6, lineCap: .round)
                )
                .frame(width: size, height: size)
                .rotationEffect(.degrees(spin ? 360 : 0))
                .animation(.linear(duration: 6.5).repeatForever(autoreverses: false), value: spin)
            Image(systemName: "key.fill")
                .font(.system(size: size * 0.25, weight: .semibold))
                .foregroundStyle(.white)
                .shadow(color: .cyan.opacity(0.65), radius: 14)
        }
        .onAppear { spin = true }
        .accessibilityHidden(true)
    }
}

// MARK: - Tela de key

struct LicenseGateView: View {
    @EnvironmentObject private var license: LicenseManager

    @State private var keyText = ""
    @State private var shake: CGFloat = 0
    @State private var copiedHWID = false
    @FocusState private var isKeyFocused: Bool

    var body: some View {
        ZStack {
            LicenseAuroraBackground()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 20) {
                    brandHeader
                    content
                    deviceCard
                    legalFooter
                }
                .padding(.horizontal, 22)
                .padding(.top, 30)
                .padding(.bottom, 36)
                .frame(maxWidth: 520)
                .frame(maxWidth: .infinity)
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .preferredColorScheme(.dark)
        .onAppear {
            if keyText.isEmpty, let stored = license.storedKey {
                keyText = stored
            }
        }
        .onChange(of: license.storedKey) { _, stored in
            guard let stored, keyText.isEmpty else { return }
            keyText = stored
        }
        .onChange(of: license.lastFailure) { _, failure in
            guard failure != nil else { return }
            withAnimation(.linear(duration: 0.45)) { shake += 1 }
            UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
        }
        .onChange(of: license.isUnlocked) { _, unlocked in
            guard unlocked else { return }
            isKeyFocused = false
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        }
    }

    // MARK: Cabeçalho

    private var brandHeader: some View {
        VStack(spacing: 15) {
            LicenseBrandMark()
            VStack(spacing: 7) {
                Text("LUCCHESE STORE")
                    .font(.system(size: 19, weight: .bold, design: .rounded))
                    .tracking(3.4)
                    .foregroundStyle(.white)
                Text("ACESSO PROTEGIDO POR KEY")
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .tracking(2.4)
                    .foregroundStyle(LicensePalette.highlight.opacity(0.92))
            }
        }
        .padding(.bottom, 4)
    }

    // MARK: Conteúdo por estado

    @ViewBuilder
    private var content: some View {
        if case .locked(.noKey) = license.phase {
            keyFormCard
        } else if case .locked(.rejected(let failure)) = license.phase {
            rejectedCard(failure: failure)
        } else if case .locked(.unavailable(let failure)) = license.phase {
            unavailableCard(failure: failure)
        } else {
            checkingCard
        }
    }

    private var keyFormCard: some View {
        LicenseGlassCard {
            VStack(alignment: .leading, spacing: 16) {
                Text("Insira sua key para liberar o acesso.")
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.84))
                    .fixedSize(horizontal: false, vertical: true)

                keyField

                if let notice = license.notice {
                    noticeBanner(notice)
                }

                if let failure = license.lastFailure, failure != .emptyKey {
                    failureBanner(failure)
                }

                activateButton
            }
        }
        .modifier(LicenseShake(animatableData: shake))
    }

    private var keyField: some View {
        HStack(spacing: 10) {
            Image(systemName: "key.fill")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(LicensePalette.highlight)

            TextField(
                "",
                text: $keyText,
                prompt: Text("LUCCHESE-XXXXXXXXXXX").foregroundColor(.white.opacity(0.30))
            )
            .font(.system(size: 15, weight: .semibold, design: .monospaced))
            .foregroundStyle(.white)
            .textInputAutocapitalization(.characters)
            .autocorrectionDisabled()
            .keyboardType(.asciiCapable)
            .submitLabel(.go)
            .focused($isKeyFocused)
            .onSubmit { submit() }
            .onChange(of: keyText) { _, value in
                let normalized = LicenseManager.normalize(value)
                if normalized != value {
                    keyText = normalized
                }
            }

            trailingKeyAction
        }
        .padding(.horizontal, 14)
        .frame(height: 54)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(Color.white.opacity(0.055))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .strokeBorder(
                    isKeyFocused ? LicensePalette.accent.opacity(0.78) : Color.white.opacity(0.12),
                    lineWidth: isKeyFocused ? 1.6 : 1
                )
        )
        .animation(.easeOut(duration: 0.2), value: isKeyFocused)
    }

    @ViewBuilder
    private var trailingKeyAction: some View {
        if keyText.isEmpty {
            Button(action: pasteKey) {
                Text("Colar")
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .foregroundStyle(LicensePalette.highlight)
                    .padding(.horizontal, 11)
                    .padding(.vertical, 7)
                    .background(Capsule().fill(LicensePalette.highlight.opacity(0.14)))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Colar key")
        } else {
            Button {
                keyText = ""
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(.white.opacity(0.35))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Limpar key")
        }
    }

    private var activateButton: some View {
        Button(action: submit) {
            HStack(spacing: 9) {
                if license.isWorking {
                    ProgressView()
                        .tint(.white)
                        .scaleEffect(0.85)
                } else {
                    Image(systemName: "bolt.fill")
                        .font(.system(size: 14, weight: .bold))
                }
                Text(license.isWorking ? "Verificando…" : "Ativar licença")
                    .font(.system(size: 16, weight: .bold, design: .rounded))
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 54)
            .background(
                RoundedRectangle(cornerRadius: 17, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: LicensePalette.buttonGradient,
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .shadow(color: LicensePalette.accent.opacity(0.45), radius: 18, y: 8)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 17, style: .continuous)
                    .strokeBorder(.white.opacity(0.18), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .disabled(license.isWorking || keyText.isEmpty)
        .opacity(keyText.isEmpty ? 0.55 : 1)
        .accessibilityLabel("Ativar licença")
    }

    // MARK: Estados de bloqueio

    private func rejectedCard(failure: LicenseFailure) -> some View {
        LicenseGlassCard {
            VStack(spacing: 16) {
                statusIcon(symbol: failure.symbol, tint: LicensePalette.tint(for: failure))

                VStack(spacing: 7) {
                    Text(failure.title)
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .multilineTextAlignment(.center)
                    if let detail = failure.detail {
                        Text(detail)
                            .font(.system(size: 13, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.68))
                            .multilineTextAlignment(.center)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }

                if let info = license.info, let expiresDate = info.expiresDate {
                    infoPill(text: "Expirou em \(LicenseDate.medium(expiresDate))")
                }

                VStack(spacing: 10) {
                    if failure == .hwidMismatch {
                        unlinkButton
                        unlinkFeedback
                    }
                    primaryButton(title: "Usar outra key", symbol: "key.fill") {
                        license.showKeyEntry()
                    }
                }
            }
            .frame(maxWidth: .infinity)
        }
    }

    private func unavailableCard(failure: LicenseFailure) -> some View {
        LicenseGlassCard {
            VStack(spacing: 16) {
                statusIcon(symbol: failure.symbol, tint: LicensePalette.tint(for: failure))

                VStack(spacing: 7) {
                    Text(failure.title)
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .multilineTextAlignment(.center)
                    if let detail = failure.detail {
                        Text(detail)
                            .font(.system(size: 13, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.68))
                            .multilineTextAlignment(.center)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }

                VStack(spacing: 10) {
                    primaryButton(
                        title: license.isWorking ? "Verificando…" : "Tentar novamente",
                        symbol: "arrow.clockwise"
                    ) {
                        Task { await license.validateStoredKey() }
                    }
                    .disabled(license.isWorking)

                    secondaryButton(title: "Usar outra key") {
                        license.showKeyEntry()
                    }
                }
            }
            .frame(maxWidth: .infinity)
        }
    }

    private var checkingCard: some View {
        LicenseGlassCard {
            VStack(spacing: 16) {
                statusIcon(symbol: "checkmark.seal.fill", tint: LicensePalette.highlight, spinning: true)

                VStack(spacing: 7) {
                    Text("Verificando licença")
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    Text("Confirmando sua key com o servidor…")
                        .font(.system(size: 13, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.66))
                        .multilineTextAlignment(.center)
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 6)
        }
    }

    // MARK: Componentes

    private func statusIcon(symbol: String, tint: Color, spinning: Bool = false) -> some View {
        ZStack {
            Circle()
                .fill(tint.opacity(0.16))
                .frame(width: 82, height: 82)
                .blur(radius: 6)
            Circle()
                .strokeBorder(tint.opacity(0.35), lineWidth: 1)
                .frame(width: 74, height: 74)
            Image(systemName: symbol)
                .font(.system(size: 30, weight: .semibold))
                .foregroundStyle(tint)
                .symbolEffect(.pulse, isActive: spinning)
        }
        .frame(height: 88)
    }

    private func infoPill(text: String) -> some View {
        Text(text)
            .font(.system(size: 11, weight: .semibold, design: .rounded))
            .foregroundStyle(.white.opacity(0.62))
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(Capsule().fill(Color.white.opacity(0.07)))
    }

    private func primaryButton(title: String, symbol: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 9) {
                if license.isWorking {
                    ProgressView().tint(.white).scaleEffect(0.85)
                } else {
                    Image(systemName: symbol)
                        .font(.system(size: 14, weight: .bold))
                }
                Text(title)
                    .font(.system(size: 15, weight: .bold, design: .rounded))
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 52)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: LicensePalette.buttonGradient,
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .shadow(color: LicensePalette.accent.opacity(0.38), radius: 16, y: 7)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .strokeBorder(.white.opacity(0.16), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }

    private func secondaryButton(title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.86))
                .frame(maxWidth: .infinity)
                .frame(height: 48)
                .background(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .fill(Color.white.opacity(0.07))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .strokeBorder(.white.opacity(0.12), lineWidth: 1)
                )
        }
        .buttonStyle(.plain)
    }

    private func failureBanner(_ failure: LicenseFailure) -> some View {
        let tint = LicensePalette.tint(for: failure)
        return VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: failure.symbol)
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(tint)
                    .frame(width: 20)
                VStack(alignment: .leading, spacing: 3) {
                    Text(failure.title)
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    if let detail = failure.detail {
                        Text(detail)
                            .font(.system(size: 12, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.72))
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                Spacer(minLength: 0)
            }

            if failure == .hwidMismatch {
                unlinkButton
                unlinkFeedback
            }
        }
        .padding(13)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 15, style: .continuous)
                .strokeBorder(tint.opacity(0.26), lineWidth: 1)
        )
        .transition(.opacity.combined(with: .move(edge: .top)))
    }

    private func noticeBanner(_ text: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "checkmark.seal.fill")
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(LicensePalette.success)
                .frame(width: 20)
            Text(text)
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.82))
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .padding(13)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LicensePalette.success.opacity(0.12), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 15, style: .continuous)
                .strokeBorder(LicensePalette.success.opacity(0.26), lineWidth: 1)
        )
        .transition(.opacity.combined(with: .move(edge: .top)))
    }

    private var unlinkButton: some View {
        Button {
            Task { await license.requestUnlink(key: keyText) }
        } label: {
            HStack(spacing: 7) {
                if license.unlinkState == .working {
                    ProgressView().tint(.white).scaleEffect(0.75)
                } else {
                    Image(systemName: "iphone.slash")
                        .font(.system(size: 12, weight: .bold))
                }
                Text("Desvincular este aparelho")
                    .font(.system(size: 12, weight: .bold, design: .rounded))
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 13)
            .padding(.vertical, 9)
            .background(Capsule().fill(Color.white.opacity(0.12)))
            .overlay(Capsule().strokeBorder(.white.opacity(0.16), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .disabled(license.unlinkState == .working || keyText.isEmpty)
        .opacity(keyText.isEmpty ? 0.5 : 1)
    }

    @ViewBuilder
    private var unlinkFeedback: some View {
        switch license.unlinkState {
        case .success:
            Text("Aparelho desvinculado. Ative a key novamente.")
                .font(.system(size: 11, weight: .semibold, design: .rounded))
                .foregroundStyle(LicensePalette.success)
        case .failed(let message):
            Text(message)
                .font(.system(size: 11, weight: .medium, design: .rounded))
                .foregroundStyle(LicensePalette.danger)
                .fixedSize(horizontal: false, vertical: true)
        case .idle, .working:
            EmptyView()
        }
    }

    private var deviceCard: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(Color.white.opacity(0.07))
                Image(systemName: "iphone")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(LicensePalette.highlight)
            }
            .frame(width: 38, height: 38)

            VStack(alignment: .leading, spacing: 3) {
                Text("ESTE APARELHO")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(1.4)
                    .foregroundStyle(.white.opacity(0.42))
                Text(LuccheseDeviceInfo.description)
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.86))
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
                Text("HWID \(LicenseHWID.value)")
                    .font(.system(size: 9, weight: .medium, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.36))
                    .lineLimit(1)
                    .truncationMode(.middle)
            }

            Spacer(minLength: 4)

            Button {
                UIPasteboard.general.string = LicenseHWID.value
                withAnimation(.easeOut(duration: 0.2)) { copiedHWID = true }
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                Task {
                    try? await Task.sleep(nanoseconds: 1_600_000_000)
                    withAnimation(.easeOut(duration: 0.2)) { copiedHWID = false }
                }
            } label: {
                Image(systemName: copiedHWID ? "checkmark" : "doc.on.doc")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(copiedHWID ? LicensePalette.success : .white.opacity(0.55))
                    .frame(width: 34, height: 34)
                    .background(Circle().fill(Color.white.opacity(0.07)))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Copiar HWID")
        }
        .padding(13)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder(.white.opacity(0.08), lineWidth: 1)
        )
    }

    private var legalFooter: some View {
        VStack(spacing: 8) {
            Text("Sua key é vinculada a este aparelho no primeiro uso.")
            HStack(spacing: 4) {
                Text("Suporte")
                    .foregroundStyle(.white.opacity(0.38))
                Text("@lucchese")
                    .foregroundStyle(LicensePalette.highlight)
            }
        }
        .font(.system(size: 11, weight: .semibold, design: .rounded))
        .multilineTextAlignment(.center)
        .padding(.top, 4)
    }

    // MARK: Ações

    private func submit() {
        guard !license.isWorking else { return }
        isKeyFocused = false
        let key = LicenseManager.normalize(keyText)
        Task { await license.activate(rawKey: key) }
    }

    private func pasteKey() {
        guard let raw = UIPasteboard.general.string else { return }
        let normalized = LicenseManager.normalize(raw)
        guard !normalized.isEmpty else { return }
        keyText = normalized
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }
}

// MARK: - Celebração de ativação

struct LicenseUnlockCelebration: View {
    let info: LicenseInfo

    @State private var pop = false

    private var subtitle: String {
        var parts: [String] = []
        if let planDays = info.planDays {
            parts.append(planDays == 1 ? "Plano de 1 dia" : "Plano de \(planDays) dias")
        }
        if let expiresDate = info.expiresDate {
            parts.append("até \(LicenseDate.medium(expiresDate))")
        }
        return parts.isEmpty ? "Bem-vindo de volta" : parts.joined(separator: " · ")
    }

    var body: some View {
        ZStack {
            Rectangle()
                .fill(.ultraThinMaterial)
                .background(Color.black.opacity(0.32))
                .ignoresSafeArea()

            VStack(spacing: 18) {
                ZStack {
                    Circle()
                        .fill(LicensePalette.success.opacity(0.20))
                        .frame(width: 108, height: 108)
                        .scaleEffect(pop ? 1 : 0.6)
                        .blur(radius: pop ? 2 : 10)
                    Circle()
                        .strokeBorder(LicensePalette.success.opacity(0.5), lineWidth: 1.5)
                        .frame(width: 92, height: 92)
                        .scaleEffect(pop ? 1 : 0.85)
                    Image(systemName: "checkmark")
                        .font(.system(size: 36, weight: .bold))
                        .foregroundStyle(.white)
                        .shadow(color: LicensePalette.success.opacity(0.85), radius: 14)
                        .scaleEffect(pop ? 1 : 0.7)
                }

                VStack(spacing: 7) {
                    Text("LICENÇA ATIVADA")
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .tracking(2.8)
                        .foregroundStyle(.white)
                    Text(subtitle)
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.72))
                        .multilineTextAlignment(.center)
                }
            }
            .padding(.horizontal, 30)
            .padding(.vertical, 32)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .strokeBorder(.white.opacity(0.14), lineWidth: 1)
            )
            .shadow(color: LicensePalette.success.opacity(0.22), radius: 30, y: 10)
            .padding(.horizontal, 44)
            .scaleEffect(pop ? 1 : 0.92)
        }
        .allowsHitTesting(false)
        .onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.62)) { pop = true }
        }
    }
}
