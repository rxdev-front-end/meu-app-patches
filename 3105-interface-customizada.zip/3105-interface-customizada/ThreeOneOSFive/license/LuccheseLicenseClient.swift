import Foundation
import Security
import UIKit

// MARK: - Configuração

/// Configuração da API de licenças (LuccKeys Control).
///
/// A URL e a credencial vivem no `Info.plist` para poderem ser trocadas sem
/// recompilar a lógica do app. O app é o cliente final, então a credencial
/// `x-api-key` precisa acompanhar o binário.
enum LuccheseLicenseConfiguration {
    /// Base HTTPS da API de licenças. Ex.: `https://host/api/license`.
    static let baseURL: URL? = {
        guard let raw = Bundle.main.object(forInfoDictionaryKey: "LUCCHESE_LICENSE_API_BASE_URL") as? String else {
            return nil
        }
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty,
              let url = URL(string: value),
              let components = URLComponents(url: url, resolvingAgainstBaseURL: false),
              components.scheme?.lowercased() == "https",
              components.host != nil,
              components.user == nil,
              components.password == nil,
              components.query == nil,
              components.fragment == nil else {
            return nil
        }
        return url
    }()

    /// Credencial da aplicação, enviada no header `x-api-key`.
    static let apiKey: String = {
        let raw = Bundle.main.object(forInfoDictionaryKey: "LUCCHESE_LICENSE_API_KEY") as? String ?? ""
        return raw.trimmingCharacters(in: .whitespacesAndNewlines)
    }()

    /// Tolerância offline em segundos. A API não gerencia modo offline,
    /// então o controle é feito aqui no cliente.
    static let offlineGrace: TimeInterval = {
        let raw = Bundle.main.object(forInfoDictionaryKey: "LUCCHESE_LICENSE_OFFLINE_GRACE_MINUTES")
        let minutes: Double
        if let number = raw as? NSNumber {
            minutes = number.doubleValue
        } else if let text = raw as? String, let parsed = Double(text) {
            minutes = parsed
        } else {
            minutes = 15
        }
        return max(0, minutes) * 60
    }()
}

// MARK: - Modelo

/// Licença devolvida pela API (`license` do envelope JSON).
struct LicenseInfo: Codable, Equatable {
    var status: String
    var planDays: Int?
    var expiresAt: String?
    /// Preenchido pelo app no momento da verificação bem-sucedida.
    var validatedAt: Date?

    var isActive: Bool { status.lowercased() == "active" }

    var expiresDate: Date? {
        guard let expiresAt else { return nil }
        return LicenseDate.parse(expiresAt)
    }

    var isExpired: Bool {
        guard let expiresDate else { return false }
        return expiresDate <= Date()
    }

    /// Dias inteiros restantes (arredondado para cima).
    var daysRemaining: Int? {
        guard let expiresDate else { return nil }
        let seconds = expiresDate.timeIntervalSinceNow
        if seconds <= 0 { return 0 }
        return Int(ceil(seconds / 86_400))
    }

    func isWithinGrace(_ seconds: TimeInterval, now: Date = Date()) -> Bool {
        guard let validatedAt else { return false }
        return now.timeIntervalSince(validatedAt) <= seconds
    }
}

enum LicenseDate {
    private static let withFractionalSeconds: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter
    }()

    private static let plain: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter
    }()

    static func parse(_ raw: String) -> Date? {
        withFractionalSeconds.date(from: raw) ?? plain.date(from: raw)
    }

    static func medium(_ date: Date) -> String {
        date.formatted(date: .abbreviated, time: .shortened)
    }
}

// MARK: - Falhas

enum LicenseFailure: Error, Equatable {
    case notConfigured
    case invalidAPIKey
    case keyNotFound
    case keyExpired
    case keyRevoked
    case hwidMismatch
    case inactive(status: String?)
    case rateLimited(retryAfter: TimeInterval)
    case serverError
    case offline
    case invalidResponse
    case emptyKey

    var title: String {
        switch self {
        case .notConfigured: return "API não configurada"
        case .invalidAPIKey: return "Credencial inválida"
        case .keyNotFound: return "Key não encontrada"
        case .keyExpired: return "Key expirada"
        case .keyRevoked: return "Key revogada"
        case .hwidMismatch: return "Key em outro aparelho"
        case .inactive: return "Licença inativa"
        case .rateLimited: return "Muitas tentativas"
        case .serverError: return "Servidor indisponível"
        case .offline: return "Sem conexão"
        case .invalidResponse: return "Resposta inesperada"
        case .emptyKey: return "Digite sua key"
        }
    }

    var detail: String? {
        switch self {
        case .notConfigured:
            return "A URL ou a credencial da API de licenças não está configurada neste build."
        case .invalidAPIKey:
            return "O app não conseguiu se autenticar no servidor de licenças. Fale com o suporte."
        case .keyNotFound:
            return "Essa key não existe. Confira os caracteres e tente novamente."
        case .keyExpired:
            return "A validade desta key terminou. Renove com o suporte e ative a nova key."
        case .keyRevoked:
            return "Esta key foi revogada e não pode mais ser usada."
        case .hwidMismatch:
            return "Esta key já está vinculada a outro aparelho. Peça a desvinculação ao suporte."
        case .inactive(let status):
            return "O status atual da licença é “\(status ?? "desconhecido")”."
        case .rateLimited(let retryAfter):
            let seconds = max(1, Int(retryAfter.rounded()))
            return "Aguarde \(seconds)s antes de tentar novamente."
        case .serverError:
            return "Falha temporária no servidor de licenças. Tente novamente em instantes."
        case .offline:
            return "Não foi possível falar com o servidor de licenças. Verifique sua internet."
        case .invalidResponse:
            return "O servidor retornou uma resposta que o app não reconhece."
        case .emptyKey:
            return "Cole a key que você recebeu para continuar."
        }
    }

    var symbol: String {
        switch self {
        case .notConfigured: return "exclamationmark.triangle.fill"
        case .invalidAPIKey: return "lock.slash.fill"
        case .keyNotFound: return "questionmark.circle.fill"
        case .keyExpired: return "clock.badge.exclamationmark"
        case .keyRevoked: return "xmark.shield.fill"
        case .hwidMismatch: return "iphone.slash"
        case .inactive: return "pause.circle.fill"
        case .rateLimited: return "hourglass"
        case .serverError: return "exclamationmark.icloud.fill"
        case .offline: return "wifi.slash"
        case .invalidResponse: return "exclamationmark.triangle.fill"
        case .emptyKey: return "key.fill"
        }
    }

    /// Falhas que bloqueiam a key em si (não adianta só tentar de novo).
    var isDefinitive: Bool {
        switch self {
        case .keyNotFound, .keyExpired, .keyRevoked, .hwidMismatch, .inactive:
            return true
        case .notConfigured, .invalidAPIKey, .rateLimited, .serverError, .offline, .invalidResponse, .emptyKey:
            return false
        }
    }

    var isConnectivityIssue: Bool {
        switch self {
        case .offline, .serverError, .invalidResponse, .rateLimited:
            return true
        case .notConfigured, .invalidAPIKey, .keyNotFound, .keyExpired, .keyRevoked, .hwidMismatch, .inactive, .emptyKey:
            return false
        }
    }

    static func from(statusCode: Int, code: String?, retryAfter: TimeInterval?) -> LicenseFailure {
        switch code {
        case "invalid_api_key": return .invalidAPIKey
        case "hwid_mismatch": return .hwidMismatch
        case "key_expired": return .keyExpired
        case "key_revoked": return .keyRevoked
        case "key_not_found": return .keyNotFound
        case "rate_limited": return .rateLimited(retryAfter: retryAfter ?? 60)
        case "internal_error": return .serverError
        default: break
        }
        switch statusCode {
        case 401: return .invalidAPIKey
        case 404: return .keyNotFound
        case 429: return .rateLimited(retryAfter: retryAfter ?? 60)
        default: return .serverError
        }
    }
}

// MARK: - Cliente HTTP

struct LuccheseLicenseClient {
    private let urlSession: URLSession

    init(urlSession: URLSession? = nil) {
        if let urlSession {
            self.urlSession = urlSession
            return
        }
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 40
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.waitsForConnectivity = false
        self.urlSession = URLSession(configuration: configuration)
    }

    private struct Envelope: Decodable {
        let ok: Bool?
        let code: String?
        let message: String?
        let license: LicenseInfo?
    }

    func activate(key: String, hwid: String) async throws -> LicenseInfo {
        let envelope = try await send(
            path: "activate",
            method: "POST",
            body: ["key": key, "hwid": hwid]
        )
        return try license(from: envelope)
    }

    func validate(key: String, hwid: String) async throws -> LicenseInfo {
        let envelope = try await send(
            path: "validate",
            method: "POST",
            body: ["key": key, "hwid": hwid]
        )
        return try license(from: envelope)
    }

    func status(key: String, hwid: String) async throws -> LicenseInfo {
        let envelope = try await send(
            path: "status",
            method: "GET",
            query: ["key": key, "hwid": hwid]
        )
        return try license(from: envelope)
    }

    func unlinkHWID(key: String, hwid: String) async throws {
        _ = try await send(
            path: "unlink-hwid",
            method: "POST",
            body: ["key": key, "hwid": hwid]
        )
    }

    // MARK: Internos

    private func license(from envelope: Envelope) throws -> LicenseInfo {
        guard var info = envelope.license else { throw LicenseFailure.invalidResponse }
        guard info.isActive else { throw LicenseFailure.inactive(status: info.status) }
        info.validatedAt = Date()
        return info
    }

    @discardableResult
    private func send(
        path: String,
        method: String,
        body: [String: String]? = nil,
        query: [String: String]? = nil
    ) async throws -> Envelope {
        guard let baseURL = LuccheseLicenseConfiguration.baseURL,
              !LuccheseLicenseConfiguration.apiKey.isEmpty else {
            throw LicenseFailure.notConfigured
        }

        var components = URLComponents(
            url: baseURL.appendingPathComponent(path),
            resolvingAgainstBaseURL: false
        )
        if let query {
            components?.queryItems = query.map { URLQueryItem(name: $0.key, value: $0.value) }
        }
        guard let url = components?.url else { throw LicenseFailure.invalidResponse }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(LuccheseLicenseConfiguration.apiKey, forHTTPHeaderField: "x-api-key")
        request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
        if let body {
            request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [])
        }

        let result: (Data, URLResponse)
        do {
            result = try await urlSession.data(for: request)
        } catch let failure as LicenseFailure {
            throw failure
        } catch {
            throw LicenseFailure.offline
        }
        let data = result.0
        let response = result.1

        guard let http = response as? HTTPURLResponse else {
            throw LicenseFailure.invalidResponse
        }

        let envelope = try? JSONDecoder().decode(Envelope.self, from: data)

        guard http.statusCode == 200, envelope?.ok == true else {
            throw LicenseFailure.from(
                statusCode: http.statusCode,
                code: envelope?.code,
                retryAfter: retryAfter(from: http)
            )
        }

        guard let envelope else { throw LicenseFailure.invalidResponse }
        return envelope
    }

    private func retryAfter(from response: HTTPURLResponse) -> TimeInterval? {
        for header in ["Retry-After", "x-ratelimit-reset"] {
            guard let raw = response.value(forHTTPHeaderField: header) else { continue }
            let trimmed = raw.trimmingCharacters(in: .whitespaces)
            if let seconds = TimeInterval(trimmed) {
                return max(1, seconds)
            }
        }
        return nil
    }
}

// MARK: - Keychain

/// Guarda a key da licença e o HWID no Keychain (sobrevive à reinstalação).
enum LicenseKeychain {
    private static let service = "com.lucchese.store.license"
    private static let keyAccount = "license.key"

    static func readKey() -> String? {
        read(account: keyAccount)
    }

    static func saveKey(_ key: String) {
        write(key, account: keyAccount)
    }

    static func deleteKey() {
        delete(account: keyAccount)
    }

    static func read(account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data,
              let value = String(data: data, encoding: .utf8),
              !value.isEmpty else {
            return nil
        }
        return value
    }

    static func write(_ value: String, account: String) {
        guard let data = value.data(using: .utf8) else { return }
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        let attributes: [String: Any] = [
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        if SecItemUpdate(query as CFDictionary, attributes as CFDictionary) == errSecSuccess {
            return
        }
        var item = query
        attributes.forEach { item[$0.key] = $0.value }
        SecItemAdd(item as CFDictionary, nil)
    }

    static func delete(account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
}

// MARK: - HWID

/// Identificador estável do aparelho. Usa `identifierForVendor` na primeira
/// leitura e depois persiste no Keychain, para não mudar se o IDFV mudar.
enum LicenseHWID {
    private static let account = "device.hwid"

    static let value: String = {
        if let stored = LicenseKeychain.read(account: account) {
            return stored
        }
        let raw = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        let normalized = raw.uppercased()
        LicenseKeychain.write(normalized, account: account)
        return normalized
    }()

    static var short: String {
        let current = value
        guard current.count > 10 else { return current }
        return "…" + current.suffix(8)
    }
}
