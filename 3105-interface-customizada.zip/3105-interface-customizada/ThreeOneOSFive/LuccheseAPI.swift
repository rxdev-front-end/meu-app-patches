import Combine
import Foundation
import UIKit

/// A URL HTTPS é lida do Info.plist; o host reservado só responderá após publicação autorizada.
enum LuccheseAPIConfiguration {
    static let baseURL: URL? = {
        guard let raw = Bundle.main.object(forInfoDictionaryKey: "LUCCHESE_API_BASE_URL") as? String else {
            return nil
        }
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty,
              let url = URL(string: value),
              let components = URLComponents(url: url, resolvingAgainstBaseURL: false),
              components.scheme?.lowercased() == "https",
              components.host != nil,
              components.user == nil,
              components.password == nil,
              components.query == nil,
              components.fragment == nil,
              components.path.isEmpty || components.path == "/" else {
            return nil
        }
        return url
    }()

    static let allowedDownloadHosts: Set<String> = {
        let raw = Bundle.main.object(forInfoDictionaryKey: "LUCCHESE_API_ALLOWED_DOWNLOAD_HOSTS") as? String ?? ""
        return Set(raw.split(separator: ",").map {
            $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        }.filter { !$0.isEmpty })
    }()
}

enum LucchesePatchStatus: String, Codable {
    case ativo
    case atualizando
    case desativado
}

struct LuccheseRemoteCategory: Codable, Identifiable, Equatable {
    let id: String
    let name: String
    let sortOrder: Int
}

struct LuccheseRemotePatch: Codable, Identifiable {
    let id: String
    let name: String
    let categoryId: String?
    let note: String?
    let status: LucchesePatchStatus
    let risk: Bool
    let fileURL: String
}

enum LucchesePatchImportState: Equatable {
    case downloading
    case importing
    case incompatibleFormat
    case passwordProtected
    case failed
}

struct LuccheseCatalog: Decodable {
    let categories: [LuccheseRemoteCategory]?
    let patches: [LuccheseRemotePatch]
}

private enum LuccheseCatalogDefaults {
    static let categories = [
        LuccheseRemoteCategory(id: "normal", name: "Normal", sortOrder: 0),
        LuccheseRemoteCategory(id: "texturas", name: "Texturas", sortOrder: 1),
        LuccheseRemoteCategory(id: "outros", name: "Outros", sortOrder: 2)
    ]
}

struct LuccheseAnnouncement: Codable, Identifiable {
    let id: String
    let title: String
    let message: String
    let createdAt: String
}

private struct LuccheseAnnouncements: Codable {
    let announcements: [LuccheseAnnouncement]
}

enum LuccheseAPIError: Error {
    case notConfigured
    case badResponse
    case missingPatch
}

enum LuccheseActivationBlock: String, Equatable {
    case unsupportedIOS = "ios.unsupported.exact"
    case anotherPatchActive = "patch.remote.another-active"
    case remoteUnavailable = "patch.remote.unavailable"
    case remoteInactive = "patch.remote.inactive"

    var message: String {
        switch self {
        case .unsupportedIOS: return "Versão do iOS não suportada"
        case .anotherPatchActive: return "Desative e restaure o patch ativo antes de ativar outro."
        case .remoteUnavailable: return "Não foi possível validar o catálogo remoto. Tente novamente."
        case .remoteInactive: return "Este patch não está ativo no catálogo remoto."
        }
    }
}

@MainActor
enum LuccheseActivationPolicy {
    static func blockReason(
        for projectID: UUID,
        remoteID: String? = nil,
        api: LuccheseAPI,
        store: PatchProjectStore
    ) async -> LuccheseActivationBlock? {
        guard LuccheseAPI.isIOSSupported else { return .unsupportedIOS }
        if store.items.contains(where: { item in
            item.id != projectID && DevicePatchService.latestReceipt(projectID: item.id) != nil
        }) {
            return .anotherPatchActive
        }
        let resolvedRemoteID = remoteID ?? api.mappings.first(where: {
            UUID(uuidString: $0.value) == projectID
        })?.key
        guard let resolvedRemoteID else { return .remoteUnavailable }
        let status = await api.currentStatus(remoteID: resolvedRemoteID)
        guard status == .ativo else {
            return api.networkAvailable ? .remoteInactive : .remoteUnavailable
        }
        return nil
    }
}

@MainActor
final class LuccheseAPI: ObservableObject {
    private static let catalogCacheKey = "Lucchese.remoteCatalog.v1"
    private static let categoriesCacheKey = "Lucchese.remoteCategories.v1"
    private static let announcementsCacheKey = "Lucchese.remoteAnnouncements.v1"

    @Published private(set) var catalog: [LuccheseRemotePatch] = []
    @Published private(set) var categories: [LuccheseRemoteCategory] = LuccheseCatalogDefaults.categories
    @Published private(set) var announcements: [LuccheseAnnouncement] = []
    @Published private(set) var lastSync: Date?
    @Published private(set) var networkAvailable = false
    @Published private(set) var isRefreshing = false
    @Published private(set) var isSynchronizing = false
    @Published private(set) var errorMessage: String?
    @Published private(set) var mappings: [String: String] =
        UserDefaults.standard.dictionary(forKey: "Lucchese.remotePatchUUIDMap.v1") as? [String: String] ?? [:]
    @Published private(set) var automaticImportPackageID: UUID?
    @Published private(set) var patchImportStates: [String: LucchesePatchImportState] = [:]

    private let session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 30
        configuration.timeoutIntervalForResource = 180
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        return URLSession(configuration: configuration)
    }()

    private var baseURL: URL? { LuccheseAPIConfiguration.baseURL }

    init() {
        let defaults = UserDefaults.standard
        if let data = defaults.data(forKey: Self.catalogCacheKey),
           let cached = try? JSONDecoder().decode([LuccheseRemotePatch].self, from: data) {
            catalog = cached
        }
        if let data = defaults.data(forKey: Self.categoriesCacheKey),
           let cached = try? JSONDecoder().decode([LuccheseRemoteCategory].self, from: data),
           !cached.isEmpty {
            categories = cached.sorted { lhs, rhs in
                lhs.sortOrder == rhs.sortOrder ? lhs.id < rhs.id : lhs.sortOrder < rhs.sortOrder
            }
        }
        if let data = defaults.data(forKey: Self.announcementsCacheKey),
           let cached = try? JSONDecoder().decode(LuccheseAnnouncements.self, from: data) {
            announcements = cached.announcements
        }
    }

    func refresh() async {
        isRefreshing = true
        defer { isRefreshing = false }
        do {
            guard let baseURL else { throw LuccheseAPIError.notConfigured }
            let requestURL = baseURL.appendingPathComponent("api/mobile/catalog")
            var request = URLRequest(url: requestURL)
            request.cachePolicy = .reloadIgnoringLocalCacheData
            request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
            let (data, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse,
                  (200..<300).contains(http.statusCode) else {
                throw LuccheseAPIError.badResponse
            }
            let responseCatalog = try JSONDecoder().decode(LuccheseCatalog.self, from: data)
            let fresh = responseCatalog.patches
            let orderedCategories = (responseCatalog.categories ?? LuccheseCatalogDefaults.categories).sorted { lhs, rhs in
                lhs.sortOrder == rhs.sortOrder ? lhs.id < rhs.id : lhs.sortOrder < rhs.sortOrder
            }
            let freshCategories = orderedCategories.isEmpty ? LuccheseCatalogDefaults.categories : orderedCategories
            catalog = fresh
            categories = freshCategories
            if let cache = try? JSONEncoder().encode(fresh) {
                UserDefaults.standard.set(cache, forKey: Self.catalogCacheKey)
            }
            if let categoryCache = try? JSONEncoder().encode(freshCategories) {
                UserDefaults.standard.set(categoryCache, forKey: Self.categoriesCacheKey)
            }
            networkAvailable = true
            lastSync = Date()
            errorMessage = nil
        } catch {
            networkAvailable = false
            errorMessage = baseURL == nil ? "API ainda não configurada" : "Não foi possível atualizar o catálogo"
            return // Falha fechada: uma resposta incompleta nunca reconcilia nem apaga o cache.
        }
    }

    func refreshAnnouncements() async {
        guard let baseURL else { return }
        do {
            let requestURL = baseURL.appendingPathComponent("api/mobile/announcements")
            var request = URLRequest(url: requestURL)
            request.cachePolicy = .reloadIgnoringLocalCacheData
            request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
            let (data, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse,
                  (200..<300).contains(http.statusCode) else { return }
            let fresh = try JSONDecoder().decode(LuccheseAnnouncements.self, from: data).announcements
            announcements = fresh
            if let cache = try? JSONEncoder().encode(LuccheseAnnouncements(announcements: fresh)) {
                UserDefaults.standard.set(cache, forKey: Self.announcementsCacheKey)
            }
        } catch {
            // O último conjunto de avisos continua visível quando a rede falha.
        }
    }

    func currentStatus(remoteID: String) async -> LucchesePatchStatus? {
        await refresh()
        guard networkAvailable else { return nil }
        return catalog.first(where: { $0.id == remoteID })?.status
    }

    func setSynchronizing(_ value: Bool) {
        isSynchronizing = value
    }

    func setPatchImportState(_ state: LucchesePatchImportState?, remoteID: String) {
        if let state {
            patchImportStates[remoteID] = state
        } else {
            patchImportStates.removeValue(forKey: remoteID)
        }
    }

    func retainPatchImportStates(for remoteIDs: Set<String>) {
        patchImportStates = patchImportStates.filter { remoteIDs.contains($0.key) }
    }

    func failInProgressPatchImports() {
        let inProgressIDs = patchImportStates.compactMap { remoteID, state in
            state == .downloading || state == .importing ? remoteID : nil
        }
        for remoteID in inProgressIDs {
            patchImportStates[remoteID] = .failed
        }
    }

    func download(_ patch: LuccheseRemotePatch) async throws -> Data {
        guard let baseURL, let baseHost = baseURL.host else {
            throw LuccheseAPIError.notConfigured
        }
        let fileURL = URL(string: patch.fileURL, relativeTo: baseURL)?.absoluteURL
        guard let fileURL,
              fileURL.scheme?.lowercased() == "https",
              fileURL.host == baseHost else {
            throw LuccheseAPIError.badResponse
        }
        let (data, response) = try await session.data(from: fileURL)
        guard let http = response as? HTTPURLResponse,
              let finalURL = http.url,
              let finalHost = finalURL.host?.lowercased(),
              (200..<300).contains(http.statusCode),
              finalURL.scheme?.lowercased() == "https",
              finalHost == baseHost.lowercased() || LuccheseAPIConfiguration.allowedDownloadHosts.contains(finalHost),
              !data.isEmpty,
              data.count <= 25 * 1024 * 1024 else {
            throw LuccheseAPIError.badResponse
        }
        return data
    }

    func associate(remoteID: String, internalID: UUID) {
        mappings[remoteID] = internalID.uuidString
        UserDefaults.standard.set(mappings, forKey: "Lucchese.remotePatchUUIDMap.v1")
    }

    func internalID(for remoteID: String) -> UUID? {
        mappings[remoteID].flatMap(UUID.init(uuidString:))
    }

    func clearMapping(remoteID: String) {
        mappings.removeValue(forKey: remoteID)
        UserDefaults.standard.set(mappings, forKey: "Lucchese.remotePatchUUIDMap.v1")
    }

    func markAutomaticImportStarted(packageID: UUID) {
        automaticImportPackageID = packageID
    }

    func consumeAutomaticImportSuccessAlert() -> Bool {
        guard automaticImportPackageID != nil else { return false }
        automaticImportPackageID = nil
        return true
    }

    func clearAutomaticImportIfMissing(installedIDs: Set<UUID>) {
        guard let automaticImportPackageID,
              !installedIDs.contains(automaticImportPackageID) else { return }
        self.automaticImportPackageID = nil
    }

    func clearAutomaticImport(packageID: UUID) {
        guard automaticImportPackageID == packageID else { return }
        automaticImportPackageID = nil
    }

    static var deviceDescription: String {
        LuccheseDeviceInfo.description
    }

    static var isIOSSupported: Bool {
        let version = ProcessInfo.processInfo.operatingSystemVersion
        return (version.majorVersion == 17 && (0...7).contains(version.minorVersion)) ||
            (version.majorVersion == 26 && ((0...5).contains(version.minorVersion) ||
                (version.minorVersion == 6 && version.patchVersion <= 2)))
    }
}
