import Foundation
import UIKit

@MainActor
enum LuccheseCatalogSync {
    private static var synchronizationInProgress = false
    private static var retryAttempts: [String: Int] = [:]
    private static var retryAfter: [String: Date] = [:]

    static func synchronize(api: LuccheseAPI, store: PatchProjectStore) async {
        guard !synchronizationInProgress else { return }
        synchronizationInProgress = true
        api.setSynchronizing(true)
        defer {
            synchronizationInProgress = false
            api.setSynchronizing(false)
        }

        // O store carrega o catálogo local em background na inicialização.
        guard await waitForStoreToBecomeIdle(store) else {
            api.failInProgressPatchImports()
            return
        }
        await api.refresh()
        guard api.networkAvailable else {
            api.failInProgressPatchImports()
            return
        }
        guard await waitForStoreToBecomeIdle(store) else {
            api.failInProgressPatchImports()
            return
        }

        let remoteIDs = Set(api.catalog.map(\.id))
        api.retainPatchImportStates(for: remoteIDs)
        retryAfter = retryAfter.filter { remoteIDs.contains($0.key) }
        retryAttempts = retryAttempts.filter { remoteIDs.contains($0.key) }
        for (remoteID, uuidString) in Array(api.mappings) where !remoteIDs.contains(remoteID) {
            guard let id = UUID(uuidString: uuidString) else {
                api.clearMapping(remoteID: remoteID)
                continue
            }

            guard let item = store.items.first(where: { $0.id == id }) else {
                api.clearMapping(remoteID: remoteID)
                continue
            }

            // A remoção remota bloqueia novas ativações, mas não apaga o que é necessário
            // para restaurar arquivos ainda modificados no aparelho.
            if DevicePatchService.latestReceipt(projectID: id) != nil { continue }

            store.delete(item)
            if !store.items.contains(where: { $0.id == id }) {
                api.clearMapping(remoteID: remoteID)
            }
        }

        for remote in api.catalog {
            guard remote.status == .ativo else {
                api.setPatchImportState(nil, remoteID: remote.id)
                continue
            }

            if let localID = api.internalID(for: remote.id),
               store.items.contains(where: { $0.id == localID }) {
                markSuccess(remoteID: remote.id)
                api.setPatchImportState(nil, remoteID: remote.id)
                continue
            }

            // Falhas ficam visíveis enquanto aguardam o backoff; não iniciam outra tentativa
            // em cada ciclo de 15 segundos do aplicativo.
            guard (retryAfter[remote.id] ?? .distantPast) <= Date() else { continue }
            api.setPatchImportState(.downloading, remoteID: remote.id)

            do {
                let data = try await api.download(remote)
                let summary = try PatchPackageCodec.inspect(data)

                // A loja distribui apenas pacotes sem senha. Pacotes protegidos não são
                // enviados ao fluxo de importação/desbloqueio.
                if summary.isPasswordProtected {
                    api.clearAutomaticImport(packageID: summary.packageID)
                    api.clearMapping(remoteID: remote.id)
                    markFailure(remoteID: remote.id)
                    api.setPatchImportState(.passwordProtected, remoteID: remote.id)
                    continue
                }

                if store.items.contains(where: { $0.id == summary.packageID }) {
                    api.associate(remoteID: remote.id, internalID: summary.packageID)
                    markSuccess(remoteID: remote.id)
                    api.setPatchImportState(nil, remoteID: remote.id)
                    continue
                }

                api.associate(remoteID: remote.id, internalID: summary.packageID)
                api.markAutomaticImportStarted(packageID: summary.packageID)
                api.setPatchImportState(.importing, remoteID: remote.id)
                guard await waitForStoreToBecomeIdle(store),
                      store.importPackage(
                        data: data,
                        allowAlternativeTargetOverlap: true
                      ) else {
                    api.clearAutomaticImport(packageID: summary.packageID)
                    api.clearMapping(remoteID: remote.id)
                    markFailure(remoteID: remote.id)
                    api.setPatchImportState(.failed, remoteID: remote.id)
                    continue
                }

                let imported = await waitForImportToFinish(
                    packageID: summary.packageID,
                    store: store
                )
                if imported {
                    markSuccess(remoteID: remote.id)
                    api.setPatchImportState(nil, remoteID: remote.id)
                } else {
                    api.clearAutomaticImport(packageID: summary.packageID)
                    if !store.items.contains(where: { $0.id == summary.packageID }) {
                        api.clearMapping(remoteID: remote.id)
                    }
                    markFailure(remoteID: remote.id)
                    api.setPatchImportState(.failed, remoteID: remote.id)
                }
            } catch let error as PatchPackageError {
                markFailure(remoteID: remote.id)
                let state: LucchesePatchImportState =
                    error == .unsupportedFormat || error == .unsupportedVersion
                    ? .incompatibleFormat
                    : .failed
                api.setPatchImportState(state, remoteID: remote.id)
            } catch {
                markFailure(remoteID: remote.id)
                api.setPatchImportState(.failed, remoteID: remote.id)
            }
        }
    }

    private static func markFailure(remoteID: String) {
        let attempts = min((retryAttempts[remoteID] ?? 0) + 1, 10)
        retryAttempts[remoteID] = attempts
        let delay = min(15.0 * pow(2.0, Double(attempts - 1)), 900.0)
        retryAfter[remoteID] = Date().addingTimeInterval(delay)
    }

    private static func markSuccess(remoteID: String) {
        retryAttempts.removeValue(forKey: remoteID)
        retryAfter.removeValue(forKey: remoteID)
    }

    static func removeOrphanAfterRestore(remoteID: String, api: LuccheseAPI, store: PatchProjectStore) {
        guard let id = api.internalID(for: remoteID),
              DevicePatchService.latestReceipt(projectID: id) == nil,
              let item = store.items.first(where: { $0.id == id }) else { return }
        store.delete(item)
        if !store.items.contains(where: { $0.id == id }) {
            api.clearMapping(remoteID: remoteID)
        }
    }

    private static func waitForStoreToBecomeIdle(_ store: PatchProjectStore) async -> Bool {
        let deadline = Date().addingTimeInterval(60)
        while store.isBusy && Date() < deadline {
            try? await Task.sleep(nanoseconds: 100_000_000)
        }
        return !store.isBusy
    }

    private static func waitForImportToFinish(packageID: UUID, store: PatchProjectStore) async -> Bool {
        let deadline = Date().addingTimeInterval(60)
        while Date() < deadline {
            if store.items.contains(where: { $0.id == packageID }) { return true }
            if !store.isBusy { return false }
            try? await Task.sleep(nanoseconds: 100_000_000)
        }
        return store.items.contains(where: { $0.id == packageID })
    }
}

enum LuccheseDeviceInfo {
    static var description: String {
        let hardware = AppInfo.displayMachineName
        let model = models[hardware] ?? (hardware.hasPrefix("iPhone") ? "iPhone (\(hardware))" : hardware)
        return "iOS \(UIDevice.current.systemVersion) · \(model)"
    }

    private static let models: [String: String] = [
        "iPhone6,1": "iPhone 5s", "iPhone6,2": "iPhone 5s",
        "iPhone7,1": "iPhone 6 Plus", "iPhone7,2": "iPhone 6",
        "iPhone8,1": "iPhone 6s", "iPhone8,2": "iPhone 6s Plus", "iPhone8,4": "iPhone SE (1ª geração)",
        "iPhone9,1": "iPhone 7", "iPhone9,2": "iPhone 7 Plus", "iPhone9,3": "iPhone 7", "iPhone9,4": "iPhone 7 Plus",
        "iPhone10,1": "iPhone 8", "iPhone10,2": "iPhone 8 Plus", "iPhone10,3": "iPhone X", "iPhone10,4": "iPhone 8", "iPhone10,5": "iPhone 8 Plus", "iPhone10,6": "iPhone X",
        "iPhone11,2": "iPhone XS", "iPhone11,4": "iPhone XS Max", "iPhone11,6": "iPhone XS Max", "iPhone11,8": "iPhone XR",
        "iPhone12,1": "iPhone 11", "iPhone12,3": "iPhone 11 Pro", "iPhone12,5": "iPhone 11 Pro Max", "iPhone12,8": "iPhone SE (2ª geração)",
        "iPhone13,1": "iPhone 12 mini", "iPhone13,2": "iPhone 12", "iPhone13,3": "iPhone 12 Pro", "iPhone13,4": "iPhone 12 Pro Max",
        "iPhone14,2": "iPhone 13 Pro", "iPhone14,3": "iPhone 13 Pro Max", "iPhone14,4": "iPhone 13 mini", "iPhone14,5": "iPhone 13", "iPhone14,6": "iPhone SE (3ª geração)",
        "iPhone14,7": "iPhone 14", "iPhone14,8": "iPhone 14 Plus",
        "iPhone15,2": "iPhone 14 Pro", "iPhone15,3": "iPhone 14 Pro Max", "iPhone15,4": "iPhone 15", "iPhone15,5": "iPhone 15 Plus",
        "iPhone16,1": "iPhone 15 Pro", "iPhone16,2": "iPhone 15 Pro Max",
        "iPhone17,1": "iPhone 16 Pro", "iPhone17,2": "iPhone 16 Pro Max", "iPhone17,3": "iPhone 16", "iPhone17,4": "iPhone 16 Plus", "iPhone17,5": "iPhone 16e",
        "iPhone18,1": "iPhone 17 Pro", "iPhone18,2": "iPhone 17 Pro Max", "iPhone18,3": "iPhone 17", "iPhone18,4": "iPhone Air"
    ]
}
