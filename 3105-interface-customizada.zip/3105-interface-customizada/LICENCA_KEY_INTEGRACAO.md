# Interface de key (LuccKeys) — 3105 / Lucchese Store

Este pacote entrega o app 3105 com uma tela de ativação por key na identidade visual do
app (fundo navy com brilhos azuis, cartões de vidro, tipografia arredondada) e com o
fluxo completo de licença já conectado à API **LuccKeys Control**.

![Tela de key, confirmação de ativação e painel de licença](docs/preview-licenca-key.png)

*(Prévia de design renderizada a partir do layout implementado — a versão final roda em
SwiftUI no aparelho.)*

## O que foi adicionado

| Arquivo | Função |
| --- | --- |
| `ThreeOneOSFive/license/LuccheseLicenseClient.swift` | Cliente HTTPS da API (`/activate`, `/validate`, `/status`, `/unlink-hwid`), modelo da licença, dicionário de erros, Keychain e HWID |
| `ThreeOneOSFive/license/LicenseManager.swift` | Máquina de estados da licença: ativação, validação de rotina, bloqueio, tolerância offline e heartbeat |
| `ThreeOneOSFive/license/LicenseGateView.swift` | Tela de key (formulário, estados de bloqueio, HWID do aparelho) e animação de licença ativada |
| `ThreeOneOSFive/license/LicenseDetailsSheet.swift` | Painel de licença (dias restantes, expiração, key mascarada, copiar key/HWID, verificar agora, trocar key, remover do aparelho) |

Arquivos alterados:

- `ThreeOneOSFive/ContentView.swift` — o app agora só abre depois da licença liberada.
- `ThreeOneOSFive/CustomLayoutView.swift` — selo de licença no topo (verde = ativa, laranja = pendente/offline) que abre o painel de licença.
- `ThreeOneOSFive/Info.plist` — URL, credencial e tolerância offline da API de licenças.
- `ThreeOneOSFive.xcodeproj/project.pbxproj` — os quatro arquivos novos já estão no target.

## Configuração (Info.plist)

```xml
<key>LUCCHESE_LICENSE_API_BASE_URL</key>
<string>https://lucckeys-ll5aquxm.manus.space/api/license</string>
<key>LUCCHESE_LICENSE_API_KEY</key>
<string>lk_live_B_BlUwxNm22VY-kE19ZR4Df78qcZCOT9</string>
<key>LUCCHESE_LICENSE_OFFLINE_GRACE_MINUTES</key>
<integer>15</integer>
```

Nada de URL/credencial está fixo no código: trocar o `Info.plist` muda o comportamento
sem mexer na lógica. A base precisa ser HTTPS e o app acrescenta `/activate`,
`/validate`, `/status` e `/unlink-hwid`.

## Fluxo implementado

1. **HWID** — na primeira leitura o app pega `identifierForVendor` e grava no Keychain
   (`kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly`). A partir daí o valor é estável,
   mesmo se o IDFV mudar (reinstalação). É enviado em todas as chamadas.
2. **Primeira ativação** — o botão "Ativar licença" chama `POST /activate`. Em sucesso a
   key é salva no Keychain, a licença é liberada e aparece a animação "LICENÇA ATIVADA".
3. **Validação de rotina** — ao abrir o app, ao voltar do background e a cada 15 segundos
   enquanto o app estiver ativo/em primeiro plano, o app chama `POST /validate`. Isso é
   polling quase em tempo real; o iOS suspende tarefas de rede em background, então não
   há garantia de consulta enquanto o app estiver suspenso ou fechado.
4. **Bloqueio imediato** — `hwid_mismatch`, `key_expired`, `key_revoked`, `key_not_found`
   ou `status != "active"` derrubam o acesso na hora, com tela explicando o motivo.
   Em `key_revoked` e `key_not_found` a key local é apagada.
5. **Tolerância offline** — o servidor não gerencia modo offline, então o app faz isso:
   guarda o horário da última validação bem-sucedida e mantém o acesso por até 15
   minutos (configurável) sem internet. Passado esse prazo, aparece a tela "Sem conexão"
   com "Tentar novamente". `429 rate_limited` respeita o `Retry-After` e entra na mesma
   regra de tolerância.
6. **Desvincular aparelho** — em `hwid_mismatch` a tela oferece "Desvincular este
   aparelho" (`POST /unlink-hwid`). Se o painel não autorizou a ação, a mensagem do
   servidor aparece na própria tela.

## Tratamento dos códigos de erro

| HTTP / code | O que o app faz |
| --- | --- |
| `401 invalid_api_key` | "Credencial inválida" — problema de build/configuração, com opção de tentar de novo |
| `409 hwid_mismatch` | Bloqueia e mostra o botão de desvincular + "usar outra key" |
| `409 key_expired` | Bloqueia, mostra a data em que expirou e pede a key renovada |
| `409 key_revoked` | Bloqueia e apaga a key do aparelho |
| `404 key_not_found` | Erro no próprio formulário ("essa key não existe") |
| `429 rate_limited` | Mostra o tempo de espera; usa a tolerância offline se ainda estiver na janela |
| `500 internal_error` | "Servidor indisponível" com "Tentar novamente" |
| Falha de rede | `offline` — tolerância de 15 min, depois tela de retry |

## Interface

- Fundo em gradiente navy com três brilhos animados (mesma linguagem da home do app).
- Marca com anel girando e ícone de key, título "LUCCHESE STORE" com tracking.
- Campo de key monoespaçado, maiúsculo automático, com botão "Colar" e foco com halo azul.
- Erros em faixa colorida + tremida (shake) e feedback tátil.
- Cartão do aparelho mostrando modelo/iOS e o HWID (com copiar).
- Selo de licença no topo do app: dias restantes, "Offline" ou "Bloqueado".
- Painel de licença com dias restantes, expiração, key mascarada, última verificação.

## Compilar

Abra `ThreeOneOSFive.xcodeproj` no Xcode (destino iOS 17+), escolha a equipe de assinatura
e rode. Não foi possível compilar neste ambiente Linux (sem `xcodebuild`), então o código
foi revisado linha a linha; qualquer ajuste de assinatura/bundle fica do lado do Xcode.

## Testes rápidos

- Key inexistente (`LUCCHESE-TESTE000000`) → `key_not_found` no formulário.
- Ativar uma key real → animação e app liberado; fechar e abrir o app → validação
  automática; modo avião → app continua liberado por até 15 minutos.
- Revogar a key no painel com o app aberto → o app volta para a tela de bloqueio na
  próxima consulta (até aproximadamente 15 segundos, se a rede responder).

## Segurança

A credencial `x-api-key` acompanha o binário, como o documento da API exige. Ela pode ser
extraída de um IPA. Se isso for um problema, o caminho é colocar um proxy seu entre o app
e a LuccKeys (o app passa a falar só com o seu domínio) — o `Info.plist` já permite trocar
a base sem tocar no código. A key do usuário e o HWID ficam no Keychain, nunca em
`UserDefaults`; o cache local guarda apenas status, plano e data de expiração.
