# Controle global do app e gerenciamento de HWID

O projeto web `Lucchese Control` acrescenta uma API para o app, separada da API LuccKeys de licença. No servidor do painel, os registros ficam no banco MySQL gerenciado. As credenciais do administrador são segredos de ambiente no projeto web.

## Modos disponíveis

- `normal`: permite continuar para o fluxo normal da key.
- `updating`: bloqueia as telas de licença e do app e mostra por padrão “O app está atualizando. Contate o suporte.”
- `old_version`: bloqueia o uso e mostra “Nova versão disponível para baixar. Contate o suporte.”
- `offline`: bloqueia o uso e mostra “App offline. Aguardando o proprietário religar o app.”

O administrador pode salvar uma mensagem alternativa (até 500 caracteres) para os modos bloqueados. A exceção de banimento do aparelho é verificada antes do modo global; aparelho banido mostra a tela de banimento independentemente de key ou modo do app.

## Contrato de bootstrap

Após publicar o painel, o app envia o seguinte JSON por HTTPS para `POST <URL do site>/api/app/bootstrap`:

```json
{
  "hwid": "UUID estável salvo no Keychain",
  "deviceModel": "iPhone (iPhoneXX,X)",
  "iosVersion": "18.x",
  "appVersion": "1.2.1",
  "buildNumber": "9"
}
```

Resposta permitida:

```json
{
  "ok": true,
  "mode": "normal",
  "message": null,
  "device": { "hwid": "...", "banned": false, "banReason": null },
  "checkedAt": "2026-11-15T12:00:00.000Z"
}
```

O endpoint registra o aparelho no primeiro contato, atualiza modelo/versões/último contato e preserva a decisão de banimento existente. O HWID é chave primária única. Não há endpoint público para ler a lista nem alterar banimento ou modo; essas operações exigem sessão administrativa.

## Chave de configuração do app

Em `ThreeOneOSFive/Info.plist`, `LUCCHESE_APP_CONTROL_BASE_URL` está configurado para a origem HTTPS publicada `https://lucchesecont-bk7u7th5.manus.space`, sem `/api/app/bootstrap`, query ou fragment. O endpoint é público apenas para que novas instalações registrem o próprio aparelho e consultem modo/banimento; a lista e as ações administrativas continuam autenticadas.

O domínio está publicado e `/api/health` respondeu com sucesso; sem sessão, a rota administrativa responde `401`, e o bootstrap rejeita payload inválido com `400`. Gere um novo IPA/Xcode archive para distribuir a build já conectada. Preview não é URL de produção e não deve ser distribuído para usuários.

## Persistência e limites do HWID

O app nunca troca um HWID encontrado no Keychain. Se não há registro anterior, cria um UUID aleatório e o salva como `ThisDeviceOnly`; verifica a gravação antes de enviar. Para manter associações antigas, builds anteriores preservam exatamente o identificador já guardado (inclusive os originados do IDFV). O banco rejeita duplicatas por unicidade de HWID.

Esse identificador é criado pelo app, não é serial físico do iPhone. A Apple não disponibiliza um identificador físico permanente para apps comuns. O Keychain costuma sobreviver atualizações e reinstalações normais, mas apagamento dos dados de Keychain/reset/restauração pode remover o item; nessas condições não há garantia técnica de reconhecer o mesmo aparelho sem verificação Apple adicional como App Attest.

## Sequência de acesso

1. O app recupera/cria HWID e faz bootstrap com o painel antes de renderizar outras telas.
2. Se o serviço está bloqueado, o app substitui a interface inteira pelo aviso; se o dispositivo está banido, exibe primeiro a tela de banimento.
3. Somente após `mode=normal` e `banned=false` o app chama a API de licenças e permite inserir/validar key.
4. Enquanto o app está em foreground, revalida o controle a cada 15 segundos e novamente ao voltar ao primeiro plano.
5. O app é fail-closed: sem comunicação com a origem configurada, o conteúdo permanece bloqueado. O iOS pode suspender requisições enquanto o app está em background ou fechado.

## Segurança

O endpoint bootstrap é público por necessidade para registrar instalações novas. Aceita somente payload curto com UUID e metadados, não expõe registros de outros aparelhos e não permite alterar estados. Como dados enviados de um IPA podem ser falsificados, o HWID não é atestado criptograficamente como hardware genuíno; App Attest é uma evolução possível se for necessário elevar essa garantia.
