# CodeMagic — projeto Lucchese Store 3106

O log anterior usou o projeto errado: `ThreeOneOSFive.xcodeproj` e scheme `3105`, que não existem na fonte 3106 deste pacote. Use a pasta extraída cujo nível contém diretamente `ThreeOneOSSix.xcodeproj`.

Configuração de build no CodeMagic:

- **Xcode project:** `ThreeOneOSSix.xcodeproj`
- **Scheme:** `3106`
- **Configuration:** `Release`
- **Destination:** `generic/platform=iOS`

A origem HTTPS da API está configurada no target para Debug e Release como `https://lucchese-h5sphw9z.manus.space`. Não selecione a pasta `site-api/`: ela é o backend web, não um target iOS. Também não use `3105-interface-customizada/` nem `ThreeOneOSFive.xcodeproj` — são caminhos/nomes da fonte anterior, não da IPA 2 adaptada.

Em builds para distribuição/TestFlight, configure certificado e perfil de provisionamento correspondentes ao Bundle Identifier `com.qingtang.3106` ou altere o Bundle Identifier para um que pertença à sua equipe Apple. Esse pacote corrige a seleção do projeto/scheme; não garante assinatura sem as credenciais do seu time. O log anexado parou antes da compilação por não encontrar o `.xcodeproj`, portanto ainda não revela eventuais erros de Swift/assinatura posteriores.
