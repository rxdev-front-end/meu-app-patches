import Foundation
import Security
import SwiftUI
import UIKit

struct RemotePatch: Decodable, Identifiable {
    let id: String
    var name: String
    var category: String?
    var description: String?
    var version: String?
    var status: String
    var risk: Bool
    var downloadURL: URL?

    private enum CodingKeys: String, CodingKey {
        case id, name, category, categoryId, description, note, version, status, risk
        case downloadURL, fileURL, download, file
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = (try? container.decode(String.self, forKey: .id))
            ?? (try? container.decode(Int.self, forKey: .id)).map(String.init)
            ?? ""
        name = (try? container.decode(String.self, forKey: .name)) ?? "Patch \(id)"
        category = (try? container.decode(String.self, forKey: .category))
            ?? (try? container.decode(String.self, forKey: .categoryId))
            ?? (try? container.decode(Int.self, forKey: .categoryId)).map(String.init)
        description = (try? container.decode(String.self, forKey: .description))
            ?? (try? container.decode(String.self, forKey: .note))
        version = try? container.decode(String.self, forKey: .version)
        status = (try? container.decode(String.self, forKey: .status)) ?? "desativado"
        risk = (try? container.decode(Bool.self, forKey: .risk)) ?? false
        let rawURL = (try? container.decode(String.self, forKey: .fileURL))
            ?? (try? container.decode(String.self, forKey: .downloadURL))
            ?? (try? container.decode(String.self, forKey: .download))
            ?? (try? container.decode(String.self, forKey: .file))
        downloadURL = rawURL.flatMap(URL.init(string:))
    }
}

struct RemoteAnnouncement: Decodable, Identifiable {
    let id: String
    let title: String
    let message: String
    let createdAt: String?

    private enum CodingKeys: String, CodingKey { case id, title, message, body, content, createdAt, date }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = (try? container.decode(String.self, forKey: .id))
            ?? (try? container.decode(Int.self, forKey: .id)).map(String.init)
            ?? UUID().uuidString
        title = (try? container.decode(String.self, forKey: .title)) ?? "Aviso"
        message = (try? container.decode(String.self, forKey: .message))
            ?? (try? container.decode(String.self, forKey: .body))
            ?? (try? container.decode(String.self, forKey: .content))
            ?? ""
        createdAt = (try? container.decode(String.self, forKey: .createdAt))
            ?? (try? container.decode(String.self, forKey: .date))
    }
}

@MainActor
final class RemoteIntegration: ObservableObject {
    static let shared = RemoteIntegration()

    @Published private(set) var licensed = false
    @Published private(set) var serviceAllowed = false
    @Published private(set) var gateMessage: String?
    @Published private(set) var patches: [RemotePatch] = []
    @Published private(set) var announcements: [RemoteAnnouncement] = []
    @Published private(set) var isLoading = false
    @Published var errorMessage: String?
    @Published var licenseKey = ""
    @Published private(set) var globalStatus = "checking"

    private let session = URLSession(configuration: .ephemeral)
    private let keychainService = "com.lucchese.3106.remote"
    private let licenseAccount = "license.key"
    private let deviceAccount = "device.hwid"
    private let licenseStorageKey = "3106.remote.license"
    private var lastCatalogRefresh = Date.distantPast

    private var baseURL: URL? {
        guard let raw = Bundle.main.object(forInfoDictionaryKey: "LUCCHESE_API_BASE_URL") as? String else { return nil }
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: value),
              let components = URLComponents(url: url, resolvingAgainstBaseURL: false),
              components.scheme?.lowercased() == "https",
              components.host != nil,
              components.user == nil,
              components.password == nil,
              components.query == nil,
              components.fragment == nil,
              components.path.isEmpty || components.path == "/" else { return nil }
        return url
    }

    var isConfigured: Bool { baseURL != nil }
    private var savedKey: String? { readKeychain(account: licenseAccount) }

    private var hwid: String {
        if let stored = readKeychain(account: deviceAccount), !stored.isEmpty { return stored }
        let generated = UUID().uuidString.uppercased()
        guard writeKeychain(generated, account: deviceAccount), readKeychain(account: deviceAccount) == generated else {
            return ""
        }
        return generated
    }

    private init() {
        licenseKey = readKeychain(account: licenseAccount) ?? ""
        // One-time migration from the pre-release preference key; then remove plaintext storage.
        if let legacy = UserDefaults.standard.string(forKey: licenseStorageKey), !legacy.isEmpty {
            if writeKeychain(legacy, account: licenseAccount) {
                licenseKey = legacy
                UserDefaults.standard.removeObject(forKey: licenseStorageKey)
            }
        }
    }

    private func readKeychain(account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    @discardableResult
    private func writeKeychain(_ value: String, account: String) -> Bool {
        guard let data = value.data(using: .utf8) else { return false }
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: account,
        ]
        let attributes: [String: Any] = [
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
        ]
        let update = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if update == errSecSuccess { return true }
        guard update == errSecItemNotFound else { return false }
        var item = query
        attributes.forEach { item[$0.key] = $0.value }
        return SecItemAdd(item as CFDictionary, nil) == errSecSuccess
    }

    private func deleteKeychain(account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: account,
        ]
        SecItemDelete(query as CFDictionary)
    }

    private func endpoint(_ path: String) throws -> URL {
        guard let baseURL, let url = URL(string: path, relativeTo: baseURL)?.absoluteURL else {
            throw RemoteError.configuration
        }
        return url
    }

    private func attachMobileCredentials(to request: inout URLRequest) {
        guard let key = savedKey, !key.isEmpty, !hwid.isEmpty else { return }
        request.setValue(key, forHTTPHeaderField: "X-License-Key")
        request.setValue(hwid, forHTTPHeaderField: "X-Device-ID")
        request.setValue(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0", forHTTPHeaderField: "X-App-Version")
        request.setValue(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "0", forHTTPHeaderField: "X-App-Build")
    }

    private enum RemoteError: LocalizedError {
        case configuration
        case response(String)
        case malformed

        var errorDescription: String? {
            switch self {
            case .configuration:
                return "Servidor remoto não configurado. Defina LUCCHESE_API_BASE_URL com a origem HTTPS publicada."
            case .response(let text):
                return text
            case .malformed:
                return "Resposta inesperada do servidor. Tente novamente."
            }
        }
    }

    private func send(_ path: String, method: String = "GET", body: [String: Any]? = nil) async throws -> [String: Any] {
        var request = URLRequest(url: try endpoint(path), timeoutInterval: 25)
        request.httpMethod = method
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
        if let body {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        attachMobileCredentials(to: &request)
        // Não usar x-api-key: uma credencial estática distribuída no app não é segredo.
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw RemoteError.malformed }
        let payload = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
        guard (200..<300).contains(http.statusCode) else {
            throw RemoteError.response((payload["message"] as? String)
                ?? (payload["error"] as? String)
                ?? "Falha HTTP \(http.statusCode). Verifique a conexão e tente novamente.")
        }
        return payload
    }

    private func devicePayload() -> [String: Any] {
        [
            "hwid": hwid,
            "deviceModel": UIDevice.current.model,
            "iosVersion": UIDevice.current.systemVersion,
            "appVersion": Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0",
            "buildNumber": Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "0",
        ]
    }

    @discardableResult
    func checkBootstrap() async -> Bool {
        guard isConfigured else {
            globalStatus = "offline"
            serviceAllowed = false
            gateMessage = RemoteError.configuration.localizedDescription
            return false
        }
        guard !hwid.isEmpty else {
            globalStatus = "offline"
            serviceAllowed = false
            gateMessage = "Não foi possível criar o identificador seguro deste dispositivo."
            return false
        }
        do {
            let result = try await send("/api/app/bootstrap", method: "POST", body: devicePayload())
            updateStatus(result)
            serviceAllowed = isServicePermitted(result)
            if !serviceAllowed {
                licensed = false
                gateMessage = preferredMessage(for: result)
            } else {
                gateMessage = nil
            }
            return serviceAllowed
        } catch {
            globalStatus = "offline"
            serviceAllowed = false
            licensed = false
            gateMessage = error.localizedDescription
            return false
        }
    }

    func activateOrValidate(key: String? = nil) async {
        guard !isLoading else { return }
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }

        guard await checkBootstrap() else { return }
        let candidate = (key ?? licenseKey).trimmingCharacters(in: .whitespacesAndNewlines)
        let currentKey = savedKey
        let chosenKey = candidate.isEmpty ? currentKey : candidate
        guard let chosenKey, !chosenKey.isEmpty else {
            errorMessage = "Informe sua chave de licença."
            return
        }
        guard !hwid.isEmpty else {
            errorMessage = "Não foi possível identificar este dispositivo com segurança."
            return
        }

        do {
            let isNewKey = currentKey == nil || currentKey?.caseInsensitiveCompare(chosenKey) != .orderedSame
            let payload: [String: Any] = ["key": chosenKey, "hwid": hwid]
            let response = try await send(isNewKey ? "/api/license/activate" : "/api/license/validate", method: "POST", body: payload)
            guard isLicenseValid(response) else {
                licensed = false
                errorMessage = (response["message"] as? String) ?? "A licença não está ativa. Confira a key e tente novamente."
                return
            }
            guard writeKeychain(chosenKey, account: licenseAccount) else {
                licensed = false
                errorMessage = "Não foi possível proteger a key no Keychain deste aparelho."
                return
            }
            licenseKey = chosenKey
            licensed = true
            gateMessage = nil
            await refreshCatalog()
        } catch {
            licensed = false
            errorMessage = error.localizedDescription
            gateMessage = error.localizedDescription
        }
    }

    func unlink() async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        guard let key = savedKey, !key.isEmpty else {
            errorMessage = "Não há uma licença salva neste aparelho."
            return
        }
        do {
            _ = try await send("/api/license/unlink-hwid", method: "POST", body: ["hwid": hwid, "key": key])
            deleteKeychain(account: licenseAccount)
            UserDefaults.standard.removeObject(forKey: licenseStorageKey)
            licenseKey = ""
            licensed = false
            gateMessage = "Dispositivo desvinculado. Ative uma licença para continuar."
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func isLicenseValid(_ object: [String: Any]) -> Bool {
        guard (object["ok"] as? Bool) == true,
              let license = object["license"] as? [String: Any],
              let rawStatus = license["status"] as? String else { return false }
        return ["active", "valid", "ok"].contains(rawStatus.lowercased())
    }

    private func serviceMode(from object: [String: Any]) -> String {
        let raw = (object["mode"] as? String)
            ?? (object["globalStatus"] as? String)
            ?? (object["status"] as? String)
            ?? "normal"
        let normalized = raw.lowercased()
        if ["active", "normal", "ok"].contains(normalized) { return "normal" }
        if ["disabled", "shutdown", "off"].contains(normalized) { return "offline" }
        if ["update"].contains(normalized) { return "updating" }
        return normalized
    }

    private func updateStatus(_ object: [String: Any]) {
        let device = object["device"] as? [String: Any] ?? object
        if (device["banned"] as? Bool) == true {
            globalStatus = "banned"
        } else {
            globalStatus = serviceMode(from: object)
        }
        let reason = device["banReason"] as? String
        let message = object["message"] as? String
        if globalStatus == "banned", let reason, !reason.isEmpty {
            gateMessage = "Este dispositivo foi bloqueado. \(reason)"
        } else if let message, !message.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            gateMessage = message
        }
    }

    private func isServicePermitted(_ object: [String: Any]) -> Bool {
        let device = object["device"] as? [String: Any] ?? object
        let banned = (device["banned"] as? Bool) == true
        return !banned && ["normal", "active", "ok"].contains(serviceMode(from: object))
    }

    private func preferredMessage(for object: [String: Any]) -> String {
        let device = object["device"] as? [String: Any] ?? object
        if (device["banned"] as? Bool) == true {
            let reason = (device["banReason"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines)
            return reason?.isEmpty == false ? "Este dispositivo foi bloqueado. \(reason!)" : "Este dispositivo foi bloqueado. Contate o suporte."
        }
        if let message = object["message"] as? String, !message.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return message
        }
        switch serviceMode(from: object) {
        case "maintenance": return "Serviço em manutenção. Tente novamente mais tarde."
        case "offline": return "Serviço temporariamente desligado. Tente novamente mais tarde."
        case "updating": return "Serviço em atualização. Tente novamente em alguns minutos."
        case "old_version", "old-version": return "Esta versão do app está desatualizada. Atualize para continuar."
        default: return "Não foi possível liberar o acesso. Tente novamente."
        }
    }

    private func decodeArray<T: Decodable>(_ type: T.Type, from object: Any?) -> [T] {
        guard let object, JSONSerialization.isValidJSONObject(object),
              let data = try? JSONSerialization.data(withJSONObject: object) else { return [] }
        if let direct = try? JSONDecoder().decode([T].self, from: data) { return direct }
        for key in ["data", "items", "catalog", "patches", "announcements", "results"] {
            if let nested = (object as? [String: Any])?[key],
               let nestedData = try? JSONSerialization.data(withJSONObject: nested),
               let decoded = try? JSONDecoder().decode([T].self, from: nestedData) { return decoded }
        }
        return []
    }

    func refreshCatalog() async {
        guard licensed else { return }
        do {
            async let catalogTask = send("/api/mobile/catalog")
            async let announcementsTask = send("/api/mobile/announcements")
            let (catalog, news) = try await (catalogTask, announcementsTask)
            let categoryRows = catalog["categories"] as? [[String: Any]] ?? []
            let categoryNames = Dictionary(uniqueKeysWithValues: categoryRows.compactMap { row -> (String, String)? in
                let id = (row["id"] as? String) ?? (row["id"] as? Int).map(String.init)
                guard let id, let name = row["name"] as? String else { return nil }
                return (id, name)
            })
            let decoded = decodeArray(RemotePatch.self, from: catalog["patches"] ?? catalog["data"] ?? catalog)
            patches = decoded.map { patch in
                var value = patch
                if let categoryId = patch.category, let name = categoryNames[categoryId] { value.category = name }
                return value
            }
            announcements = decodeArray(RemoteAnnouncement.self, from: news["announcements"] ?? news["data"] ?? news)
            lastCatalogRefresh = Date()
            errorMessage = nil
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func download(_ patch: RemotePatch, coordinator: PatchDraftCoordinator) async {
        guard isConfigured, !patch.id.isEmpty else {
            errorMessage = "Identificador do patch inválido."
            return
        }
        guard patch.status == "ativo" else {
            errorMessage = patch.status == "atualizando" ? "Este pacote está sendo atualizado." : "Este pacote está desativado."
            return
        }
        do {
            let safeID = patch.id.addingPercentEncoding(withAllowedCharacters: CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-_"))) ?? ""
            guard !safeID.isEmpty else { throw RemoteError.response("Identificador do patch inválido.") }
            var request = URLRequest(url: try endpoint("/api/mobile/patches/\(safeID)/file"))
            attachMobileCredentials(to: &request)
            let (temporaryFile, response) = try await session.download(for: request)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
                throw RemoteError.response("Não foi possível baixar o pacote. Tente novamente.")
            }
            let bytes = try Data(contentsOf: temporaryFile)
            guard !bytes.isEmpty, bytes.count <= 25 * 1_024 * 1_024 else {
                throw RemoteError.response("Arquivo vazio ou maior que o limite compatível de 25 MiB.")
            }
            let destination = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".3106")
            try bytes.write(to: destination, options: .atomic)
            // The existing native 3106 importer remains the only parser/validator.
            coordinator.presentImport(destination)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func monitor() async {
        while !Task.isCancelled {
            if UIApplication.shared.applicationState == .active, isConfigured {
                let allowed = await checkBootstrap()
                if allowed, let key = savedKey, !key.isEmpty {
                    do {
                        let response = try await send("/api/license/validate", method: "POST", body: ["key": key, "hwid": hwid])
                        if !isLicenseValid(response) {
                            licensed = false
                            errorMessage = (response["message"] as? String) ?? "A licença não está mais ativa."
                        } else {
                            licensed = true
                            gateMessage = nil
                            if Date().timeIntervalSince(lastCatalogRefresh) >= 60 { await refreshCatalog() }
                        }
                    } catch {
                        licensed = false
                        errorMessage = error.localizedDescription
                    }
                } else {
                    licensed = false
                }
            }
            try? await Task.sleep(nanoseconds: 15 * 1_000_000_000)
        }
    }
}

struct RemoteAccessView: View {
    @ObservedObject var service = RemoteIntegration.shared
    @EnvironmentObject private var importCoordinator: PatchDraftCoordinator
    @State private var selected = 0

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                if let error = service.errorMessage {
                    Label(error, systemImage: "exclamationmark.triangle.fill")
                        .font(.footnote).foregroundStyle(.red).padding()
                }
                if service.licensed {
                    Picker("Conteúdo", selection: $selected) {
                        Text("Catálogo").tag(0)
                        Text("Avisos").tag(1)
                    }
                    .pickerStyle(.segmented)
                    .padding()
                    if selected == 0 { catalog } else { announcements }
                } else {
                    licenseForm
                }
            }
            .navigationTitle("Acesso remoto Lucchese Store")
            .toolbar {
                if service.licensed {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("Desvincular") { Task { await service.unlink() } }
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        Task {
                            if service.licensed { await service.refreshCatalog() }
                            else { await service.activateOrValidate() }
                        }
                    } label: { Image(systemName: "arrow.clockwise") }
                }
            }
        }
        .task {
            guard service.isConfigured else { return }
            let allowed = await service.checkBootstrap()
            if allowed, !service.licenseKey.isEmpty { await service.activateOrValidate() }
        }
    }

    private var licenseForm: some View {
        Form {
            Section("Licença") {
                if !service.isConfigured {
                    Text("Servidor não configurado. Defina LUCCHESE_API_BASE_URL para a origem HTTPS publicada; nenhum domínio é presumido.")
                        .foregroundStyle(.orange)
                }
                SecureField("Chave de licença", text: $service.licenseKey)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                if let message = service.gateMessage { Text(message).foregroundStyle(.orange) }
                Button(service.isLoading ? "Conectando…" : "Ativar / validar licença") {
                    Task { await service.activateOrValidate(key: service.licenseKey) }
                }
                .disabled(service.isLoading || !service.isConfigured)
                Text("A licença remota controla o acesso solicitado. Nenhuma chave estática de API é enviada.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    private var catalog: some View {
        List {
            if service.patches.isEmpty {
                Text("Sem patches. Atualize para tentar novamente.").foregroundStyle(.secondary)
            }
            ForEach(service.patches) { patch in
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(patch.name).font(.headline)
                        Spacer()
                        Text(patch.status.capitalized).font(.caption).foregroundStyle(patch.status == "ativo" ? .green : .secondary)
                    }
                    if let category = patch.category { Text(category).font(.caption).foregroundStyle(.secondary) }
                    if let version = patch.version { Text("Versão \(version)").font(.caption).foregroundStyle(.secondary) }
                    if let description = patch.description { Text(description).font(.subheadline) }
                    if patch.risk { Label("Risco indicado pelo painel", systemImage: "exclamationmark.triangle.fill").font(.caption).foregroundStyle(.orange) }
                    Button("Baixar e importar") { Task { await service.download(patch, coordinator: importCoordinator) } }
                        .disabled(service.isLoading || patch.status != "ativo")
                }
                .padding(.vertical, 4)
            }
        }
        .refreshable { await service.refreshCatalog() }
    }

    private var announcements: some View {
        List(service.announcements) { item in
            VStack(alignment: .leading, spacing: 6) {
                Text(item.title).font(.headline)
                Text(item.message)
                if let date = item.createdAt { Text(date).font(.caption).foregroundStyle(.secondary) }
            }
        }
        .refreshable { await service.refreshCatalog() }
    }
}
