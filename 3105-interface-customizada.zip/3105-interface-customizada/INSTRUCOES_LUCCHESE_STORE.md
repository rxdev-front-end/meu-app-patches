# Lucchese Store — instruções do app 3105

## Estado desta entrega

O projeto iOS foi preparado para buscar catálogo de patches e avisos pela API. O site e a API **ainda não foram publicados**. O domínio reservado está configurado no app, mas só responderá depois de uma publicação autorizada. Não instale o app esperando receber patches enquanto a API estiver offline.

## Atualização do catálogo e avisos

Ao abrir o app, voltar para ele e puxar a lista para atualizar, o app consulta a API. Enquanto estiver em primeiro plano, também verifica mudanças aproximadamente a cada 15 segundos. Os avisos publicados e todos os patches do catálogo — inclusive os que estejam `atualizando` ou `desativados` — aparecem com os metadados configurados no painel. O app baixa/importa internamente os arquivos `.3105` ativos; não há botão de importação manual nem associação do tipo `.3105` com o iOS. Patches publicados não podem ser renomeados no app.

O status `ativo` permite iniciar uma nova ativação. `atualizando` e `desativado` bloqueiam novas ativações. Se um patch for removido do site, ele some do catálogo depois da próxima sincronização. Se ainda estiver aplicado, o app mantém os dados necessários para restaurá-lo; depois da restauração conclui a remoção local. O motor original de aplicação/restauração e as cópias de segurança continuam no projeto.

A sincronização por polling **não é instantânea** e só funciona enquanto o app está aberto/em primeiro plano. O iOS pode suspender a rede em segundo plano, com o app suspenso ou fechado. Push fora do app não foi habilitado: exige capability/entitlement e assinatura Apple, registro de token do aparelho e chave/credenciais APNs no backend. Essas configurações não estão disponíveis nesta entrega.

## Compatibilidade

A tela mostra a versão do iOS e o modelo do aparelho. A regra configurada considera compatíveis iOS 17.0–17.7 e iOS 26.0–26.6.2; demais versões são bloqueadas para ativação com `Versão do iOS não suportada`.

## Endereço da API

`ThreeOneOSFive/Info.plist`, chave `LUCCHESE_API_BASE_URL`, aponta para `https://lucchapi-h4bdt6t8.manus.space`. Use somente a raiz HTTPS do domínio permanente, sem acrescentar `/api` e sem usar a URL de Preview. O cliente usa `GET /api/mobile/catalog`, `GET /api/mobile/patches/{id}/file` e `GET /api/mobile/announcements`. Esses endpoints de leitura/download são públicos para os clientes do app; a senha administrativa não deve ser colocada no app. A chave `LUCCHESE_API_ALLOWED_DOWNLOAD_HOSTS` limita o download ao host da API ou ao host do CDN assinado observado para o Storage gerenciado; se esse host mudar, atualize a allowlist no Info.plist e recompile o app.

A configuração de publicação automática do projeto Web está ligada. Como a instrução atual é não publicar o site/API sem autorização separada, não foi feito push/checkpoint nem publicação. Antes de qualquer publicação futura, desligue Auto Publish no Dashboard e conceda autorização expressa para tornar catálogo, arquivos de patches ativos e avisos acessíveis pelos endpoints públicos do app.

## Abrir e compilar no Xcode

Abra `ThreeOneOSFive.xcodeproj` em um Mac com Xcode, escolha um destino e equipe de assinatura válidos e faça o build/instalação pelo Xcode. O ambiente usado para atualizar este pacote é Linux e não tem `xcodebuild` nem `swiftc`; portanto, **não foi possível executar nem confirmar uma compilação iOS**. A URL configurada no pacote não torna a API disponível até o proprietário autorizar e a publicação ser concluída. O app já instalado também não se atualiza sozinho: é necessário instalar uma versão recompilada.
