# Notas de referência externas

- Repositório público 3105 (branch main): https://github.com/YangJiiii/3105
- Guia de patches do repositório: https://github.com/YangJiiii/3105/blob/main/docs/PATCH_GUIDE.md. O guia descreve schemas 6–9; schema 9 adiciona prefix key selectors e valores Data carregados do aparelho; apps antigos devem rejeitar esquemas novos em vez de interpretar operações incorretamente.
- Codec consultado: https://raw.githubusercontent.com/YangJiiii/3105/main/ThreeOneOSFive/helpers/PatchPackageCodec.swift. A cópia pública consultada declara latestSchemaVersion = 3.
- Patch MediaFire analisado por solicitação do usuário: link https://www.mediafire.com/file/o5nkwl8l41u6if4/Hs+Pescoc%CC%A7o+-+Slide+Up.3105/file. Download feito em 2026-11-15; envelope Magic 3105PATCH, schemaVersion 9, unprotected, payload decodificado revela nome “Hs Pescoço + Slide Up”, 1 regra; operation replace e containerKind application, com bundle ID de jogo.
