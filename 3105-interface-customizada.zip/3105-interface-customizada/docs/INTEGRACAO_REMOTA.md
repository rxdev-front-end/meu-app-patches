# Integração remota do cliente 3106 — Lucchese Store

## Configuração

A origem HTTPS da API unificada publicada é `https://lucchese-h5sphw9z.manus.space`. O projeto Xcode já define `LUCCHESE_API_BASE_URL` com essa origem nas configurações Debug e Release; não acrescente barra final, caminho `/api` ou credenciais. Se o domínio mudar, atualize o build setting do target. Quando a URL está configurada, o app exige licença/acesso remoto antes das telas principais; os motores e fluxos locais do 3106 permanecem nativos. Não existe `x-api-key` nem segredo estático no cliente.

O identificador do dispositivo é um UUID aleatório criado pelo app e persistido localmente; não é UDID nem identificador físico. O cliente informa apenas modelo do aparelho, versão do iOS, versão do app e build no bootstrap. A key de licença é armazenada no Keychain; HWID e key nunca são colocados em query string.

## Contrato implementado

- `POST /api/app/bootstrap` recebe `hwid`, `deviceModel`, `iosVersion`, `appVersion` e `buildNumber`; devolve modo global, mensagem e estado do dispositivo.
- `POST /api/license/activate` recebe `key` e `hwid` no JSON para primeiro vínculo; `POST /api/license/validate` revalida o vínculo salvo.
- `GET /api/license/status` recebe `X-License-Key` e `X-Device-ID` nos headers TLS.
- `POST /api/license/unlink-hwid` solicita desvinculação com `key` e `hwid` no JSON.
- `GET /api/mobile/catalog`, `GET /api/mobile/announcements` e `GET /api/mobile/patches/:id/file` também exigem `X-License-Key` e `X-Device-ID`.

Sucesso de licença: `{ "ok": true, "license": { "status": "active", "planDays": 7, "expiresAt": "ISO-8601 ou null" } }`. Erro móvel: `{ "ok": false, "code": "...", "message": "..." }`. Estados globais `normal`/`active` permitem prosseguir; `maintenance`, `offline`, `updating`, `old_version` e dispositivo banido bloqueiam o acesso com mensagem. Os endpoints de conteúdo também validam serviço ativo e versão/build mínimos, não apenas a UI.

O catálogo retorna `categories` e `patches`, incluindo `id`, `name`, `categoryId`, `note`, `status`, `risk`, `version` e URL de arquivo. Avisos publicados são retornados em `announcements`.

## Importação e limites

O download é guardado temporariamente como `.3106` e entregue a `PatchDraftCoordinator.presentImport`. O importador e `PatchPackageCodec` locais continuam responsáveis pelo formato/cabeçalho `3105PATCH`, schema, senha, compatibilidade e integridade. O cliente não decodifica, transforma nem aplica o pacote automaticamente; o backend só valida extensão/cabeçalho do upload, tamanho (máx. 25 MiB) e SHA-256, armazena os bytes e entrega o pacote publicado.

A integração não substitui motores, importador, sandbox, mecanismos de patch ou demais sistemas próprios do 3106 pelos do 3105. Os módulos nativos permanecem locais. `LICENSE` e `NOTICE.md` da fonte original são preservados.

## Build

Abra `ThreeOneOSSix.xcodeproj` e compile/assine no Xcode; Debug e Release já apontam para a origem publicada acima. O identificador de bundle e o versionamento da fonte original foram preservados; o nome exibido é “Lucchese Store” e a assinatura visual é “@lucchese”. Este pacote contém código-fonte, não uma IPA assinada.
