import Combine
import Foundation
import UIKit

/// Configure somente após a publicação do backend e a autorização do proprietário.
/// Mantida nil enquanto não há um endereço de produção aprovado.
enum LuccheseAPIConfiguration {
    static let baseURL: URL? = nil
}

enum LucchesePatchStatus: String, Codable {
    case ativo
    case atualizando
    case desativado
}

struct LuccheseRemotePatch: Codable, Identifiable {
    let id: String
    let name: String
    let note: String?
    let status: LucchesePatchStatus
    let risk: Bool
    let fileURL: String
}

struct LuccheseCatalog: Decodable {
    let patches: [LuccheseRemotePatch]
}

struct LuccheseAnnouncement: Decodable, Identifiable {
    let id: String
    let title: String
    let message: String
    let createdAt: String
}

private struct LuccheseAnnouncements: Decodable {
    let announcements: [LuccheseAnnouncement]
}

enum LuccheseAPIError: Error {
    case notConfigured
    case badResponse
    case missingPatch
}

enum LuccheseActivationBlock: String, Equatable {
    case unsupportedIOS = "ios.unsupported.exact"
    case anotherPatchActive = "patch.remote.another-active"
    case remoteUnavailable = "patch.remote.unavailable"
    case remoteInactive = "patch.remote.inactive"

    var message: String {
        switch self {
        case .unsupportedIOS: return "Versão do iOS não suportada"
        case .anotherPatchActive: return "Desative e restaure o patch ativo antes de ativar outro."
        case .remoteUnavailable: return "Não foi possível validar o catálogo remoto. Tente novamente."
        case .remoteInactive: return "Este patch não está ativo no catálogo remoto."
        }
    }
}

@MainActor
enum LuccheseActivationPolicy {
    static func blockReason(
        for projectID: UUID,
        api: LuccheseAPI,
        store: PatchProjectStore
    ) async -> LuccheseActivationBlock? {
        guard LuccheseAPI.isIOSSupported else { return .unsupportedIOS }
        if store.items.contains(where: { item in
            item.id != projectID && DevicePatchService.latestReceipt(projectID: item.id) != nil
        }) {
            return .anotherPatchActive
        }
        guard let remoteID = api.mappings.first(where: {
            UUID(uuidString: $0.value) == projectID
        })?.key else {
            return .remoteUnavailable
        }
        let status = await api.currentStatus(remoteID: remoteID)
        guard status == .ativo else {
            return api.networkAvailable ? .remoteInactive : .remoteUnavailable
        }
        return nil
    }
}

@MainActor
final class LuccheseAPI: ObservableObject {
    @Published private(set) var catalog: [LuccheseRemotePatch] = []
    @Published private(set) var announcements: [LuccheseAnnouncement] = []
    @Published private(set) var lastSync: Date?
    @Published private(set) var networkAvailable = false
    @Published private(set) var errorMessage: String?
    @Published private(set) var mappings: [String: String] =
        UserDefaults.standard.dictionary(forKey: "Lucchese.remotePatchUUIDMap.v1") as? [String: String] ?? [:]
    @Published private(set) var automaticImportPackageID: UUID?

    private let session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 30
        configuration.timeoutIntervalForResource = 180
        return URLSession(configuration: configuration)
    }()

    private var baseURL: URL? { LuccheseAPIConfiguration.baseURL }

    func refresh() async {
        do {
            guard let baseURL,
                  baseURL.scheme?.lowercased() == "https",
                  baseURL.host != nil else {
                throw LuccheseAPIError.notConfigured
            }

            var request = URLRequest(url: baseURL.appendingPathComponent("api/mobile/catalog"))
            request.cachePolicy = .reloadIgnoringLocalCacheData
            let (data, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse,
                  (200..<300).contains(http.statusCode) else {
                throw LuccheseAPIError.badResponse
            }

            let fresh = try JSONDecoder().decode(LuccheseCatalog.self, from: data).patches
            catalog = fresh
            networkAvailable = true
            lastSync = Date()
            errorMessage = nil
        } catch {
            networkAvailable = false
            errorMessage = baseURL == nil ? "Backend ainda não configurado" : "Não foi possível atualizar o catálogo"
            return // Falha fechada: nunca remove entradas com sync incompleto.
        }
    }

    func refreshAnnouncements() async {
        guard let baseURL,
              baseURL.scheme?.lowercased() == "https",
              baseURL.host != nil else { return }

        do {
            var request = URLRequest(url: baseURL.appendingPathComponent("api/mobile/announcements"))
            request.cachePolicy = .reloadIgnoringLocalCacheData
            let (data, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse,
                  (200..<300).contains(http.statusCode) else { return }
            announcements = try JSONDecoder().decode(LuccheseAnnouncements.self, from: data).announcements
        } catch {
            // Avisos indisponíveis não afetam os pacotes locais.
        }
    }

    func currentStatus(remoteID: String) async -> LucchesePatchStatus? {
        await refresh()
        guard networkAvailable else { return nil }
        return catalog.first(where: { $0.id == remoteID })?.status
    }

    func download(_ patch: LuccheseRemotePatch) async throws -> Data {
        guard let baseURL,
              baseURL.scheme?.lowercased() == "https",
              let baseHost = baseURL.host else {
            throw LuccheseAPIError.notConfigured
        }

        let fileURL = URL(string: patch.fileURL, relativeTo: baseURL)?.absoluteURL
        guard let fileURL,
              fileURL.scheme?.lowercased() == "https",
              fileURL.host == baseHost else {
            throw LuccheseAPIError.badResponse
        }

        let (data, response) = try await session.data(from: fileURL)
        guard let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode),
              http.url?.scheme?.lowercased() == "https",
              !data.isEmpty else {
            throw LuccheseAPIError.badResponse
        }
        return data
    }

    func associate(remoteID: String, internalID: UUID) {
        mappings[remoteID] = internalID.uuidString
        UserDefaults.standard.set(mappings, forKey: "Lucchese.remotePatchUUIDMap.v1")
    }

    func internalID(for remoteID: String) -> UUID? {
        mappings[remoteID].flatMap(UUID.init(uuidString:))
    }

    func clearMapping(remoteID: String) {
        mappings.removeValue(forKey: remoteID)
        UserDefaults.standard.set(mappings, forKey: "Lucchese.remotePatchUUIDMap.v1")
    }

    func markAutomaticImportStarted(packageID: UUID) {
        automaticImportPackageID = packageID
    }

    func consumeAutomaticImportSuccessAlert() -> Bool {
        guard automaticImportPackageID != nil else { return false }
        automaticImportPackageID = nil
        return true
    }

    func clearAutomaticImportIfMissing(installedIDs: Set<UUID>) {
        guard let automaticImportPackageID,
              !installedIDs.contains(automaticImportPackageID) else { return }
        self.automaticImportPackageID = nil
    }

    func clearAutomaticImport(packageID: UUID) {
        guard automaticImportPackageID == packageID else { return }
        automaticImportPackageID = nil
    }

    static var deviceDescription: String {
        LuccheseDeviceInfo.description
    }

    static var isIOSSupported: Bool {
        let version = ProcessInfo.processInfo.operatingSystemVersion
        return (version.majorVersion == 17 && (0...7).contains(version.minorVersion)) ||
            (version.majorVersion == 26 && ((0...5).contains(version.minorVersion) ||
                (version.minorVersion == 6 && version.patchVersion <= 2)))
    }
}
