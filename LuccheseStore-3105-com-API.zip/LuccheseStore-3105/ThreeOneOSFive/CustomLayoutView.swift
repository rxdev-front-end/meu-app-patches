import SwiftUI
import UniformTypeIdentifiers

struct CustomLayoutView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var patchStore: PatchProjectStore
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @StateObject private var luccheseAPI = LuccheseAPI()

    @AppStorage("sexystore.patchDisplayNames.v1") private var displayNamesJSON = "{}"
    @State private var isImporting = false
    @State private var selectedPatch: PatchLibraryItem?
    @State private var toggleOverrides: [UUID: Bool] = [:]
    @State private var workingIDs = Set<UUID>()
    @State private var toggleConfirmation: PendingToggleConfirmation?
    @State private var injectionState: InjectionState?
    @State private var isLaunching = true
    @State private var backgroundShift = false

    private let navy = Color(red: 0.008, green: 0.018, blue: 0.065)
    private let blue = Color(red: 0.12, green: 0.40, blue: 1.0)

    private var displayNames: [String: String] {
        guard let data = displayNamesJSON.data(using: .utf8),
              let names = try? JSONDecoder().decode([String: String].self, from: data) else {
            return [:]
        }
        return names
    }

    var body: some View {
        TabView {
            patchesPage
                .tabItem {
                    Label("Patches", systemImage: "square.stack.3d.up.fill")
                }

            tutorialPage
                .tabItem {
                    Label("Tutorial", systemImage: "book.closed.fill")
                }

            announcementsPage
                .tabItem { Label("Avisos", systemImage: "bell.fill") }
        }
        .tint(blue)
        .preferredColorScheme(.dark)
        .sheet(isPresented: $isImporting) {
            FileDocumentPicker(
                allowedContentTypes: [
                    UTType(filenameExtension: "3105") ?? .data,
                    .data
                ],
                copiesSelectedDocument: true,
                allowsMultipleSelection: false,
                onSelection: { result in
                    isImporting = false
                    switch result {
                    case .success(let urls):
                        guard let url = urls.first else { return }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                            patchStore.importPackage(at: url)
                        }
                    case .failure(let error):
                        let cocoaError = error as NSError
                        guard !(error is CancellationError), cocoaError.code != 3072 else { return }
                        patchStore.presentImportError(.unsupportedFormat)
                    }
                },
                onCancel: {
                    isImporting = false
                }
            )
            .ignoresSafeArea()
        }
        .patchStorePresentation(patchStore)
        .alert(item: Binding(
            get: {
                guard patchStore.alert?.messageKey == "patch.imported_message",
                      luccheseAPI.automaticImportPackageID != nil else { return patchStore.alert }
                return nil
            },
            set: { patchStore.alert = $0 }
        )) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(LuccheseActivationBlock(rawValue: alert.messageKey)?.message ?? alert.message(language: language)),
                dismissButton: .default(Text("OK"))
            )
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { _ in
            guard let request = patchDraftCoordinator.importRequest else { return }
            patchStore.importPackage(from: request.source)
            patchDraftCoordinator.clearImport()
        }
        .onChange(of: patchStore.items.map(\.id)) { _ in
            toggleOverrides = toggleOverrides.filter { id, _ in
                patchStore.items.contains(where: { $0.id == id })
            }
            removeAliasesForMissingPatches()
        }
        .onChange(of: patchStore.alert?.id) { _ in
            guard patchStore.alert?.messageKey == "patch.imported_message",
                  luccheseAPI.consumeAutomaticImportSuccessAlert() else { return }
            patchStore.alert = nil
        }
        .onChange(of: patchStore.passwordRequest?.summary.packageID) { packageID in
            guard packageID == nil else { return }
            luccheseAPI.clearAutomaticImportIfMissing(installedIDs: Set(patchStore.items.map(\.id)))
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            Task { await refreshFromAPI() }
        }
    }

    private var patchesPage: some View {
        ZStack {
            background

            VStack(spacing: 0) {
                header

                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 22) {
                        collectionHeading

                        if patchStore.items.isEmpty {
                            emptyState
                        } else {
                            LazyVStack(spacing: 13) {
                                ForEach(patchStore.items) { item in
                                    patchRow(item)
                                        .transition(.opacity.combined(with: .move(edge: .top)))
                                }
                            }
                            .animation(.spring(response: 0.38, dampingFraction: 0.86), value: patchStore.items.map(\.id))
                        }

                        developerSignature
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 17)
                    .padding(.bottom, 28)
                }
                .refreshable { await refreshFromAPI() }
            }
        }
        .overlay {
            if let injectionState {
                InjectionOverlay(state: injectionState)
                    .transition(.opacity)
                    .zIndex(2)
            }
        }
        .overlay {
            if isLaunching {
                StoreLaunchOverlay()
                    .transition(.opacity)
                    .zIndex(3)
            }
        }
        .alert(item: $toggleConfirmation) { confirmation in
            if confirmation.isBlocked {
                return Alert(
                    title: Text("Um patch por vez"),
                    message: Text("Desative e restaure o patch ativo antes de ativar outro."),
                    dismissButton: .default(Text("OK"))
                )
            }
            if confirmation.isEnabling {
                return Alert(
                    title: Text("Aplicar patch?"),
                    message: Text("Deseja aplicar “\(displayName(for: confirmation.item))” agora?"),
                    primaryButton: .default(Text("Aplicar")) {
                        setEnabled(true, for: confirmation.item)
                    },
                    secondaryButton: .cancel(Text("Cancelar"))
                )
            }
            return Alert(
                title: Text("Restaurar patch?"),
                message: Text("Deseja restaurar os arquivos e desativar “\(displayName(for: confirmation.item))”?"),
                primaryButton: .destructive(Text("Restore")) {
                    setEnabled(false, for: confirmation.item)
                },
                secondaryButton: .cancel(Text("Cancelar"))
            )
        }
        .onAppear {
            Task { await refreshFromAPI() }
            backgroundShift = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                withAnimation(.easeOut(duration: 0.45)) {
                    isLaunching = false
                }
            }
        }
        .task {
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 120_000_000_000)
                guard !Task.isCancelled, scenePhase == .active else { continue }
                await refreshFromAPI()
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .sheet(item: $selectedPatch) { item in
            PatchManagementSheet(
                item: item,
                displayName: displayName(for: item),
                isApplied: isApplied(item),
                onRename: { newName in
                    saveDisplayName(newName, for: item)
                    selectedPatch = nil
                },
                onDelete: {
                    deletePatch(item)
                }
            )
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
        }
    }

    private var announcementsPage: some View {
        ZStack { background; ScrollView { VStack(alignment: .leading, spacing: 14) {
            Text("Avisos").font(.system(size: 27, weight: .bold, design: .rounded)).foregroundStyle(.white).padding(.top, 22)
            HStack { Text(LuccheseDeviceInfo.description); Spacer(); Text(luccheseAPI.networkAvailable ? "Catálogo atualizado" : "Catálogo indisponível") }
                .font(.caption).foregroundStyle(.white.opacity(0.62))
            if !LuccheseAPI.isIOSSupported {
                Text("Versão do iOS não suportada").font(.subheadline.weight(.semibold)).foregroundStyle(.orange)
            }
            if luccheseAPI.announcements.isEmpty { Text("Nenhum aviso disponível.").foregroundStyle(.white.opacity(0.65)).padding(.vertical, 30) }
            ForEach(luccheseAPI.announcements) { announcement in
                VStack(alignment: .leading, spacing: 8) { Text(announcement.title).font(.headline).foregroundStyle(.white); Text(announcement.message).font(.subheadline).foregroundStyle(.white.opacity(0.78)); Text(announcement.createdAt).font(.caption).foregroundStyle(.white.opacity(0.42)) }
                    .padding(16).frame(maxWidth: .infinity, alignment: .leading).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
            }
            developerSignature
        }.padding(.horizontal, 20) } }
        .refreshable { await LuccheseCatalogSync.synchronize(api: luccheseAPI, store: patchStore); await luccheseAPI.refreshAnnouncements() }
    }

    private var tutorialPage: some View {
        ZStack {
            background

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 22) {
                    HStack(spacing: 14) {
                        Image(systemName: "book.closed.fill")
                            .font(.system(size: 21, weight: .semibold))
                            .foregroundStyle(.white)
                            .frame(width: 50, height: 50)
                            .background(blue.opacity(0.8), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                            .shadow(color: blue.opacity(0.32), radius: 18, y: 7)

                        VStack(alignment: .leading, spacing: 4) {
                            Text("Tutorial")
                                .font(.system(size: 27, weight: .bold, design: .rounded))
                                .foregroundStyle(.white)
                            Text("LUCCHESE STORE")
                                .font(.system(size: 10, weight: .bold, design: .rounded))
                                .tracking(2.3)
                                .foregroundStyle(Color(red: 0.58, green: 0.76, blue: 1.0))
                        }
                    }
                    .padding(.top, 20)

                    VStack(alignment: .leading, spacing: 18) {
                        Text("COMO USAR")
                            .font(.system(size: 11, weight: .bold, design: .rounded))
                            .tracking(2.2)
                            .foregroundStyle(.white.opacity(0.5))

                        tutorialStep(number: "01", text: "Entre no Free Fire e aguarde o carregamento até 40%.", symbol: "gamecontroller.fill")
                        tutorialStep(number: "02", text: "Volte ao aplicativo e ative o patch desejado.", symbol: "switch.2")
                        tutorialStep(number: "03", text: "Retorne ao jogo e, quando chegar ao lobby, desative o patch.", symbol: "arrow.uturn.backward")
                    }
                    .padding(20)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).strokeBorder(.white.opacity(0.09), lineWidth: 1))

                    HStack(alignment: .top, spacing: 13) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.system(size: 19, weight: .semibold))
                            .foregroundStyle(Color(red: 1.0, green: 0.72, blue: 0.28))
                        Text("Usar de forma indevida pode ocasionar banimentos.")
                            .font(.system(size: 14, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.88))
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(17)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.orange.opacity(0.10), in: RoundedRectangle(cornerRadius: 19, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 19, style: .continuous).strokeBorder(Color.orange.opacity(0.20), lineWidth: 1))

                    developerSignature
                        .frame(maxWidth: .infinity)
                        .padding(.top, 4)
                        .padding(.bottom, 24)
                }
                .padding(.horizontal, 20)
            }
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    private func tutorialStep(number: String, text: String, symbol: String) -> some View {
        HStack(alignment: .top, spacing: 13) {
            ZStack {
                Circle().fill(blue.opacity(0.17))
                Text(number)
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .foregroundStyle(Color(red: 0.62, green: 0.79, blue: 1.0))
            }
            .frame(width: 34, height: 34)

            VStack(alignment: .leading, spacing: 7) {
                Image(systemName: symbol)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(Color(red: 0.58, green: 0.76, blue: 1.0))
                Text(text)
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.9))
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
    }

    private var developerSignature: some View {
        HStack(spacing: 4) {
            Text("Desenvolvido por")
                .foregroundStyle(.white.opacity(0.45))
            Text("@lucchese")
                .foregroundStyle(Color(red: 0.58, green: 0.76, blue: 1.0))
        }
        .font(.system(size: 12, weight: .semibold, design: .rounded))
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
    }

    private var background: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.015, green: 0.12, blue: 0.36), navy, Color(red: 0.005, green: 0.008, blue: 0.025)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            Circle()
                .fill(blue.opacity(0.22))
                .frame(width: 320, height: 320)
                .blur(radius: 100)
                .offset(x: backgroundShift ? 150 : 110, y: backgroundShift ? -305 : -345)
            Circle()
                .fill(Color.cyan.opacity(0.11))
                .frame(width: 250, height: 250)
                .blur(radius: 95)
                .offset(x: backgroundShift ? -145 : -175, y: backgroundShift ? 135 : 80)
        }
        .animation(.easeInOut(duration: 8).repeatForever(autoreverses: true), value: backgroundShift)
        .ignoresSafeArea()
    }

    private var header: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(.ultraThinMaterial)
                    .overlay(Circle().strokeBorder(.white.opacity(0.14), lineWidth: 1))
                Circle()
                    .fill(LinearGradient(
                        colors: [blue.opacity(0.34), blue.opacity(0.08)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ))
                Image(systemName: "person.fill")
                    .font(.system(size: 24, weight: .medium))
                    .foregroundStyle(.white)
            }
            .frame(width: 56, height: 56)
            .shadow(color: blue.opacity(0.18), radius: 16, y: 7)

            VStack(alignment: .leading, spacing: 4) {
                Text("Patches")
                    .font(.system(size: 27, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .accessibilityAddTraits(.isHeader)
                Text("LUCCHESE STORE")
                    .font(.system(size: 11, weight: .bold, design: .rounded))
                    .tracking(3.1)
                    .foregroundStyle(Color(red: 0.50, green: 0.70, blue: 1.0))
                Text(LuccheseDeviceInfo.description)
                    .font(.system(size: 9, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55))
            }

            Spacer(minLength: 4)

            Button {
                isImporting = true
            } label: {
                Group {
                    if patchStore.isBusy {
                        ProgressView().tint(.white)
                    } else {
                        Image(systemName: "plus")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundStyle(.white)
                    }
                }
                .frame(width: 46, height: 46)
                .background(.ultraThinMaterial, in: Circle())
                .overlay(Circle().strokeBorder(.white.opacity(0.14), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .disabled(patchStore.isBusy)
            .accessibilityLabel("Importar patch")
        }
        .padding(.horizontal, 22)
        .padding(.top, 12)
        .padding(.bottom, 16)
    }

    private var collectionHeading: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 4) {
                Text("SUA COLEÇÃO")
                    .font(.system(size: 11, weight: .bold, design: .rounded))
                    .tracking(2.2)
                    .foregroundStyle(.white.opacity(0.48))
                Text(patchCountText)
                    .font(.system(size: 15, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.82))
            }
            Spacer()
            HStack(spacing: 6) {
                Image(systemName: LuccheseAPI.isIOSSupported ? "checkmark.seal.fill" : "xmark.seal.fill")
                Text(LuccheseAPI.isIOSSupported ? "iOS compatível" : "iOS incompatível")
            }
            .font(.system(size: 11, weight: .semibold, design: .rounded))
            .foregroundStyle(LuccheseAPI.isIOSSupported ? Color.green : Color.orange)
            .padding(.horizontal, 11)
            .padding(.vertical, 8)
            .background((LuccheseAPI.isIOSSupported ? Color.green : Color.orange).opacity(0.11), in: Capsule())
        }
        .padding(.horizontal, 2)
    }

    private var patchCountText: String {
        let count = patchStore.items.count
        return count == 1 ? "1 patch importado" : "\(count) patches importados"
    }

    private func refreshFromAPI() async {
        await LuccheseCatalogSync.synchronize(api: luccheseAPI, store: patchStore)
        await luccheseAPI.refreshAnnouncements()
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "square.stack.3d.up")
                .font(.system(size: 34, weight: .light))
                .foregroundStyle(blue.opacity(0.95))
                .symbolRenderingMode(.hierarchical)
                .frame(width: 72, height: 72)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).strokeBorder(.white.opacity(0.09), lineWidth: 1))

            Text("Nenhum patch importado")
                .font(.system(size: 18, weight: .semibold, design: .rounded))
                .foregroundStyle(.white)
            Text("Toque no + para adicionar um patch à sua coleção.")
                .font(.system(size: 14, weight: .regular, design: .rounded))
                .foregroundStyle(.white.opacity(0.56))
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)

            Button {
                isImporting = true
            } label: {
                Label("Importar patch", systemImage: "plus")
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 12)
                    .background(blue.opacity(0.82), in: Capsule())
            }
            .buttonStyle(.plain)
            .disabled(patchStore.isBusy)
            .padding(.top, 3)
        }
        .frame(maxWidth: .infinity)
        .padding(.horizontal, 22)
        .padding(.vertical, 38)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .strokeBorder(.white.opacity(0.09), lineWidth: 1)
        }
        .accessibilityElement(children: .contain)
    }

    private func patchRow(_ item: PatchLibraryItem) -> some View {
        HStack(spacing: 12) {
            Button {
                selectedPatch = item
            } label: {
                HStack(spacing: 13) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 15, style: .continuous)
                            .fill(LinearGradient(
                                colors: [blue.opacity(0.28), blue.opacity(0.10)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ))
                        Image(systemName: "square.stack.3d.up.fill")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundStyle(Color(red: 0.58, green: 0.76, blue: 1.0))
                    }
                    .frame(width: 48, height: 48)

                    VStack(alignment: .leading, spacing: 5) {
                        Text(displayName(for: item))
                            .font(.system(size: 15, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(2)
                            .multilineTextAlignment(.leading)
                        if let remote = remotePatch(for: item) {
                            HStack(spacing: 7) {
                                Text(remote.status.rawValue.capitalized)
                                Text(remote.risk ? "Risco elevado" : "Risco baixo")
                                    .foregroundStyle(remote.risk ? Color.orange : Color.green)
                            }
                            .font(.system(size: 10, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.58))
                            if let note = remote.note, !note.isEmpty {
                                Text(note).font(.system(size: 10)).foregroundStyle(.white.opacity(0.48)).lineLimit(2)
                            }
                        } else if remoteID(for: item) != nil {
                            Text(isApplied(item) ? "Removido do catálogo · restaure para remover" : "Removido do catálogo")
                                .font(.system(size: 11, weight: .medium, design: .rounded))
                                .foregroundStyle(.orange.opacity(0.86))
                        } else {
                            Text("Toque para gerenciar")
                                .font(.system(size: 11, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.43))
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)

                    Image(systemName: "ellipsis")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(.white.opacity(0.42))
                        .padding(.trailing, 2)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityHint("Abre as opções para renomear ou excluir")

            Toggle(
                displayName(for: item),
                isOn: Binding(
                    get: { toggleOverrides[item.id] ?? isApplied(item) },
                    set: { requestToggle($0, for: item) }
                )
            )
            .labelsHidden()
            .tint(blue)
            .disabled(
                item.project == nil || !workingIDs.isEmpty || patchStore.isBusy ||
                    (!isApplied(item) && remotePatch(for: item)?.status != .ativo)
            )
            .accessibilityLabel(displayName(for: item))
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 13)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .strokeBorder(.white.opacity(0.085), lineWidth: 1)
        }
        .shadow(color: blue.opacity(0.06), radius: 18, y: 8)
        .contextMenu {
            Button {
                selectedPatch = item
            } label: {
                Label("Renomear ou excluir", systemImage: "ellipsis.circle")
            }
        }
    }

    private func canonicalName(for item: PatchLibraryItem) -> String {
        item.project?.name ?? item.packageURL.deletingPathExtension().lastPathComponent
    }

    private func displayName(for item: PatchLibraryItem) -> String {
        displayNames[item.id.uuidString] ?? canonicalName(for: item)
    }

    private func saveDisplayName(_ suppliedName: String, for item: PatchLibraryItem) {
        let name = suppliedName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { return }
        var names = displayNames
        if name == canonicalName(for: item) {
            names.removeValue(forKey: item.id.uuidString)
        } else {
            names[item.id.uuidString] = name
        }
        persistDisplayNames(names)
    }

    private func removeAliasesForMissingPatches() {
        let activeIDs = Set(patchStore.items.map { $0.id.uuidString })
        let current = displayNames
        let cleaned = current.filter { activeIDs.contains($0.key) }
        guard cleaned.count != current.count else { return }
        persistDisplayNames(cleaned)
    }

    private func persistDisplayNames(_ names: [String: String]) {
        guard let data = try? JSONEncoder().encode(names),
              let json = String(data: data, encoding: .utf8) else { return }
        displayNamesJSON = json
    }

    private func remoteID(for item: PatchLibraryItem) -> String? {
        luccheseAPI.mappings.first(where: { UUID(uuidString: $0.value) == item.id })?.key
    }

    private func remotePatch(for item: PatchLibraryItem) -> LuccheseRemotePatch? {
        guard let remoteID = remoteID(for: item) else { return nil }
        return luccheseAPI.catalog.first(where: { $0.id == remoteID })
    }
    private func isApplied(_ item: PatchLibraryItem) -> Bool {
        DevicePatchService.latestReceipt(projectID: item.id) != nil
    }

    private func hasAnotherAppliedPatch(excluding item: PatchLibraryItem) -> Bool {
        patchStore.items.contains { other in
            other.id != item.id && isApplied(other)
        }
    }

    private func requestToggle(_ enabled: Bool, for item: PatchLibraryItem) {
        guard workingIDs.isEmpty, !patchStore.isBusy else { return }
        if enabled {
            Task {
                if let block = await LuccheseActivationPolicy.blockReason(
                    for: item.id,
                    api: luccheseAPI,
                    store: patchStore
                ) {
                    if block == .anotherPatchActive {
                        presentToggleConfirmation(item, enabled: true)
                    } else {
                        patchStore.alert = PatchStoreAlert(titleKey: "common.failed", messageKey: block.rawValue)
                    }
                    return
                }
                presentToggleConfirmation(item, enabled: true)
            }
            return
        }
        presentToggleConfirmation(item, enabled: false)
    }

    private func presentToggleConfirmation(_ item: PatchLibraryItem, enabled: Bool) {
        let isBlocked = enabled && hasAnotherAppliedPatch(excluding: item)
        toggleConfirmation = PendingToggleConfirmation(item: item, isEnabling: enabled, isBlocked: isBlocked)
    }
    private func deletePatch(_ item: PatchLibraryItem) {
        guard !isApplied(item) else {
            patchStore.alert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: "patch.error.active_delete"
            )
            return
        }
        patchStore.delete(item)
        guard !patchStore.items.contains(where: { $0.id == item.id }) else { return }
        var names = displayNames
        names.removeValue(forKey: item.id.uuidString)
        persistDisplayNames(names)
        selectedPatch = nil
    }

    private func setEnabled(_ enabled: Bool, for item: PatchLibraryItem) {
        guard workingIDs.isEmpty, !patchStore.isBusy else { return }
        guard !enabled || !hasAnotherAppliedPatch(excluding: item) else {
            presentToggleConfirmation(item, enabled: true)
            return
        }
        if enabled, item.project == nil {
            patchStore.alert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: "patch.error.invalid_project"
            )
            return
        }
        toggleOverrides[item.id] = enabled
        workingIDs.insert(item.id)
        withAnimation(.easeInOut(duration: 0.25)) {
            injectionState = enabled ? .applying : .restoring
        }

        Task.detached(priority: .userInitiated) {
            do {
                if enabled {
                    if let block = await LuccheseActivationPolicy.blockReason(
                        for: item.id,
                        api: luccheseAPI,
                        store: patchStore
                    ) {
                        await MainActor.run {
                            toggleOverrides[item.id] = nil; workingIDs.remove(item.id); injectionState = nil
                            patchStore.alert = PatchStoreAlert(titleKey: "common.failed", messageKey: block.rawValue)
                        }
                        return
                    }
                    guard let baseProject = item.project else {
                        throw PatchPackageError.invalidProject
                    }
                    let project = item.summary.schemaVersion >= 2 && item.canInspectContents
                        ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                        : baseProject
                    _ = try DevicePatchService.apply(project: project)
                } else if let receipt = DevicePatchService.latestReceipt(projectID: item.id) {
                    try DevicePatchService.restore(receipt: receipt)
                }
                await MainActor.run {
                    patchStore.reload()
                    if !enabled, let pair = luccheseAPI.mappings.first(where: { UUID(uuidString: $0.value) == item.id }),
                       !luccheseAPI.catalog.contains(where: { $0.id == pair.key }) {
                        LuccheseCatalogSync.removeOrphanAfterRestore(remoteID: pair.key, api: luccheseAPI, store: patchStore)
                    }
                    toggleOverrides[item.id] = nil
                    workingIDs.remove(item.id)
                    withAnimation(.easeOut(duration: 0.25)) {
                        injectionState = nil
                    }
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    toggleOverrides[item.id] = nil
                    workingIDs.remove(item.id)
                    withAnimation(.easeOut(duration: 0.25)) {
                        injectionState = nil
                    }
                    patchStore.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    toggleOverrides[item.id] = nil
                    workingIDs.remove(item.id)
                    withAnimation(.easeOut(duration: 0.25)) {
                        injectionState = nil
                    }
                    patchStore.alert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: enabled ? "patch.error.apply" : "patch.error.restore"
                    )
                }
            }
        }
    }
}

private struct PendingToggleConfirmation: Identifiable {
    let id = UUID()
    let item: PatchLibraryItem
    let isEnabling: Bool
    let isBlocked: Bool
}

private enum InjectionState: Equatable {
    case applying
    case restoring

    var title: String {
        switch self {
        case .applying: return "INJETANDO"
        case .restoring: return "RESTAURANDO"
        }
    }

    var subtitle: String {
        switch self {
        case .applying: return "Aplicando patch com segurança…"
        case .restoring: return "Restaurando os arquivos originais…"
        }
    }
}

private struct StoreLaunchOverlay: View {
    @State private var isAnimating = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.015, green: 0.12, blue: 0.36), Color(red: 0.008, green: 0.018, blue: 0.065), .black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 20) {
                ZStack {
                    Circle()
                        .stroke(.white.opacity(0.08), lineWidth: 1)
                        .frame(width: 112, height: 112)
                    Circle()
                        .trim(from: 0.08, to: 0.78)
                        .stroke(
                            AngularGradient(colors: [.cyan.opacity(0.15), Color(red: 0.25, green: 0.56, blue: 1), .white], center: .center),
                            style: StrokeStyle(lineWidth: 3, lineCap: .round)
                        )
                        .frame(width: 112, height: 112)
                        .rotationEffect(.degrees(isAnimating ? 360 : 0))
                        .animation(.linear(duration: 1.5).repeatForever(autoreverses: false), value: isAnimating)

                    Circle()
                        .fill(Color(red: 0.10, green: 0.38, blue: 0.95).opacity(0.22))
                        .frame(width: 76, height: 76)
                        .scaleEffect(isAnimating ? 1.08 : 0.92)
                        .animation(.easeInOut(duration: 1.1).repeatForever(autoreverses: true), value: isAnimating)
                    Image(systemName: "square.stack.3d.up.fill")
                        .font(.system(size: 28, weight: .medium))
                        .foregroundStyle(.white)
                        .shadow(color: .cyan.opacity(0.7), radius: 16)
                }

                VStack(spacing: 7) {
                    Text("LUCCHESE STORE")
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                        .tracking(3)
                        .foregroundStyle(.white)
                    Text("INICIALIZANDO")
                        .font(.system(size: 10, weight: .semibold, design: .rounded))
                        .tracking(2.6)
                        .foregroundStyle(Color(red: 0.58, green: 0.76, blue: 1.0))
                }
            }
        }
        .onAppear { isAnimating = true }
        .accessibilityElement(children: .combine)
    }
}

private struct InjectionOverlay: View {
    let state: InjectionState
    @State private var isAnimating = false

    var body: some View {
        ZStack {
            Rectangle()
                .fill(.black.opacity(0.48))
                .background(.ultraThinMaterial)
                .ignoresSafeArea()

            VStack(spacing: 18) {
                ZStack {
                    Circle()
                        .stroke(.white.opacity(0.10), lineWidth: 1)
                        .frame(width: 116, height: 116)
                    Circle()
                        .trim(from: 0.06, to: 0.72)
                        .stroke(
                            AngularGradient(colors: [.cyan.opacity(0.12), Color(red: 0.20, green: 0.48, blue: 1), .white], center: .center),
                            style: StrokeStyle(lineWidth: 3, lineCap: .round)
                        )
                        .frame(width: 116, height: 116)
                        .rotationEffect(.degrees(isAnimating ? 360 : 0))
                        .animation(.linear(duration: 1.25).repeatForever(autoreverses: false), value: isAnimating)
                    Circle()
                        .fill(Color(red: 0.12, green: 0.42, blue: 1).opacity(0.20))
                        .frame(width: 82, height: 82)
                        .scaleEffect(isAnimating ? 1.10 : 0.90)
                        .animation(.easeInOut(duration: 0.9).repeatForever(autoreverses: true), value: isAnimating)
                    Image(systemName: state == .applying ? "bolt.fill" : "arrow.uturn.backward")
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundStyle(.white)
                        .shadow(color: .cyan.opacity(0.72), radius: 17)
                }

                VStack(spacing: 7) {
                    Text(state.title)
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .tracking(3)
                        .foregroundStyle(.white)
                    Text(state.subtitle)
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.66))
                        .multilineTextAlignment(.center)
                }
                ProgressView()
                    .tint(Color(red: 0.58, green: 0.76, blue: 1.0))
                    .padding(.top, 2)
            }
            .padding(28)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).strokeBorder(.white.opacity(0.13), lineWidth: 1))
            .shadow(color: Color.blue.opacity(0.22), radius: 35, y: 12)
            .padding(.horizontal, 38)
        }
        .onAppear { isAnimating = true }
        .accessibilityElement(children: .combine)
    }
}

private struct PatchManagementSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var editedName: String
    @State private var isRenaming = false
    @State private var isConfirmingDelete = false

    let item: PatchLibraryItem
    let displayName: String
    let isApplied: Bool
    let onRename: (String) -> Void
    let onDelete: () -> Void

    init(
        item: PatchLibraryItem,
        displayName: String,
        isApplied: Bool,
        onRename: @escaping (String) -> Void,
        onDelete: @escaping () -> Void
    ) {
        self.item = item
        self.displayName = displayName
        self.isApplied = isApplied
        self.onRename = onRename
        self.onDelete = onDelete
        _editedName = State(initialValue: displayName)
    }

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    colors: [Color(red: 0.015, green: 0.12, blue: 0.36), Color(red: 0.008, green: 0.018, blue: 0.065), .black],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                VStack(spacing: 18) {
                    Image(systemName: "square.stack.3d.up.fill")
                        .font(.system(size: 24, weight: .medium))
                        .foregroundStyle(Color(red: 0.58, green: 0.76, blue: 1.0))
                        .frame(width: 62, height: 62)
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 21, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 21, style: .continuous).strokeBorder(.white.opacity(0.1), lineWidth: 1))

                    if isRenaming {
                        VStack(spacing: 14) {
                            TextField("Nome exibido", text: $editedName)
                                .textInputAutocapitalization(.words)
                                .autocorrectionDisabled()
                                .padding(.horizontal, 15)
                                .padding(.vertical, 13)
                                .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).strokeBorder(.white.opacity(0.1), lineWidth: 1))

                            Button {
                                let name = editedName.trimmingCharacters(in: .whitespacesAndNewlines)
                                guard !name.isEmpty else { return }
                                onRename(name)
                            } label: {
                                Text("Salvar nome")
                                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                                    .foregroundStyle(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 13)
                                    .background(Color(red: 0.20, green: 0.52, blue: 0.98), in: Capsule())
                            }
                            .buttonStyle(.plain)
                            .disabled(editedName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        }
                    } else {
                        Text(displayName)
                            .font(.system(size: 19, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .multilineTextAlignment(.center)
                            .lineLimit(3)

                        VStack(spacing: 10) {
                            Button {
                                isRenaming = true
                            } label: {
                                Label("Renomear nome exibido", systemImage: "pencil")
                                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                                    .foregroundStyle(.white)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 14)
                                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).strokeBorder(.white.opacity(0.1), lineWidth: 1))
                            }
                            .buttonStyle(.plain)

                            Button(role: .destructive) {
                                isConfirmingDelete = true
                            } label: {
                                Label("Excluir patch", systemImage: "trash")
                                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                                    .foregroundStyle(Color(red: 1.0, green: 0.42, blue: 0.45))
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 14)
                                    .background(Color.red.opacity(0.11), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).strokeBorder(Color.red.opacity(0.18), lineWidth: 1))
                            }
                            .buttonStyle(.plain)
                            .disabled(isApplied)

                            if isApplied {
                                Text("Desative o patch e restaure os arquivos antes de excluí-lo.")
                                    .font(.system(size: 12, weight: .medium, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.55))
                                    .multilineTextAlignment(.center)
                            }
                        }
                    }

                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 24)
                .padding(.top, 18)
            }
            .navigationTitle(isRenaming ? "Renomear patch" : "Gerenciar patch")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(isRenaming ? "Cancelar" : "OK") {
                        if isRenaming {
                            isRenaming = false
                            editedName = displayName
                        } else {
                            dismiss()
                        }
                    }
                    .foregroundStyle(Color(red: 0.58, green: 0.76, blue: 1.0))
                }
            }
            .confirmationDialog(
                "Excluir este patch?",
                isPresented: $isConfirmingDelete,
                titleVisibility: .visible
            ) {
                Button("Excluir patch", role: .destructive) {
                    onDelete()
                }
                Button("Cancelar", role: .cancel) {}
            } message: {
                Text("O pacote e o nome personalizado serão removidos deste aplicativo.")
            }
        }
        .preferredColorScheme(.dark)
    }
}
