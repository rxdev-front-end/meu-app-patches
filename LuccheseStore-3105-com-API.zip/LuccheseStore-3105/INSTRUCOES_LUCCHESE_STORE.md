# Integração Lucchese Store — 3105

O projeto contém o cliente da API e sincroniza patches/avisos automaticamente ao abrir o app, ao voltar para primeiro plano e por atualização periódica enquanto o app permanece ativo. Também é possível puxar a lista para atualizar manualmente.

## URL da API

Em `ThreeOneOSFive/LuccheseAPI.swift`, `LuccheseAPIConfiguration.baseURL` está intencionalmente como `nil`. A API ainda não foi publicada nem recebeu autorização para publicação; por isso, o app não tenta acessar o Preview e não habilita ativações remotas sem conseguir validar o catálogo.

Somente depois de o proprietário autorizar separadamente a publicação e receber a URL HTTPS permanente, substitua `nil` pela URL raiz do site, por exemplo:

```swift
static let baseURL: URL? = URL(string: "https://DOMINIO-PUBLICADO")
```

Use somente o domínio HTTPS permanente, sem acrescentar `/api`. Não use a URL de Preview. O cliente valida HTTPS e usa `GET /api/mobile/catalog`, `GET /api/mobile/patches/{id}/file` e `GET /api/mobile/announcements`. Os endpoints móveis de leitura/download são públicos para o app; não inclua a senha administrativa no aplicativo.

## Compilação

Abra `ThreeOneOSFive.xcodeproj` em uma versão do Xcode que suporte o projeto e faça a compilação/assinatura no ambiente Apple. Este pacote foi atualizado no sandbox Linux, que não dispõe de `xcodebuild` nem de `swiftc`; portanto, nenhuma compilação iOS é declarada como concluída.
