import SwiftUI
import UIKit
import ImageIO

private enum LucchesePalette {
    private static func adaptive(dark: UIColor, light: UIColor) -> Color {
        Color(uiColor: UIColor { traits in traits.userInterfaceStyle == .dark ? dark : light })
    }
    static let background = adaptive(dark: UIColor(red: 0.035, green: 0.039, blue: 0.047, alpha: 1), light: UIColor(red: 0.965, green: 0.97, blue: 0.978, alpha: 1))
    static let surface = adaptive(dark: UIColor(red: 0.085, green: 0.090, blue: 0.102, alpha: 1), light: .white)
    static let raised = adaptive(dark: UIColor(red: 0.125, green: 0.133, blue: 0.149, alpha: 1), light: UIColor(red: 0.925, green: 0.935, blue: 0.948, alpha: 1))
    static let line = adaptive(dark: UIColor.white.withAlphaComponent(0.10), light: UIColor.black.withAlphaComponent(0.10))
    static let muted = adaptive(dark: UIColor(red: 0.57, green: 0.59, blue: 0.63, alpha: 1), light: UIColor(red: 0.43, green: 0.45, blue: 0.49, alpha: 1))
    static let soft = adaptive(dark: UIColor(red: 0.77, green: 0.78, blue: 0.81, alpha: 1), light: UIColor(red: 0.29, green: 0.31, blue: 0.34, alpha: 1))
    static let white = adaptive(dark: UIColor(red: 0.96, green: 0.96, blue: 0.97, alpha: 1), light: UIColor(red: 0.10, green: 0.11, blue: 0.13, alpha: 1))
    static let onAccent = adaptive(dark: UIColor(red: 0.08, green: 0.09, blue: 0.10, alpha: 1), light: .white)
}

private struct AnimatedBannerImage: UIViewRepresentable {
    let image: UIImage
    func makeUIView(context: Context) -> UIImageView {
        let view = UIImageView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.backgroundColor = .clear
        view.isOpaque = false
        view.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        view.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
        view.setContentHuggingPriority(.defaultLow, for: .horizontal)
        view.setContentHuggingPriority(.defaultLow, for: .vertical)
        view.animationRepeatCount = 0
        return view
    }
    func updateUIView(_ view: UIImageView, context: Context) {
        view.image = image
        view.startAnimating()
    }
}

private struct RemoteGIFBanner: View {
    let url: URL?
    @State private var image: UIImage?

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                if let image {
                    AnimatedBannerImage(image: image)
                        .frame(width: geometry.size.width, height: geometry.size.height)
                } else {
                    LinearGradient(colors: [LucchesePalette.raised, LucchesePalette.surface, LucchesePalette.background], startPoint: .topLeading, endPoint: .bottomTrailing)
                    Image(systemName: "sparkles")
                        .font(.system(size: 22, weight: .medium))
                        .foregroundStyle(LucchesePalette.muted.opacity(0.42))
                }
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
            .clipped()
            .clipShape(RoundedRectangle(cornerRadius: 23, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 23, style: .continuous)
                    .stroke(
                        LinearGradient(
                            colors: [LucchesePalette.white.opacity(0.22), LucchesePalette.line.opacity(0.65), LucchesePalette.white.opacity(0.08)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 0.9
                    )
                    .allowsHitTesting(false)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 154)
        .accessibilityLabel("Banner animado da loja")
        .task(id: url) {
            image = nil
            guard let url, url.scheme?.lowercased() == "https" else { return }
            do {
                var request = URLRequest(url: url, timeoutInterval: 12)
                request.setValue("image/gif,image/*;q=0.8", forHTTPHeaderField: "Accept")
                let (data, response) = try await URLSession.shared.data(for: request)
                guard (response as? HTTPURLResponse).map({ (200..<300).contains($0.statusCode) }) == true,
                      !data.isEmpty, data.count <= 8 * 1_024 * 1_024,
                      let source = CGImageSourceCreateWithData(data as CFData, nil) else { return }
                let count = min(CGImageSourceGetCount(source), 32)
                var frames: [UIImage] = []
                var duration: TimeInterval = 0
                for index in 0..<count {
                    let options: CFDictionary = [
                        kCGImageSourceCreateThumbnailFromImageAlways: true,
                        kCGImageSourceThumbnailMaxPixelSize: 640,
                        kCGImageSourceCreateThumbnailWithTransform: true
                    ] as CFDictionary
                    guard let cgImage = CGImageSourceCreateThumbnailAtIndex(source, index, options) else { continue }
                    frames.append(UIImage(cgImage: cgImage))
                    let properties = CGImageSourceCopyPropertiesAtIndex(source, index, nil) as? [CFString: Any]
                    let gif = properties?[kCGImagePropertyGIFDictionary] as? [CFString: Any]
                    let frameDelay = (gif?[kCGImagePropertyGIFUnclampedDelayTime] as? Double)
                        ?? (gif?[kCGImagePropertyGIFDelayTime] as? Double)
                        ?? 0.1
                    duration += max(0.04, frameDelay)
                }
                guard !frames.isEmpty else { return }
                let loaded = frames.count > 1 ? UIImage.animatedImage(with: frames, duration: max(duration, 0.1)) : UIImage(data: data)
                await MainActor.run { image = loaded }
            } catch { /* O banner padrão permanece visível se a URL falhar. */ }
        }
    }
}

private enum StoreTab: String, CaseIterable, Identifiable {
    case patches
    case global
    case info
    case tutorial

    var id: String { rawValue }
    var title: String {
        switch self {
        case .patches: return "Patches"
        case .global: return "Global"
        case .info: return "Info"
        case .tutorial: return "Tutorial"
        }
    }
    var icon: String {
        switch self {
        case .patches: return "square.stack.3d.up.fill"
        case .global: return "bell.badge.fill"
        case .info: return "info.circle.fill"
        case .tutorial: return "book.closed.fill"
        }
    }
    var subtitle: String {
        switch self {
        case .patches: return "Seu catálogo, organizado por categoria."
        case .global: return "Comunicados publicados pela Lucchese Store."
        case .info: return "Licença, dispositivo e estado da sessão."
        case .tutorial: return "Orientações de uso e avisos importantes."
        }
    }
}

private struct LuccheseGlassSurface<S: Shape>: ViewModifier {
    let shape: S
    let fallback: Color

    func body(content: Content) -> some View {
        Group {
            if #available(iOS 26.0, *) {
                content.background { shape.fill(.clear).glassEffect(.regular, in: shape) }
            } else {
                content.background {
                    shape.fill(.ultraThinMaterial)
                        .overlay(shape.fill(fallback.opacity(0.52)))
                }
            }
        }
        .overlay {
            shape.stroke(
                LinearGradient(
                    colors: [LucchesePalette.white.opacity(0.24), LucchesePalette.line.opacity(0.42), LucchesePalette.white.opacity(0.07)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                lineWidth: 0.8
            )
            .allowsHitTesting(false)
        }
    }
}

private extension View {
    func luccheseGlass<S: Shape>(in shape: S, fallback: Color) -> some View {
        modifier(LuccheseGlassSurface(shape: shape, fallback: fallback))
    }
}

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @ObservedObject private var remoteIntegration = RemoteIntegration.shared
    @AppStorage("lucchese.appAppearance") private var appearanceMode = "dark"

    @State private var selectedTab: StoreTab = .patches
    @State private var activeSheet: StoreSheet?
    @State private var activeOperation: PatchOperationPresentation?
    @State private var patchActionStates: [String: PatchActionState] = [:]
    @State private var passwordValue = ""
    @State private var restorePatch: RemotePatch?
    @State private var restoreChangedPaths: [String] = []
    @State private var showRestoreConfirmation = false
    @State private var showUnlinkConfirmation = false

    var body: some View {
        ZStack {
            AmbientMotionBackground()
            if remoteIntegration.isRestoringSession {
                restoringSession
                    .transition(.opacity)
            } else if let state = accessGateKind {
                AccessStatusView(state: state, service: remoteIntegration) {
                    Task { await remoteIntegration.refreshSessionNow() }
                }
                .transition(reduceMotion ? .opacity : .opacity.combined(with: .move(edge: .bottom)))
            } else if remoteIntegration.licensed {
                authenticatedStore
                    .transition(reduceMotion ? .opacity : .opacity.combined(with: .move(edge: .bottom)))
            } else {
                LuccheseKeyEntryView(service: remoteIntegration) { patch in
                    requestToggle(patch, enabled: false)
                }
                .transition(reduceMotion ? .opacity : .opacity.combined(with: .scale(scale: 0.985)))
            }
            if let activeOperation {
                PatchOperationOverlay(operation: activeOperation, reduceMotion: reduceMotion)
                    .transition(.opacity)
                    .zIndex(20)
            }
        }
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.72), value: appearanceMode)
        .preferredColorScheme(appearanceMode == "light" ? .light : .dark)
        .tint(LucchesePalette.white)
        .task {
            await remoteIntegration.restoreSavedSession()
            await remoteIntegration.monitor()
        }
        .onChange(of: remoteIntegration.licensed) { isLicensed in
            guard isLicensed else { return }
            withAnimation(reduceMotion ? nil : .spring(response: 0.36, dampingFraction: 0.86)) {
                selectedTab = .patches
            }
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            Task { await remoteIntegration.refreshSessionNow() }
        }
        .sheet(item: $activeSheet) { sheet in
            switch sheet.content {
                case let .confirmation(patch, enabled):
                    PatchConfirmationSheet(patch: patch, isInjection: enabled, onCancel: {
                        activeSheet = nil
                    }, onConfirm: {
                        activeSheet = nil
                        if !reduceMotion { UIImpactFeedbackGenerator(style: .medium).impactOccurred() }
                        Task { await performToggle(patch, enabled: enabled, riskConfirmed: enabled && patch.risk) }
                    })
            case let .details(patch):
                PatchDetailsSheet(
                    patch: patch,
                    category: categoryName(patch),
                    statusTitle: statusTitle(for: patch),
                    statusColor: statusColor(for: patch),
                    isActive: remoteIntegration.isPatchActive(patch.id)
                ) {
                    activeSheet = nil
                }
            case let .result(result):
                PatchOperationResultSheet(result: result, onClose: {
                    activeSheet = nil
                }, onRefresh: {
                    activeSheet = nil
                    Task { await remoteIntegration.refreshSessionNow() }
                })
            case let .password(patch):
                PatchPasswordSheet(
                    patchName: patch.name,
                    password: $passwordValue,
                    onCancel: {
                        remoteIntegration.discardPendingPackage(for: patch.id)
                        passwordValue = ""
                        activeSheet = nil
                    },
                    onUnlock: {
                        let value = passwordValue
                        activeSheet = nil
                        if !reduceMotion { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
                        Task { await performToggle(patch, enabled: true, password: value, riskConfirmed: true) }
                    }
                )
                .presentationDetents([.medium])
                .presentationDragIndicator(.visible)
            }
        }
        .alert("Arquivos alterados", isPresented: $showRestoreConfirmation) {
            Button("Cancelar", role: .cancel) { restorePatch = nil }
            Button("Restaurar mesmo assim", role: .destructive) {
                guard let patch = restorePatch else { return }
                Task { await performToggle(patch, enabled: false, allowChangedTargets: true) }
            }
        } message: {
            Text(restoreChangedPaths.prefix(5).joined(separator: "\n") + (restoreChangedPaths.count > 5 ? "\n…" : "") + "\n\nAlguns arquivos mudaram depois da aplicação. Restaurar substituirá essas alterações pelos backups originais.")
        }
        .alert("Desvincular dispositivo?", isPresented: $showUnlinkConfirmation) {
            Button("Cancelar", role: .cancel) {}
            Button("Desvincular", role: .destructive) {
                Task { await remoteIntegration.unlink() }
            }
        } message: {
            Text("A key deixará de estar vinculada a este aparelho. Os patches já aplicados permanecerão disponíveis para restauração local.")
        }

    }

    private var accessGateKind: AccessGateKind? {
        let status = remoteIntegration.globalStatus.lowercased()
        let code = remoteIntegration.licenseErrorCode?.lowercased()
        if status == "banned" || code == "device_banned" { return .banned }
        switch code {
        case "key_expired", "license_expired": return .keyExpired
        case "key_revoked", "license_revoked": return .keyRevoked
        case "key_not_found", "license_not_found", "key_deleted": return .keyMissing
        case "device_limit_reached", "max_devices_reached": return .deviceLimit
        case "hwid_mismatch", "device_mismatch": return .deviceMismatch
        case "license_inactive": return .keyDisabled
        case "invalid_key", "license_invalid": return .invalidKey
        case "maintenance": return .maintenance
        case "offline", "service_offline": return .offline
        case "updating", "update": return .updating
        case "old_version", "old-version": return .oldVersion
        default: break
        }
        if !remoteIntegration.isConfigured { return .configuration }
        if !remoteIntegration.hasServiceResponse { return .connection }
        guard !remoteIntegration.serviceAllowed else { return nil }
        switch status {
        case "maintenance": return .maintenance
        case "offline": return .offline
        case "updating", "update": return .updating
        case "old_version", "old-version": return .oldVersion
        case "banned": return .banned
        default: return .offline
        }
    }

    private var restoringSession: some View {
        VStack(spacing: 22) {
            LuccheseBrandMark(size: 68)
            ProgressView().tint(LucchesePalette.white).scaleEffect(1.05)
            VStack(spacing: 5) {
                Text("Verificando sua licença")
                    .font(.system(size: 19, weight: .semibold, design: .rounded))
                    .foregroundStyle(LucchesePalette.white)
                Text("\(remoteIntegration.storeName) · sessão protegida")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(LucchesePalette.muted)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(28)
    }

    private var authenticatedStore: some View {
        ZStack(alignment: .bottom) {
            VStack(spacing: 0) {
                storeHeader
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 22) {
                        switch selectedTab {
                        case .patches:
                            patchCatalog
                                .transition(reduceMotion ? .opacity : .opacity.combined(with: .move(edge: .bottom)))
                        case .global:
                            globalFeed
                                .transition(reduceMotion ? .opacity : .opacity.combined(with: .move(edge: .bottom)))
                        case .info:
                            licenseInfo
                                .transition(reduceMotion ? .opacity : .opacity.combined(with: .move(edge: .bottom)))
                        case .tutorial:
                            tutorialView
                                .transition(reduceMotion ? .opacity : .opacity.combined(with: .move(edge: .bottom)))
                        }
                        Text("DESENVOLVIDO POR @lucchese")
                            .font(.system(size: 10, weight: .semibold, design: .rounded))
                            .tracking(2.2)
                            .foregroundStyle(LucchesePalette.muted.opacity(0.8))
                            .frame(maxWidth: .infinity)
                            .padding(.top, 8)
                            .padding(.bottom, 12)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    .padding(.bottom, 104)
                }
                .refreshable { await remoteIntegration.refreshCatalog(force: true) }
            }
            bottomNavigation
                .padding(.bottom, 8)
                .zIndex(5)
        }
    }

    private var storeHeader: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(spacing: 10) {
                LuccheseBrandMark(size: 40)
                VStack(alignment: .leading, spacing: 2) {
                    Text(remoteIntegration.storeName)
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                        .foregroundStyle(LucchesePalette.white)
                    Text("LOJA DIGITAL")
                        .font(.system(size: 8, weight: .semibold, design: .rounded))
                        .tracking(2.2)
                        .foregroundStyle(LucchesePalette.muted)
                }
                Spacer(minLength: 4)
                HStack(spacing: 6) {
                    Circle().fill(remoteIntegration.serviceAllowed ? LucchesePalette.white : LucchesePalette.muted)
                        .frame(width: 5, height: 5)
                    Text(remoteIntegration.serviceAllowed ? "OK" : "SYNC")
                        .font(.system(size: 8, weight: .bold, design: .monospaced))
                        .tracking(0.8)
                        .foregroundStyle(LucchesePalette.soft)
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 7)
                .luccheseGlass(in: Capsule(), fallback: LucchesePalette.raised)
                Button {
                    withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.72)) {
                        appearanceMode = appearanceMode == "dark" ? "light" : "dark"
                    }
                } label: {
                    Image(systemName: appearanceMode == "dark" ? "sun.max.fill" : "moon.fill")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(LucchesePalette.soft)
                        .frame(width: 36, height: 36)
                        .rotationEffect(.degrees(appearanceMode == "dark" ? 0 : -90))
                        .animation(reduceMotion ? nil : .spring(response: 0.42, dampingFraction: 0.72), value: appearanceMode)
                        .luccheseGlass(in: Circle(), fallback: LucchesePalette.surface)
                        .overlay(Circle().stroke(LucchesePalette.line, lineWidth: 1))
                }
                .buttonStyle(.plain)
                .accessibilityLabel(appearanceMode == "dark" ? "Mudar para tema claro" : "Mudar para tema escuro")
                if let discordURL = remoteIntegration.discordURL {
                    Link(destination: discordURL) {
                        DiscordGlyph(size: 18)
                            .frame(width: 36, height: 36)
                            .luccheseGlass(in: Circle(), fallback: LucchesePalette.surface)
                            .overlay(Circle().stroke(LucchesePalette.line, lineWidth: 1))
                    }
                    .accessibilityLabel("Abrir comunidade no Discord")
                }
            }
            if selectedTab != .patches {
                HStack(alignment: .bottom) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(selectedTab.title)
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .tracking(-0.8)
                        .foregroundStyle(LucchesePalette.white)
                    Text(selectedTab == .global
                         ? "Comunicados publicados por \(remoteIntegration.storeName)."
                         : selectedTab.subtitle)
                        .font(.system(size: 13, weight: .regular))
                        .foregroundStyle(LucchesePalette.muted)
                }
                Spacer(minLength: 12)
                Button {
                    if !reduceMotion { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
                    Task { await remoteIntegration.refreshSessionNow() }
                } label: {
                    Group {
                        if remoteIntegration.isSyncing {
                            ProgressView().controlSize(.small).tint(LucchesePalette.white)
                        } else {
                            Image(systemName: "arrow.clockwise")
                                .font(.system(size: 14, weight: .semibold))
                        }
                    }
                    .foregroundStyle(LucchesePalette.white)
                    .frame(width: 42, height: 42)
                    .luccheseGlass(in: Circle(), fallback: LucchesePalette.surface)
                    .overlay(Circle().stroke(LucchesePalette.line, lineWidth: 1))
                }
                .disabled(remoteIntegration.isSyncing)
                .accessibilityLabel(remoteIntegration.isSyncing ? "Sincronizando" : "Sincronizar agora")
                }
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 14)
        .padding(.bottom, selectedTab == .patches ? 4 : 18)
    }

    private var patchCatalog: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                HStack(spacing: 6) {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 11, weight: .semibold))
                    Text("iOS \(remoteIntegration.iosVersion)")
                        .font(.system(size: 10, weight: .semibold, design: .rounded))
                }
                .foregroundStyle(LucchesePalette.soft)
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
                .luccheseGlass(in: Capsule(), fallback: LucchesePalette.surface)
                Spacer(minLength: 0)
                Button {
                    if !reduceMotion { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
                    Task { await remoteIntegration.refreshSessionNow() }
                } label: {
                    Group {
                        if remoteIntegration.isSyncing { ProgressView().controlSize(.small).tint(LucchesePalette.white) }
                        else { Image(systemName: "arrow.clockwise").font(.system(size: 13, weight: .semibold)) }
                    }
                    .foregroundStyle(LucchesePalette.white)
                    .frame(width: 36, height: 36)
                    .luccheseGlass(in: Circle(), fallback: LucchesePalette.surface)
                    .overlay(Circle().stroke(LucchesePalette.line, lineWidth: 1))
                }
                .disabled(remoteIntegration.isSyncing)
                .accessibilityLabel(remoteIntegration.isSyncing ? "Sincronizando" : "Sincronizar agora")
            }
            RemoteGIFBanner(url: remoteIntegration.bannerGifURL)

            if let message = remoteIntegration.gateMessage, !message.isEmpty {
                statusNotice(message, symbol: "exclamationmark.circle")
            }
            if let error = remoteIntegration.errorMessage, !error.isEmpty {
                statusNotice(error, symbol: "arrow.triangle.2.circlepath")
            }

            if sortedPatches.isEmpty {
                if sortedPatches.isEmpty && remoteIntegration.isSyncing {
                    VStack(spacing: 10) {
                        PatchSkeletonCard()
                        PatchSkeletonCard()
                    }
                    .accessibilityLabel("Carregando catálogo de patches")
                } else if sortedPatches.isEmpty && remoteIntegration.errorMessage != nil {
                    emptyState(
                        symbol: "wifi.exclamationmark",
                        title: "Não foi possível carregar",
                        message: remoteIntegration.errorMessage ?? "Confira a conexão e sincronize novamente."
                    )
                    Button {
                        if !reduceMotion { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
                        Task { await remoteIntegration.refreshSessionNow() }
                    } label: {
                        Label("Tentar sincronizar", systemImage: "arrow.clockwise")
                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                            .foregroundStyle(LucchesePalette.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 13)
                            .luccheseGlass(in: RoundedRectangle(cornerRadius: 13, style: .continuous), fallback: LucchesePalette.raised)
                    }
                    .buttonStyle(.plain)
                } else {
                    emptyState(
                        symbol: "square.stack.3d.up",
                        title: "Seu catálogo está vazio",
                        message: "Quando um patch for publicado no painel, ele aparecerá aqui, organizado pela categoria escolhida."
                    )
                }
            } else {
                ForEach(categoryNames, id: \.self) { category in
                    categorySection(category, patches: sortedPatches.filter { categoryName($0) == category })
                        .transition(reduceMotion ? .opacity : .opacity.combined(with: .move(edge: .bottom)))
                }
            }
        }
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.22), value: sortedPatches.map(\.id))
    }

    private var globalFeed: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Text("MURAL GLOBAL")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(2.2)
                    .foregroundStyle(LucchesePalette.muted)
                Spacer()
                Text("\(remoteIntegration.announcements.count) avisos")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(LucchesePalette.soft)
            }
            if remoteIntegration.announcements.isEmpty {
                emptyState(
                    symbol: "bell.slash",
                    title: "Nenhum aviso por enquanto",
                    message: "Anúncios publicados no painel aparecerão nesta aba."
                )
            } else {
                ForEach(remoteIntegration.announcements) { item in
                    VStack(alignment: .leading, spacing: 13) {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: "bell.badge.fill")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundStyle(LucchesePalette.white)
                                .frame(width: 36, height: 36)
                                .luccheseGlass(in: RoundedRectangle(cornerRadius: 12, style: .continuous), fallback: LucchesePalette.raised)
                            VStack(alignment: .leading, spacing: 5) {
                                Text(item.title)
                                    .font(.system(size: 16, weight: .semibold, design: .rounded))
                                    .foregroundStyle(LucchesePalette.white)
                                if let createdAt = item.createdAt {
                                    Text(formattedDate(createdAt))
                                        .font(.system(size: 10, weight: .medium, design: .monospaced))
                                        .foregroundStyle(LucchesePalette.muted)
                                }
                            }
                            Spacer(minLength: 0)
                        }
                        Rectangle().fill(LucchesePalette.line).frame(height: 1)
                        Text(item.message)
                            .font(.system(size: 14, weight: .regular))
                            .lineSpacing(4)
                            .foregroundStyle(LucchesePalette.soft)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(17)
                    .luccheseGlass(in: RoundedRectangle(cornerRadius: 20, style: .continuous), fallback: LucchesePalette.surface)
                    .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
                }
            }
        }
    }

    private var licenseInfo: some View {
        VStack(alignment: .leading, spacing: 17) {
            VStack(alignment: .leading, spacing: 4) {
                Text("SESSÃO E DISPOSITIVO")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(2.2)
                    .foregroundStyle(LucchesePalette.muted)
                Text("Tudo em um só lugar")
                    .font(.system(size: 17, weight: .semibold, design: .rounded))
                    .foregroundStyle(LucchesePalette.white)
            }
            VStack(spacing: 0) {
                infoRow(symbol: "storefront.fill", title: "Loja", value: remoteIntegration.storeName)
                infoDivider
                infoRow(symbol: "checkmark.shield.fill", title: "Licença", value: remoteIntegration.licensed ? "Ativa neste aparelho" : "Aguardando validação")
                infoDivider
                infoRow(symbol: "key.fill", title: "Key", value: remoteIntegration.maskedLicenseKey, monospaced: true)
                infoDivider
                infoRow(symbol: "calendar", title: "Expira em", value: formattedDate(remoteIntegration.licenseExpiresAt))
                infoDivider
                TimelineView(.periodic(from: .now, by: 1)) { timeline in
                    infoRow(
                        symbol: "timer",
                        title: "Tempo restante",
                        value: remainingLicenseTime(until: remoteIntegration.licenseExpiresAt, now: timeline.date),
                        monospaced: true
                    )
                }
                if let maxDevices = remoteIntegration.licenseMaxDevices {
                    infoDivider
                    infoRow(symbol: "iphone.gen3", title: "Limite de aparelhos", value: "\(maxDevices) \(maxDevices == 1 ? "aparelho" : "aparelhos")")
                }
                infoDivider
                infoRow(symbol: "iphone", title: "Modelo", value: remoteIntegration.deviceModelName)
                infoDivider
                infoRow(symbol: "gearshape", title: "Versão do iOS", value: remoteIntegration.iosVersion)
                infoDivider
                infoRow(symbol: "number", title: "ID do aparelho", value: "••••\(remoteIntegration.deviceIdentifierSuffix)", monospaced: true)
                infoDivider
                infoRow(symbol: "arrow.triangle.2.circlepath", title: "Última verificação", value: formattedDate(remoteIntegration.lastVerifiedAt))
            }
            .padding(.horizontal, 16)
            .luccheseGlass(in: RoundedRectangle(cornerRadius: 20, style: .continuous), fallback: LucchesePalette.surface)
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))

            if let discordURL = remoteIntegration.discordURL {
                Link(destination: discordURL) {
                    HStack(spacing: 12) {
                        DiscordGlyph(size: 20)
                            .frame(width: 40, height: 40)
                            .luccheseGlass(in: RoundedRectangle(cornerRadius: 13, style: .continuous), fallback: LucchesePalette.raised)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Comunidade no Discord")
                                .font(.system(size: 13, weight: .semibold, design: .rounded))
                                .foregroundStyle(LucchesePalette.white)
                            Text("Suporte e novidades da loja")
                                .font(.system(size: 10, weight: .medium))
                                .foregroundStyle(LucchesePalette.muted)
                        }
                        Spacer()
                        Image(systemName: "arrow.up.right")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(LucchesePalette.muted)
                    }
                    .padding(13)
                    .luccheseGlass(in: RoundedRectangle(cornerRadius: 17, style: .continuous), fallback: LucchesePalette.surface)
                    .overlay(RoundedRectangle(cornerRadius: 17, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
                }
            }

            Button {
                showUnlinkConfirmation = true
            } label: {
                HStack(spacing: 9) {
                    Image(systemName: "rectangle.portrait.and.arrow.right")
                    Text("Desvincular dispositivo")
                    Spacer()
                    Image(systemName: "arrow.up.right")
                        .font(.system(size: 10, weight: .semibold))
                }
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(LucchesePalette.soft)
                .padding(.horizontal, 16)
                .padding(.vertical, 15)
                .luccheseGlass(in: RoundedRectangle(cornerRadius: 16, style: .continuous), fallback: LucchesePalette.surface)
                .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
            }
            .disabled(remoteIntegration.isLoading)
        }
    }

    private var tutorialView: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 10) {
                Image(systemName: "book.closed.fill")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(LucchesePalette.white)
                    .frame(width: 42, height: 42)
                    .luccheseGlass(in: RoundedRectangle(cornerRadius: 14, style: .continuous), fallback: LucchesePalette.raised)
                VStack(alignment: .leading, spacing: 3) {
                    Text("COMO UTILIZAR")
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .tracking(1.8)
                        .foregroundStyle(LucchesePalette.muted)
                    Text("Passo a passo")
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        .foregroundStyle(LucchesePalette.white)
                }
            }

            VStack(spacing: 0) {
                tutorialStep(number: "01", title: "Abra o FF", message: "Entre no FF e aguarde o carregamento até 40%.", symbol: "gamecontroller.fill")
                tutorialDivider
                tutorialStep(number: "02", title: "Ative o patch", message: "Volte ao aplicativo e ative o patch desejado.", symbol: "switch.2")
                tutorialDivider
                tutorialStep(number: "03", title: "Desative no lobby", message: "Retorne ao FF e, quando entrar no lobby, desative o patch.", symbol: "arrow.uturn.backward")
            }
            .padding(.horizontal, 15)
            .luccheseGlass(in: RoundedRectangle(cornerRadius: 20, style: .continuous), fallback: LucchesePalette.surface)
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))

            VStack(spacing: 0) {
                HStack(spacing: 9) {
                    Image(systemName: "bolt.horizontal.circle.fill")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(LucchesePalette.soft)
                    Text("COMO INJETAR HS CACHE")
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .tracking(1.1)
                        .foregroundStyle(LucchesePalette.white)
                    Spacer(minLength: 0)
                }
                .padding(.top, 15)
                .padding(.bottom, 5)
                tutorialStep(number: "01", title: "Entre no FF", message: "Entre no FF até o lobby.", symbol: "gamecontroller.fill")
                tutorialDivider
                tutorialStep(number: "02", title: "Ative o HS Cache", message: "Minimize o FF e ative o hs cache desejado, rapidamente volte e inicie a partida.", symbol: "switch.2")
                tutorialDivider
                tutorialStep(number: "03", title: "Desative o HS", message: "Quando entrar na partida bem rápido, desative o hs.", symbol: "arrow.uturn.backward")
            }
            .padding(.horizontal, 15)
            .padding(.bottom, 2)
            .luccheseGlass(in: RoundedRectangle(cornerRadius: 20, style: .continuous), fallback: LucchesePalette.surface)
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))

            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "info.circle.fill")
                    .font(.system(size: 14, weight: .semibold))
                Text("Esse método é obrigatório somente para HS.")
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .fixedSize(horizontal: false, vertical: true)
            }
            .foregroundStyle(LucchesePalette.soft)
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .luccheseGlass(in: RoundedRectangle(cornerRadius: 15, style: .continuous), fallback: LucchesePalette.raised.opacity(0.72))

            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.system(size: 14, weight: .bold))
                Text("Usar de forma indevida pode ocasionar punições.")
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .fixedSize(horizontal: false, vertical: true)
            }
            .foregroundStyle(Color(red: 1.0, green: 0.62, blue: 0.31))
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.orange.opacity(0.09), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(Color.orange.opacity(0.18), lineWidth: 1))
        }
    }

    private var tutorialDivider: some View {
        Rectangle().fill(LucchesePalette.line).frame(height: 1).padding(.leading, 51)
    }

    private func tutorialStep(number: String, title: String, message: String, symbol: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            ZStack {
                Circle().fill(LucchesePalette.raised).frame(width: 38, height: 38)
                Image(systemName: symbol).font(.system(size: 14, weight: .semibold)).foregroundStyle(LucchesePalette.white)
            }
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 7) {
                    Text(number).font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(LucchesePalette.muted)
                    Text(title).font(.system(size: 13, weight: .semibold, design: .rounded)).foregroundStyle(LucchesePalette.white)
                }
                Text(message)
                    .font(.system(size: 11, weight: .regular))
                    .lineSpacing(3)
                    .foregroundStyle(LucchesePalette.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.top, 2)
            Spacer(minLength: 0)
        }
        .padding(.vertical, 14)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var bottomNavigation: some View {
        HStack(spacing: 4) {
            ForEach(StoreTab.allCases) { tab in
                Button {
                    withAnimation(reduceMotion ? nil : .spring(response: 0.34, dampingFraction: 0.82)) {
                        selectedTab = tab
                    }
                } label: {
                    VStack(spacing: 6) {
                        Image(systemName: tab.icon)
                            .font(.system(size: 18, weight: .semibold))
                            .frame(height: 20)
                        Text(tab.title)
                            .font(.system(size: 10, weight: .semibold, design: .rounded))
                    }
                    .foregroundStyle(selectedTab == tab ? LucchesePalette.white : LucchesePalette.muted)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 11)
                    .background {
                        if selectedTab == tab {
                            Capsule()
                                .fill(Color.clear)
                                .luccheseGlass(in: Capsule(), fallback: LucchesePalette.raised.opacity(0.9))
                                .overlay(Capsule().stroke(LucchesePalette.line.opacity(0.8), lineWidth: 0.75))
                                .transition(.opacity.combined(with: .scale(scale: 0.92)))
                        }
                    }
                    .contentShape(Capsule())
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(selectedTab == tab ? .isSelected : [])
            }
        }
        .padding(6)
        .frame(maxWidth: .infinity)
        .background {
            Capsule()
                .fill(Color.clear)
                .luccheseGlass(in: Capsule(), fallback: LucchesePalette.surface.opacity(0.9))
                .overlay(Capsule().stroke(LucchesePalette.line.opacity(0.75), lineWidth: 1))
                .shadow(color: LucchesePalette.background.opacity(0.24), radius: 14, y: 5)
        }
        .padding(.horizontal, 20)
        .padding(.top, 7)
        .padding(.bottom, 10)
        .background(Color.clear)
    }

    private var sortedPatches: [RemotePatch] {
        remoteIntegration.patchesForDisplay.sorted {
            if $0.categorySortOrder != $1.categorySortOrder { return $0.categorySortOrder < $1.categorySortOrder }
            let left = categoryName($0)
            let right = categoryName($1)
            if left != right { return left.localizedStandardCompare(right) == .orderedAscending }
            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }

    private func categoryName(_ patch: RemotePatch) -> String {
        let value = patch.category?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return value.isEmpty ? "Sem categoria" : value
    }

    private var categoryNames: [String] {
        var seen: Set<String> = []
        return sortedPatches.map(categoryName).filter { seen.insert($0).inserted }
    }

    private func categorySection(_ title: String, patches: [RemotePatch]) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline) {
                Text(title.uppercased())
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(LucchesePalette.muted)
                Spacer()
                Text(String(format: "%02d", patches.count))
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundStyle(LucchesePalette.muted.opacity(0.8))
            }
            ForEach(patches) { patch in patchCard(patch) }
        }
    }

    private func patchCard(_ patch: RemotePatch) -> some View {
        let isActive = remoteIntegration.isPatchActive(patch.id)
        let isAvailable = patch.status.lowercased() == "ativo"
        let actionState = patchActionStates[patch.id]
        let isBusy = remoteIntegration.isPatchBusy(patch.id) || actionState != nil
        let categoryConflict = remoteIntegration.activePatchConflict(for: patch)
        let successGreen = Color(red: 0.30, green: 0.78, blue: 0.49)
        return HStack(alignment: .center, spacing: 9) {
            Button {
                activeSheet = StoreSheet(content: .details(patch))
            } label: {
                HStack(alignment: .center, spacing: 9) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(LucchesePalette.raised)
                            .frame(width: 40, height: 40)
                        Image(systemName: "square.stack.3d.up.fill")
                            .font(.system(size: 17, weight: .medium))
                            .foregroundStyle(LucchesePalette.white)
                    }
                    VStack(alignment: .leading, spacing: 5) {
                        HStack(alignment: .firstTextBaseline, spacing: 5) {
                            Text(patch.name)
                                .font(.system(size: 14, weight: .semibold, design: .rounded))
                                .foregroundStyle(LucchesePalette.white)
                                .lineLimit(2)
                                .multilineTextAlignment(.leading)
                                .fixedSize(horizontal: false, vertical: true)
                            Image(systemName: "info.circle")
                                .font(.system(size: 10, weight: .medium))
                                .foregroundStyle(LucchesePalette.muted)
                                .accessibilityHidden(true)
                        }
                        ViewThatFits(in: .horizontal) {
                            HStack(spacing: 6) {
                                patchBadge(title: statusTitle(for: patch), color: statusColor(for: patch), symbol: statusSymbol(for: patch))
                                patchBadge(
                                    title: patch.risk ? "Risco" : "Seguro",
                                    color: patch.risk ? Color.orange : successGreen,
                                    symbol: patch.risk ? "exclamationmark.triangle.fill" : "checkmark.shield.fill"
                                )
                            }
                            VStack(alignment: .leading, spacing: 5) {
                                patchBadge(title: statusTitle(for: patch), color: statusColor(for: patch), symbol: statusSymbol(for: patch))
                                patchBadge(
                                    title: patch.risk ? "Risco" : "Seguro",
                                    color: patch.risk ? Color.orange : successGreen,
                                    symbol: patch.risk ? "exclamationmark.triangle.fill" : "checkmark.shield.fill"
                                )
                            }
                        }
                        if isActive {
                            patchBadge(title: "Aplicado", color: successGreen, symbol: "checkmark.circle.fill")
                        }
                        if let categoryConflict, !isActive {
                            Label("Limite \(remoteIntegration.activePatchLimit(for: patch)) atingido · desative \(categoryConflict)", systemImage: "lock.fill")
                                .font(.system(size: 9, weight: .medium, design: .rounded))
                                .foregroundStyle(LucchesePalette.muted)
                                .lineLimit(2)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Detalhes do patch \(patch.name)")
            .accessibilityHint("Mostra categoria, descrição, versão e status do patch.")
            .layoutPriority(1)

            Group {
                if isBusy {
                    ProgressView()
                        .controlSize(.small)
                        .tint(successGreen)
                        .accessibilityLabel(actionState?.title ?? "Operação de patch em andamento")
                } else {
                    Toggle(
                        "",
                        isOn: Binding(
                            get: { remoteIntegration.isPatchActive(patch.id) },
                            set: { requestToggle(patch, enabled: $0) }
                        )
                    )
                    .labelsHidden()
                    .toggleStyle(.switch)
                    .tint(successGreen)
                    .accessibilityLabel(isActive ? "Desativar e restaurar \(patch.name)" : "Ativar \(patch.name)")
                    .accessibilityHint(categoryConflict.map { "O limite de \(remoteIntegration.activePatchLimit(for: patch)) patch(s) ativos desta categoria foi atingido por: \($0)." } ?? "Será solicitada confirmação antes de injetar ou desinjetar.")
                    .disabled((!isActive && !isAvailable) || (!isActive && !remoteIntegration.licensed) || (!isActive && categoryConflict != nil))
                }
            }
            .frame(width: 54, height: 48, alignment: .center)
            .accessibilityElement(children: .contain)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 9)
        .frame(maxWidth: .infinity, minHeight: 82, alignment: .center)
        .luccheseGlass(in: RoundedRectangle(cornerRadius: 19, style: .continuous), fallback: LucchesePalette.surface)
        .overlay {
            RoundedRectangle(cornerRadius: 19, style: .continuous)
                .stroke(isActive ? successGreen.opacity(0.78) : LucchesePalette.line, lineWidth: isActive ? 1.5 : 1)
        }
        .shadow(color: isActive && !reduceMotion ? successGreen.opacity(0.19) : .clear, radius: isActive ? 18 : 0, y: 2)
        .opacity((!isAvailable && !isActive) ? 0.76 : 1)
        .animation(reduceMotion ? nil : .spring(response: 0.34, dampingFraction: 0.82), value: isActive)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.22), value: isBusy)
    }

    private func patchBadge(title: String, color: Color, symbol: String) -> some View {
        HStack(spacing: 4) {
            Image(systemName: symbol).font(.system(size: 8, weight: .bold))
            Text(title)
                .font(.system(size: 9, weight: .bold, design: .rounded))
                .fixedSize(horizontal: true, vertical: false)
        }
            .foregroundStyle(color)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(color.opacity(0.13), in: Capsule())
            .overlay(Capsule().stroke(color.opacity(0.20), lineWidth: 0.7))
    }

    private func statusTitle(for patch: RemotePatch) -> String {
        switch patch.status.lowercased() {
        case "ativo": return "Disponível"
        case "atualizando": return "Atualizando"
        default: return "Desativado"
        }
    }

    private func statusColor(for patch: RemotePatch) -> Color {
        switch patch.status.lowercased() {
        case "ativo": return Color(red: 0.30, green: 0.78, blue: 0.49)
        case "atualizando": return Color(red: 0.98, green: 0.66, blue: 0.24)
        default: return Color(red: 0.94, green: 0.35, blue: 0.36)
        }
    }

    private func statusSymbol(for patch: RemotePatch) -> String {
        switch patch.status.lowercased() {
        case "ativo": return "checkmark.circle.fill"
        case "atualizando": return "arrow.triangle.2.circlepath"
        default: return "xmark.circle.fill"
        }
    }

    private func requestToggle(_ patch: RemotePatch, enabled: Bool) {
        guard !enabled || patch.status.lowercased() == "ativo" else { return }
        if enabled, let conflict = remoteIntegration.activePatchConflict(for: patch) {
            let limit = remoteIntegration.activePatchLimit(for: patch)
            activeSheet = StoreSheet(content: .result(PatchOperationOutcome(
                patchName: patch.name,
                isSuccess: false,
                isInjection: true,
                message: "Esta categoria permite até \(limit) patch(es) ativo(s) e já atingiu o limite. Ativos: \(conflict). Desative um deles antes de continuar."
            )))
            return
        }
        activeSheet = StoreSheet(content: .confirmation(patch, enabled: enabled))
    }

    @MainActor
    private func performToggle(
        _ patch: RemotePatch,
        enabled: Bool,
        password: String? = nil,
        riskConfirmed: Bool = false,
        allowChangedTargets: Bool = false
    ) async {
        withAnimation(reduceMotion ? nil : .spring(response: 0.32, dampingFraction: 0.78)) {
            patchActionStates[patch.id] = enabled ? .injecting : .restoring
            activeOperation = PatchOperationPresentation(
                patchName: patch.name,
                isInjection: enabled,
                stage: enabled ? .checkingAccess : .checkingBackup
            )
        }
        defer {
            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.22)) {
                patchActionStates.removeValue(forKey: patch.id)
                activeOperation = nil
            }
        }
        let result = await remoteIntegration.setPatchEnabled(
            patch,
            enabled: enabled,
            password: password,
            riskConfirmed: riskConfirmed,
            allowChangedTargets: allowChangedTargets,
            progress: { stage in
                withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.24)) {
                    activeOperation?.stage = stage
                }
            }
        )
        switch result {
        case .completed:
            restorePatch = nil
            if !reduceMotion { UINotificationFeedbackGenerator().notificationOccurred(.success) }
            activeSheet = StoreSheet(content: .result(PatchOperationOutcome(
                patchName: patch.name,
                isSuccess: true,
                isInjection: enabled,
                message: enabled
                    ? "O pacote passou pelas verificações e foi aplicado neste aparelho."
                    : "Os arquivos originais foram restaurados com sucesso."
            )))
        case .requiresRiskConfirmation:
            activeSheet = StoreSheet(content: .confirmation(patch, enabled: true))
        case .requiresPassword:
            passwordValue = ""
            activeSheet = StoreSheet(content: .password(patch))
        case .restoreNeedsConfirmation(let paths):
            restorePatch = patch
            restoreChangedPaths = paths
            showRestoreConfirmation = true
        case .failed(let message):
            if !reduceMotion { UINotificationFeedbackGenerator().notificationOccurred(.error) }
            activeSheet = StoreSheet(content: .result(PatchOperationOutcome(
                patchName: patch.name,
                isSuccess: false,
                isInjection: enabled,
                message: message
            )))
        }
    }

    private func infoRow(symbol: String, title: String, value: String, monospaced: Bool = false) -> some View {
        HStack(alignment: .center, spacing: 11) {
            Image(systemName: symbol)
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(LucchesePalette.soft)
                .frame(width: 18)
            Text(title)
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(LucchesePalette.muted)
            Spacer(minLength: 6)
            Text(value)
                .font(monospaced ? .system(size: 11, weight: .medium, design: .monospaced) : .system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(LucchesePalette.white)
                .multilineTextAlignment(.trailing)
                .lineLimit(2)
        }
        .padding(.vertical, 14)
    }

    private var infoDivider: some View {
        Rectangle().fill(LucchesePalette.line).frame(height: 1)
    }

    private func statusNotice(_ message: String, symbol: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: symbol).font(.system(size: 13, weight: .semibold)).foregroundStyle(LucchesePalette.white)
            Text(message).font(.system(size: 12, weight: .medium)).foregroundStyle(LucchesePalette.soft).fixedSize(horizontal: false, vertical: true)
        }
        .padding(13)
        .frame(maxWidth: .infinity, alignment: .leading)
        .luccheseGlass(in: RoundedRectangle(cornerRadius: 14, style: .continuous), fallback: LucchesePalette.raised)
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
    }

    private func emptyState(symbol: String, title: String, message: String) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 21, weight: .medium))
                .foregroundStyle(LucchesePalette.soft)
            Text(title)
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(LucchesePalette.white)
            Text(message)
                .font(.system(size: 12, weight: .regular))
                .lineSpacing(3)
                .foregroundStyle(LucchesePalette.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .luccheseGlass(in: RoundedRectangle(cornerRadius: 19, style: .continuous), fallback: LucchesePalette.surface)
        .overlay(RoundedRectangle(cornerRadius: 19, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
    }

    private func formattedDate(_ raw: String?) -> String {
        guard let raw, !raw.isEmpty else { return "Não informada" }
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let date = fractional.date(from: raw) ?? ISO8601DateFormatter().date(from: raw)
        guard let date else { return raw }
        return DateFormatter.localizedString(from: date, dateStyle: .medium, timeStyle: .short)
    }

    private func formattedDate(_ date: Date?) -> String {
        guard let date else { return "Aguardando" }
        return DateFormatter.localizedString(from: date, dateStyle: .none, timeStyle: .short)
    }

    private func remainingLicenseTime(until raw: String?, now: Date) -> String {
        guard let raw, !raw.isEmpty else { return "Não informada" }
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        guard let expiry = fractional.date(from: raw) ?? ISO8601DateFormatter().date(from: raw) else {
            return "Data indisponível"
        }
        let seconds = max(0, Int(ceil(expiry.timeIntervalSince(now))))
        guard seconds > 0 else { return "Expirada" }
        let days = seconds / 86_400
        let hours = (seconds % 86_400) / 3_600
        let minutes = (seconds % 3_600) / 60
        let remainingSeconds = seconds % 60
        if days > 0 {
            return String(format: "%d d %02d:%02d:%02d", days, hours, minutes, remainingSeconds)
        }
        return String(format: "%02d:%02d:%02d", hours, minutes, remainingSeconds)
    }
}

private enum PatchActionState: Equatable {
    case injecting
    case restoring

    var title: String {
        switch self {
        case .injecting: return "INJETANDO"
        case .restoring: return "DESINJETANDO"
        }
    }
}

private enum StoreSheetContent {
    case confirmation(RemotePatch, enabled: Bool)
    case details(RemotePatch)
    case result(PatchOperationOutcome)
    case password(RemotePatch)
}

private struct StoreSheet: Identifiable {
    let id = UUID()
    let content: StoreSheetContent
}

private struct PatchOperationOutcome: Identifiable {
    let id = UUID()
    let patchName: String
    let isSuccess: Bool
    let isInjection: Bool
    let message: String
}

private struct PatchOperationPresentation: Identifiable {
    let id = UUID()
    let patchName: String
    let isInjection: Bool
    var stage: RemotePatchToggleProgress

    var stages: [RemotePatchToggleProgress] {
        isInjection
            ? [.checkingAccess, .downloadingPackage, .verifyingPackage, .preparingPatch, .applyingPatch]
            : [.checkingBackup, .restoringFiles]
    }

    var currentIndex: Int { stages.firstIndex(of: stage) ?? 0 }
}

private struct PatchOperationOverlay: View {
    let operation: PatchOperationPresentation
    let reduceMotion: Bool
    @State private var isRotating = false
    @State private var isPulsing = false

    private var accent: Color {
        operation.isInjection ? Color(red: 0.30, green: 0.78, blue: 0.49) : Color(red: 0.72, green: 0.76, blue: 0.84)
    }

    var body: some View {
        ZStack {
            Color.black.opacity(0.80).ignoresSafeArea()
            Rectangle().fill(.ultraThinMaterial).opacity(0.22).ignoresSafeArea()
            VStack(spacing: 18) {
                VStack(spacing: 5) {
                    Text(operation.isInjection ? "INJETANDO PATCH" : "DESINJETANDO PATCH")
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .tracking(2.0)
                        .foregroundStyle(accent)
                    Text(operation.patchName)
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundStyle(LucchesePalette.white)
                        .multilineTextAlignment(.center)
                        .lineLimit(2)
                        .minimumScaleFactor(0.8)
                }

                ZStack {
                    Circle().fill(accent.opacity(isPulsing ? 0.16 : 0.08)).frame(width: 126, height: 126)
                        .scaleEffect(isPulsing ? 1.08 : 0.94)
                    Circle().stroke(LucchesePalette.line, lineWidth: 2).frame(width: 100, height: 100)
                    Circle()
                        .trim(from: 0.08, to: 0.74)
                        .stroke(accent, style: StrokeStyle(lineWidth: 3, lineCap: .round))
                        .frame(width: 100, height: 100)
                        .rotationEffect(.degrees(isRotating ? 360 : 0))
                    Image(systemName: operation.stage.symbol)
                        .font(.system(size: 27, weight: .semibold))
                        .foregroundStyle(accent)
                }
                .frame(height: 130)
                .onAppear {
                    guard !reduceMotion else { return }
                    withAnimation(.linear(duration: 1.5).repeatForever(autoreverses: false)) { isRotating = true }
                    withAnimation(.easeInOut(duration: 1.3).repeatForever(autoreverses: true)) { isPulsing = true }
                }
                .padding(.top, 120)

                VStack(alignment: .leading, spacing: 11) {
                    ForEach(Array(operation.stages.enumerated()), id: \.offset) { index, step in
                        HStack(spacing: 10) {
                            Image(systemName: index < operation.currentIndex ? "checkmark.circle.fill" : (index == operation.currentIndex ? step.symbol : "circle"))
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundStyle(index <= operation.currentIndex ? accent : LucchesePalette.muted.opacity(0.55))
                                .frame(width: 18)
                            Text(step.title)
                                .font(.system(size: 11, weight: index == operation.currentIndex ? .semibold : .medium, design: .rounded))
                                .foregroundStyle(index == operation.currentIndex ? LucchesePalette.white : LucchesePalette.muted)
                            Spacer(minLength: 4)
                            if index == operation.currentIndex {
                                ProgressView().controlSize(.mini).tint(accent)
                            }
                        }
                        .accessibilityElement(children: .combine)
                    }
                }
                .padding(14)
                .luccheseGlass(in: RoundedRectangle(cornerRadius: 16, style: .continuous), fallback: LucchesePalette.background.opacity(0.55))

                Text(operation.stage.detail)
                    .font(.system(size: 11, weight: .regular))
                    .foregroundStyle(LucchesePalette.muted)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(22)
            .frame(maxWidth: 350)
            .luccheseGlass(in: RoundedRectangle(cornerRadius: 28, style: .continuous), fallback: LucchesePalette.surface)
            .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(accent.opacity(0.25), lineWidth: 1))
            .shadow(color: accent.opacity(0.12), radius: 32, y: 8)
            .padding(.horizontal, 24)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .ignoresSafeArea(.container, edges: .all)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(operation.isInjection ? "Injetando" : "Desinjetando") \(operation.patchName). \(operation.stage.title). \(operation.stage.detail)")
        .zIndex(20)
    }
}

private struct PatchConfirmationSheet: View {
    let patch: RemotePatch
    let isInjection: Bool
    let onCancel: () -> Void
    let onConfirm: () -> Void
    private var accent: Color {
        patch.risk && isInjection ? .orange : (isInjection ? Color(red: 0.30, green: 0.78, blue: 0.49) : LucchesePalette.soft)
    }

    var body: some View {
        VStack(spacing: 15) {
            Capsule().fill(LucchesePalette.muted.opacity(0.42)).frame(width: 38, height: 4).padding(.top, 5)
            Image(systemName: isInjection ? "bolt.circle.fill" : "arrow.uturn.backward.circle.fill")
                .font(.system(size: 32, weight: .medium))
                .foregroundStyle(accent)
                .frame(width: 72, height: 72)
                .background(accent.opacity(0.12), in: Circle())
                .overlay(Circle().stroke(accent.opacity(0.22), lineWidth: 1))
                .padding(.top, 2)
            VStack(spacing: 5) {
                Text(isInjection ? "Injetar este patch?" : "Desinjetar e restaurar?")
                    .font(.system(size: 21, weight: .bold, design: .rounded))
                    .foregroundStyle(LucchesePalette.white)
                Text(patch.name)
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(LucchesePalette.soft)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
            }
            Text(isInjection
                 ? "O app confirmará sua licença, baixará o pacote e verificará a integridade antes de aplicar as alterações."
                 : "O app verificará o backup e restaurará os arquivos originais salvos neste aparelho.")
                .font(.system(size: 12, weight: .regular))
                .lineSpacing(3)
                .foregroundStyle(LucchesePalette.muted)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            if isInjection && patch.risk {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "exclamationmark.triangle.fill").font(.system(size: 12, weight: .bold))
                    Text("Este item está marcado como Risco. Continue somente se confia na origem do patch.")
                        .font(.system(size: 10, weight: .semibold))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .foregroundStyle(.orange)
                .padding(11)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.orange.opacity(0.10), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            Spacer(minLength: 0)
            Button(action: onConfirm) {
                HStack(spacing: 8) {
                    Image(systemName: isInjection ? "bolt.fill" : "arrow.uturn.backward")
                    Text(isInjection ? "Confirmar injeção" : "Confirmar restauração")
                }
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .foregroundStyle(LucchesePalette.onAccent)
                .frame(maxWidth: .infinity)
                .frame(height: 50)
                .background(accent, in: RoundedRectangle(cornerRadius: 15, style: .continuous))
            }
            .buttonStyle(.plain)
            Button("Agora não", action: onCancel)
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(LucchesePalette.muted)
                .frame(height: 28)
        }
        .padding(.horizontal, 22)
        .padding(.bottom, 13)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(LucchesePalette.background.ignoresSafeArea())
        .presentationDetents([.height(isInjection && patch.risk ? 485 : 455)])
        .presentationDragIndicator(.hidden)
    }
}

private struct PatchDetailsSheet: View {
    let patch: RemotePatch
    let category: String
    let statusTitle: String
    let statusColor: Color
    let isActive: Bool
    let onClose: () -> Void

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 17) {
                Capsule().fill(LucchesePalette.muted.opacity(0.42)).frame(width: 38, height: 4).frame(maxWidth: .infinity).padding(.top, 9)
                HStack(spacing: 13) {
                    Image(systemName: "square.stack.3d.up.fill")
                        .font(.system(size: 21, weight: .semibold))
                        .foregroundStyle(LucchesePalette.white)
                        .frame(width: 54, height: 54)
                        .luccheseGlass(in: RoundedRectangle(cornerRadius: 17, style: .continuous), fallback: LucchesePalette.raised)
                    VStack(alignment: .leading, spacing: 5) {
                        Text(patch.name)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(LucchesePalette.white)
                            .fixedSize(horizontal: false, vertical: true)
                        Text(category.uppercased())
                            .font(.system(size: 9, weight: .bold, design: .rounded))
                            .tracking(1.6)
                            .foregroundStyle(LucchesePalette.muted)
                    }
                }
                HStack(spacing: 7) {
                    detailBadge(statusTitle, color: statusColor)
                    detailBadge(patch.risk ? "Risco" : "Seguro", color: patch.risk ? .orange : Color(red: 0.30, green: 0.78, blue: 0.49))
                    if isActive { detailBadge("Injetado", color: Color(red: 0.30, green: 0.78, blue: 0.49)) }
                }
                VStack(alignment: .leading, spacing: 12) {
                    detailRow("Versão", value: (patch.version?.isEmpty == false ? patch.version! : "Não informada"))
                    Rectangle().fill(LucchesePalette.line).frame(height: 1)
                    detailRow("Estado", value: statusTitle)
                    Rectangle().fill(LucchesePalette.line).frame(height: 1)
                    detailRow("Segurança", value: patch.risk ? "Risco — use com cautela" : "Seguro")
                }
                .padding(15)
                .luccheseGlass(in: RoundedRectangle(cornerRadius: 16, style: .continuous), fallback: LucchesePalette.surface)
                Text("DESCRIÇÃO")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(LucchesePalette.muted)
                Text((patch.description?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false) ? patch.description! : "Nenhuma descrição foi adicionada para este patch.")
                    .font(.system(size: 13, weight: .regular))
                    .lineSpacing(4)
                    .foregroundStyle(LucchesePalette.soft)
                    .fixedSize(horizontal: false, vertical: true)
                Button(action: onClose) {
                    Text("Fechar detalhes")
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(LucchesePalette.onAccent)
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(LucchesePalette.white, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .buttonStyle(.plain)
                .padding(.top, 2)
            }
            .padding(.horizontal, 22)
            .padding(.bottom, 20)
        }
        .background(LucchesePalette.background.ignoresSafeArea())
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.hidden)
    }

    private func detailBadge(_ title: String, color: Color) -> some View {
        Text(title)
            .font(.system(size: 10, weight: .bold, design: .rounded))
            .foregroundStyle(color)
            .padding(.horizontal, 9)
            .padding(.vertical, 6)
            .background(color.opacity(0.13), in: Capsule())
    }

    private func detailRow(_ title: String, value: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Text(title).foregroundStyle(LucchesePalette.muted)
            Spacer(minLength: 5)
            Text(value).foregroundStyle(LucchesePalette.white).multilineTextAlignment(.trailing)
        }
        .font(.system(size: 11, weight: .medium, design: .rounded))
    }
}

private struct PatchOperationResultSheet: View {
    let result: PatchOperationOutcome
    let onClose: () -> Void
    let onRefresh: () -> Void

    private var accent: Color {
        result.isSuccess ? Color(red: 0.30, green: 0.78, blue: 0.49) : Color(red: 0.94, green: 0.35, blue: 0.36)
    }

    private var title: String {
        if !result.isSuccess { return "Não foi possível concluir" }
        return result.isInjection ? "Patch injetado" : "Restauração concluída"
    }

    var body: some View {
        VStack(spacing: 15) {
            Capsule().fill(LucchesePalette.muted.opacity(0.42)).frame(width: 38, height: 4).padding(.top, 5)
            Image(systemName: result.isSuccess ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                .font(.system(size: 34, weight: .medium))
                .foregroundStyle(accent)
                .frame(width: 78, height: 78)
                .background(accent.opacity(0.12), in: Circle())
            VStack(spacing: 6) {
                Text(title)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .foregroundStyle(LucchesePalette.white)
                    .multilineTextAlignment(.center)
                Text(result.patchName)
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundStyle(LucchesePalette.soft)
                    .multilineTextAlignment(.center)
            }
            Text(result.message)
                .font(.system(size: 12, weight: .regular))
                .lineSpacing(3)
                .foregroundStyle(LucchesePalette.muted)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
            if result.isSuccess {
                Button(action: onClose) {
                    Text("Concluído")
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundStyle(LucchesePalette.onAccent)
                        .frame(maxWidth: .infinity)
                        .frame(height: 49)
                        .background(accent, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
            } else {
                Button(action: onRefresh) {
                    Label("Sincronizar e atualizar catálogo", systemImage: "arrow.clockwise")
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .foregroundStyle(LucchesePalette.onAccent)
                        .frame(maxWidth: .infinity)
                        .frame(height: 49)
                        .background(LucchesePalette.white, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                Button("Fechar", action: onClose)
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .foregroundStyle(LucchesePalette.muted)
                    .frame(height: 25)
            }
        }
        .padding(.horizontal, 22)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(LucchesePalette.background.ignoresSafeArea())
        .presentationDetents([.height(result.isSuccess ? 360 : 400)])
        .presentationDragIndicator(.hidden)
    }
}

private struct PatchSkeletonCard: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var isShimmering = false

    var body: some View {
        HStack(spacing: 11) {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(LucchesePalette.raised)
                .frame(width: 44, height: 44)
            VStack(alignment: .leading, spacing: 8) {
                RoundedRectangle(cornerRadius: 5).fill(LucchesePalette.raised).frame(width: 130, height: 13)
                HStack(spacing: 6) {
                    Capsule().fill(LucchesePalette.raised).frame(width: 72, height: 20)
                    Capsule().fill(LucchesePalette.raised).frame(width: 54, height: 20)
                }
            }
            Spacer()
            Capsule().fill(LucchesePalette.raised).frame(width: 48, height: 30)
        }
        .padding(14)
        .frame(minHeight: 80)
        .luccheseGlass(in: RoundedRectangle(cornerRadius: 19, style: .continuous), fallback: LucchesePalette.surface)
        .overlay {
            RoundedRectangle(cornerRadius: 19, style: .continuous)
                .fill(LinearGradient(colors: [.clear, LucchesePalette.white.opacity(isShimmering ? 0.045 : 0.015), .clear], startPoint: .leading, endPoint: .trailing))
                .allowsHitTesting(false)
        }
        .onAppear {
            guard !reduceMotion else { return }
            withAnimation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true)) { isShimmering = true }
        }
        .accessibilityHidden(true)
    }
}

private struct AmbientMotionBackground: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var motionProgress: CGFloat = 0
    @State private var networkPhase: CGFloat = 0

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                LucchesePalette.background
                AmbientNetwork(progress: motionProgress, phase: networkPhase)
                Circle()
                    .fill(RadialGradient(
                        colors: [LucchesePalette.white.opacity(0.09), LucchesePalette.white.opacity(0.012), .clear],
                        center: .center,
                        startRadius: 0,
                        endRadius: 210
                    ))
                    .frame(width: 420, height: 420)
                    .offset(
                        x: (-0.28 + 0.56 * motionProgress) * geometry.size.width,
                        y: (-0.38 + 0.14 * motionProgress) * geometry.size.height
                    )
                Circle()
                    .fill(RadialGradient(
                        colors: [LucchesePalette.soft.opacity(0.10), .clear],
                        center: .center,
                        startRadius: 0,
                        endRadius: 180
                    ))
                    .frame(width: 360, height: 360)
                    .offset(
                        x: (0.32 - 0.62 * motionProgress) * geometry.size.width,
                        y: (0.18 + 0.20 * motionProgress) * geometry.size.height
                    )
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
            .clipped()
            .onAppear {
                guard !reduceMotion else { return }
                withAnimation(.easeInOut(duration: 16).repeatForever(autoreverses: true)) {
                    motionProgress = 1
                }
                withAnimation(.linear(duration: 9).repeatForever(autoreverses: false)) {
                    networkPhase = 1
                }
            }
        }
        .ignoresSafeArea()
        .accessibilityHidden(true)
    }
}

private struct AmbientNetwork: View {
    let progress: CGFloat
    let phase: CGFloat

    private let anchors: [CGPoint] = [
        CGPoint(x: 0.06, y: 0.19), CGPoint(x: 0.28, y: 0.11), CGPoint(x: 0.49, y: 0.25),
        CGPoint(x: 0.72, y: 0.14), CGPoint(x: 0.94, y: 0.29), CGPoint(x: 0.15, y: 0.73),
        CGPoint(x: 0.39, y: 0.62), CGPoint(x: 0.65, y: 0.79), CGPoint(x: 0.87, y: 0.67)
    ]
    private let drift: [CGPoint] = [
        CGPoint(x: 0.07, y: 0.035), CGPoint(x: -0.035, y: 0.045), CGPoint(x: 0.06, y: -0.035),
        CGPoint(x: -0.055, y: 0.055), CGPoint(x: -0.07, y: -0.035), CGPoint(x: 0.045, y: -0.06),
        CGPoint(x: -0.045, y: 0.025), CGPoint(x: 0.035, y: -0.045), CGPoint(x: -0.06, y: 0.04)
    ]
    private let links: [(Int, Int)] = [
        (0, 1), (1, 2), (2, 3), (3, 4), (0, 6), (1, 6), (2, 6),
        (2, 7), (3, 7), (4, 7), (6, 7), (7, 8), (4, 8)
    ]

    var body: some View {
        Canvas { context, size in
            let points = anchors.indices.map { index in
                CGPoint(
                    x: (anchors[index].x + drift[index].x * progress) * size.width,
                    y: (anchors[index].y + drift[index].y * progress) * size.height
                )
            }
            var network = Path()
            for (start, end) in links {
                network.move(to: points[start])
                network.addLine(to: points[end])
            }
            context.stroke(
                network,
                with: .color(LucchesePalette.white.opacity(0.075)),
                style: StrokeStyle(lineWidth: 0.8, lineCap: .round)
            )
            for (index, (start, end)) in links.enumerated() {
                let offset = CGFloat(index) * 0.173
                let position = (phase + offset).truncatingRemainder(dividingBy: 1)
                let from = points[start]
                let to = points[end]
                let marker = CGPoint(
                    x: from.x + (to.x - from.x) * position,
                    y: from.y + (to.y - from.y) * position
                )
                let glow = CGRect(x: marker.x - 4, y: marker.y - 4, width: 8, height: 8)
                let spark = CGRect(x: marker.x - 1, y: marker.y - 1, width: 2, height: 2)
                context.fill(Path(ellipseIn: glow), with: .color(LucchesePalette.white.opacity(0.075)))
                context.fill(Path(ellipseIn: spark), with: .color(LucchesePalette.white.opacity(0.36)))
            }
            for (index, point) in points.enumerated() {
                let radius: CGFloat = index.isMultiple(of: 3) ? 2.0 : 1.25
                let halo = CGRect(x: point.x - radius * 2.5, y: point.y - radius * 2.5, width: radius * 5, height: radius * 5)
                let dot = CGRect(x: point.x - radius / 2, y: point.y - radius / 2, width: radius, height: radius)
                context.fill(Path(ellipseIn: halo), with: .color(LucchesePalette.white.opacity(0.035)))
                context.fill(Path(ellipseIn: dot), with: .color(LucchesePalette.white.opacity(0.17)))
            }
        }
        .allowsHitTesting(false)
    }
}

private enum AccessGateKind {
    case configuration, connection, maintenance, offline, updating, oldVersion, banned
    case keyMissing, keyRevoked, keyExpired, keyDisabled, invalidKey, deviceLimit, deviceMismatch

    var symbol: String {
        switch self {
        case .configuration: return "gearshape.2.fill"
        case .connection: return "wifi.slash"
        case .maintenance: return "wrench.and.screwdriver.fill"
        case .offline: return "power"
        case .updating: return "arrow.triangle.2.circlepath"
        case .oldVersion: return "arrow.down.app.fill"
        case .banned: return "iphone.slash"
        case .keyMissing: return "key.slash.fill"
        case .keyRevoked: return "xmark.shield.fill"
        case .keyExpired: return "calendar.badge.exclamationmark"
        case .keyDisabled: return "pause.circle.fill"
        case .invalidKey: return "key.fill"
        case .deviceLimit: return "iphone.gen3.radiowaves.left.and.right"
        case .deviceMismatch: return "iphone.and.arrow.forward"
        }
    }

    var title: String {
        switch self {
        case .configuration: return "Serviço não configurado"
        case .connection: return "Sem conexão com a loja"
        case .maintenance: return "Estamos em manutenção"
        case .offline: return "Serviço temporariamente desligado"
        case .updating: return "Loja em atualização"
        case .oldVersion: return "Atualize o aplicativo"
        case .banned: return "Dispositivo bloqueado"
        case .keyMissing: return "Key não encontrada"
        case .keyRevoked: return "Acesso revogado"
        case .keyExpired: return "Key expirada"
        case .keyDisabled: return "Key desativada"
        case .invalidKey: return "Não foi possível validar a key"
        case .deviceLimit: return "Limite de aparelhos atingido"
        case .deviceMismatch: return "Key vinculada a outro aparelho"
        }
    }

    var requiresNewKey: Bool {
        switch self {
        case .keyMissing, .keyRevoked, .keyExpired, .keyDisabled, .invalidKey, .deviceLimit, .deviceMismatch: return true
        default: return false
        }
    }

    @MainActor
    func message(service: RemoteIntegration) -> String {
        switch self {
        case .configuration:
            return service.gateMessage ?? "Esta versão ainda não está conectada à origem da API."
        case .connection:
            return service.errorMessage ?? "Verifique sua conexão e tente novamente."
        case .maintenance:
            return service.gateMessage ?? "A equipe está realizando uma manutenção. Tente novamente mais tarde."
        case .offline:
            return service.gateMessage ?? "O acesso à loja está temporariamente pausado."
        case .updating:
            return service.gateMessage ?? "Estamos atualizando o serviço. Tente novamente em alguns minutos."
        case .oldVersion:
            return service.gateMessage ?? "Instale a versão mais recente para continuar."
        case .banned:
            return service.gateMessage ?? "Este aparelho foi bloqueado pelo administrador. Entre em contato com o suporte."
        case .keyMissing:
            return "Esta key não existe ou foi excluída. Confira o código ou solicite uma nova key ao administrador."
        case .keyRevoked:
            return "O acesso desta key foi revogado. Solicite uma nova licença ao administrador da loja."
        case .keyExpired:
            return "O período desta key terminou. Solicite uma nova licença para continuar."
        case .keyDisabled:
            return "O administrador desativou esta licença. Entre em contato com a loja para confirmar o acesso."
        case .invalidKey:
            return service.errorMessage ?? "Confira todos os caracteres da key e tente novamente."
        case .deviceLimit:
            return "Esta key já alcançou o limite de aparelhos permitido. Peça ao administrador para liberar um vínculo ou use outra key."
        case .deviceMismatch:
            return "Esta key está vinculada a outro aparelho. Fale com o administrador para revisar o vínculo."
        }
    }
}

private struct AccessStatusView: View {
    let state: AccessGateKind
    @ObservedObject var service: RemoteIntegration
    let onRetry: () -> Void

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 24) {
                HStack(spacing: 13) {
                    LuccheseBrandMark(size: 52)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(service.storeName)
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)
                            .foregroundStyle(LucchesePalette.white)
                        Text("STATUS DO ACESSO")
                            .font(.system(size: 9, weight: .semibold, design: .rounded))
                            .tracking(2.2)
                            .foregroundStyle(LucchesePalette.muted)
                    }
                }
                .padding(.top, 34)

                VStack(alignment: .leading, spacing: 18) {
                    Image(systemName: state.symbol)
                        .font(.system(size: 24, weight: .medium))
                        .foregroundStyle(LucchesePalette.white)
                        .frame(width: 58, height: 58)
                        .luccheseGlass(in: RoundedRectangle(cornerRadius: 18, style: .continuous), fallback: LucchesePalette.raised)
                    VStack(alignment: .leading, spacing: 9) {
                        Text(state.title)
                            .font(.system(size: 27, weight: .bold, design: .rounded))
                            .tracking(-0.7)
                            .foregroundStyle(LucchesePalette.white)
                        Text(state.message(service: service))
                            .font(.system(size: 14, weight: .regular))
                            .lineSpacing(4)
                            .foregroundStyle(LucchesePalette.muted)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    if !service.maskedLicenseKey.isEmpty && service.maskedLicenseKey != "—" {
                        Text(service.maskedLicenseKey)
                            .font(.system(size: 11, weight: .medium, design: .monospaced))
                            .foregroundStyle(LucchesePalette.soft)
                            .padding(.horizontal, 11)
                            .padding(.vertical, 8)
                            .luccheseGlass(in: Capsule(), fallback: LucchesePalette.raised)
                    }
                }
                .padding(20)
                .frame(maxWidth: .infinity, alignment: .leading)
                .luccheseGlass(in: RoundedRectangle(cornerRadius: 24, style: .continuous), fallback: LucchesePalette.surface)
                .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))

                if state.requiresNewKey {
                    Button {
                        service.prepareForKeyEntry()
                    } label: {
                        HStack(spacing: 9) {
                            Text("Inserir outra key")
                            Image(systemName: "arrow.right")
                                .font(.system(size: 12, weight: .semibold))
                        }
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .foregroundStyle(LucchesePalette.onAccent)
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(LucchesePalette.white, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                } else {
                    Button(action: onRetry) {
                        HStack(spacing: 9) {
                            if service.isLoading { ProgressView().tint(LucchesePalette.background) }
                            Text("Tentar novamente")
                            Image(systemName: "arrow.clockwise")
                                .font(.system(size: 12, weight: .semibold))
                        }
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .foregroundStyle(LucchesePalette.onAccent)
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(LucchesePalette.white, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                    .disabled(service.isLoading)
                }

                if let discordURL = service.discordURL {
                    Link(destination: discordURL) {
                        HStack(spacing: 10) {
                            DiscordGlyph(size: 18)
                            Text("Falar com o suporte no Discord")
                                .font(.system(size: 12, weight: .semibold, design: .rounded))
                        }
                        .foregroundStyle(LucchesePalette.soft)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .luccheseGlass(in: RoundedRectangle(cornerRadius: 15, style: .continuous), fallback: LucchesePalette.surface)
                        .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
                    }
                }

                Text("Desenvolvido por @lucchese")
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(LucchesePalette.muted.opacity(0.8))
                    .frame(maxWidth: .infinity)
                    .padding(.top, 2)
                    .padding(.bottom, 24)
            }
            .padding(.horizontal, 23)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .scrollDismissesKeyboard(.interactively)
    }
}

private struct DiscordGlyph: View {
    let size: CGFloat

    var body: some View {
        ZStack {
            DiscordControllerShape().fill(LucchesePalette.white)
            HStack(spacing: size * 0.16) {
                Circle().fill(LucchesePalette.background)
                    .frame(width: size * 0.105, height: size * 0.105)
                Circle().fill(LucchesePalette.background)
                    .frame(width: size * 0.105, height: size * 0.105)
            }
            .offset(y: size * 0.07)
        }
        .frame(width: size, height: size * 0.82)
        .accessibilityHidden(true)
    }
}

private struct DiscordControllerShape: Shape {
    func path(in rect: CGRect) -> Path {
        let w = rect.width
        let h = rect.height
        var path = Path()
        path.move(to: CGPoint(x: w * 0.27, y: h * 0.15))
        path.addQuadCurve(to: CGPoint(x: w * 0.73, y: h * 0.15), control: CGPoint(x: w * 0.50, y: -h * 0.04))
        path.addQuadCurve(to: CGPoint(x: w * 0.87, y: h * 0.71), control: CGPoint(x: w * 0.83, y: h * 0.30))
        path.addQuadCurve(to: CGPoint(x: w * 0.64, y: h * 0.84), control: CGPoint(x: w * 0.78, y: h * 0.91))
        path.addLine(to: CGPoint(x: w * 0.58, y: h * 0.70))
        path.addQuadCurve(to: CGPoint(x: w * 0.42, y: h * 0.70), control: CGPoint(x: w * 0.50, y: h * 0.75))
        path.addLine(to: CGPoint(x: w * 0.36, y: h * 0.84))
        path.addQuadCurve(to: CGPoint(x: w * 0.13, y: h * 0.71), control: CGPoint(x: w * 0.22, y: h * 0.91))
        path.addQuadCurve(to: CGPoint(x: w * 0.27, y: h * 0.15), control: CGPoint(x: w * 0.17, y: h * 0.30))
        path.closeSubpath()
        return path
    }
}

private struct LuccheseKeyEntryView: View {
    @ObservedObject var service: RemoteIntegration
    let onRestore: (RemotePatch) -> Void

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 25) {
                HStack(spacing: 13) {
                    LuccheseBrandMark(size: 54)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(service.storeName)
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .lineLimit(1)
                            .minimumScaleFactor(0.72)
                            .foregroundStyle(LucchesePalette.white)
                        Text("ACESSO PRIVADO")
                            .font(.system(size: 9, weight: .semibold, design: .rounded))
                            .tracking(2.5)
                            .foregroundStyle(LucchesePalette.muted)
                    }
                }
                .padding(.top, 34)

                VStack(alignment: .leading, spacing: 8) {
                    Text("Acesse sua loja")
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                        .tracking(-1.1)
                        .foregroundStyle(LucchesePalette.white)
                    Text("Use a chave fornecida pelo administrador para vincular este aparelho.")
                        .font(.system(size: 13, weight: .regular))
                        .lineSpacing(4)
                        .foregroundStyle(LucchesePalette.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(.top, 14)

                VStack(alignment: .leading, spacing: 10) {
                    Text("CHAVE DE ACESSO")
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .tracking(2)
                        .foregroundStyle(LucchesePalette.muted)
                    HStack(spacing: 11) {
                        Image(systemName: "key.horizontal.fill")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(LucchesePalette.soft)
                        TextField("Cole ou digite sua key", text: $service.licenseKey)
                            .font(.system(size: 13, weight: .medium, design: .monospaced))
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .keyboardType(.asciiCapable)
                            .submitLabel(.go)
                            .onSubmit { Task { await service.activateOrValidate(key: service.licenseKey) } }
                            .foregroundStyle(LucchesePalette.white)
                    }
                    .padding(.horizontal, 15)
                    .frame(height: 57)
                    .luccheseGlass(in: RoundedRectangle(cornerRadius: 16, style: .continuous), fallback: LucchesePalette.surface)
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))

                    if let message = service.errorMessage ?? service.gateMessage, !message.isEmpty {
                        HStack(alignment: .top, spacing: 8) {
                            Image(systemName: "exclamationmark.circle.fill")
                                .font(.system(size: 12))
                            Text(message)
                                .font(.system(size: 12, weight: .medium))
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .foregroundStyle(LucchesePalette.soft)
                        .padding(.top, 4)
                    }

                    if !service.isConfigured {
                        Text("O serviço ainda não está configurado para esta versão do app. Entre em contato com o suporte.")
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(LucchesePalette.muted)
                            .padding(.top, 5)
                    }
                }
                .padding(17)
                .luccheseGlass(in: RoundedRectangle(cornerRadius: 21, style: .continuous), fallback: LucchesePalette.surface.opacity(0.72))
                .overlay(RoundedRectangle(cornerRadius: 21, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))

                Button {
                    Task { await service.activateOrValidate(key: service.licenseKey) }
                } label: {
                    HStack(spacing: 9) {
                        if service.isLoading {
                            ProgressView().tint(LucchesePalette.background)
                        } else {
                            Text("Validar e continuar")
                            Image(systemName: "arrow.right")
                                .font(.system(size: 13, weight: .semibold))
                        }
                    }
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(LucchesePalette.onAccent)
                    .frame(maxWidth: .infinity)
                    .frame(height: 54)
                    .background(LucchesePalette.white, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .disabled(service.isLoading || !service.isConfigured || service.licenseKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                .opacity(service.isLoading || !service.isConfigured ? 0.65 : 1)

                if !service.recoveryPatches.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 8) {
                            Image(systemName: "arrow.uturn.backward.circle.fill")
                            Text("RESTAURAÇÃO LOCAL")
                                .tracking(1.8)
                        }
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .foregroundStyle(LucchesePalette.soft)
                        Text("A licença não está ativa. Você ainda pode desligar um patch aplicado para restaurar os arquivos originais.")
                            .font(.system(size: 11, weight: .regular))
                            .lineSpacing(3)
                            .foregroundStyle(LucchesePalette.muted)
                        ForEach(service.recoveryPatches) { patch in
                            HStack(spacing: 10) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(patch.name).font(.system(size: 12, weight: .semibold)).foregroundStyle(LucchesePalette.white)
                                    Text("Aplicado neste aparelho").font(.system(size: 10, weight: .medium)).foregroundStyle(LucchesePalette.muted)
                                }
                                Spacer()
                                Toggle(
                                    "",
                                    isOn: Binding(
                                        get: { service.isPatchActive(patch.id) },
                                        set: { if !$0 { onRestore(patch) } }
                                    )
                                )
                                .labelsHidden()
                                .toggleStyle(SwitchToggleStyle(tint: LucchesePalette.white))
                                .disabled(service.isPatchBusy(patch.id))
                            }
                            .padding(.vertical, 8)
                        }
                    }
                    .padding(16)
                    .luccheseGlass(in: RoundedRectangle(cornerRadius: 18, style: .continuous), fallback: LucchesePalette.surface)
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
                }

                Text("Desenvolvido por @lucchese")
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(LucchesePalette.muted.opacity(0.8))
                    .frame(maxWidth: .infinity)
                    .padding(.top, 4)
                    .padding(.bottom, 24)
            }
            .padding(.horizontal, 23)
        }
        .scrollDismissesKeyboard(.interactively)
    }
}

private struct LuccheseBrandMark: View {
    var size: CGFloat

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.32, style: .continuous)
                .fill(LucchesePalette.raised)
            RoundedRectangle(cornerRadius: size * 0.32, style: .continuous)
                .stroke(LucchesePalette.line, lineWidth: 1)
            Image(systemName: "person.fill")
                .font(.system(size: size * 0.39, weight: .medium))
                .foregroundStyle(LucchesePalette.white)
        }
        .frame(width: size, height: size)
        .accessibilityLabel("Perfil da licença")
    }
}

private struct PatchPasswordSheet: View {
    let patchName: String
    @Binding var password: String
    let onCancel: () -> Void
    let onUnlock: () -> Void
    @FocusState private var focused: Bool

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 18) {
                Text("Este pacote está protegido por senha.")
                    .font(.system(size: 16, weight: .semibold, design: .rounded))
                    .foregroundStyle(LucchesePalette.white)
                Text(patchName)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(LucchesePalette.muted)
                SecureField("Senha do pacote", text: $password)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .focused($focused)
                    .padding(14)
                    .luccheseGlass(in: RoundedRectangle(cornerRadius: 13, style: .continuous), fallback: LucchesePalette.raised)
                Button(action: onUnlock) {
                    Text("Desbloquear e continuar")
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .foregroundStyle(LucchesePalette.onAccent)
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(LucchesePalette.white, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .disabled(password.isEmpty)
                Spacer(minLength: 0)
            }
            .padding(20)
            .background(LucchesePalette.background.ignoresSafeArea())
            .navigationTitle("Desbloquear pacote")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar", action: onCancel).foregroundStyle(LucchesePalette.soft)
                }
            }
            .onAppear { DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { focused = true } }
        }
    }
}
