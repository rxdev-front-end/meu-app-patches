#import "ClockViewController.h"
#import <QuartzCore/QuartzCore.h>

static UIColor *Orange(void) { return [UIColor colorWithRed:1.0 green:0.61 blue:0.05 alpha:1.0]; }
static UIColor *Panel(void) { return [UIColor colorWithRed:0.12 green:0.12 blue:0.13 alpha:1.0]; }
static UIColor *Muted(void) { return [UIColor colorWithWhite:0.52 alpha:1.0]; }

@interface BaseController : UIViewController
- (void)style;
- (UILabel *)label:(NSString *)text size:(CGFloat)size color:(UIColor *)color;
@end
@implementation BaseController
- (void)style { self.view.backgroundColor = UIColor.blackColor; self.navigationController.navigationBarHidden = YES; }
- (void)viewDidLoad { [super viewDidLoad]; [self style]; }
- (UILabel *)label:(NSString *)text size:(CGFloat)size color:(UIColor *)color {
    UILabel *l = [[UILabel alloc] init]; l.text=text; l.textColor=color; l.font=[UIFont systemFontOfSize:(size * 0.5) weight:UIFontWeightRegular]; l.translatesAutoresizingMaskIntoConstraints=NO; return l;
}
@end

static NSArray<NSDictionary *> *CityCatalog(void) {
    static NSArray<NSDictionary *> *items;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSArray *rows = @[
            @[@"Abidjan", @"Costa do Marfim", @"Africa/Abidjan"], @[@"Abu Dhabi", @"EAU", @"Asia/Dubai"],
            @[@"Acapulco", @"México", @"America/Mexico_City"], @[@"Accra", @"Gana", @"Africa/Accra"],
            @[@"Acton", @"EUA", @"America/Los_Angeles"], @[@"Adak", @"EUA", @"America/Adak"],
            @[@"Adamstown", @"Ilhas Pitcairn", @"Pacific/Pitcairn"], @[@"Adelaide", @"Austrália", @"Australia/Adelaide"],
            @[@"Aden", @"Iêmen", @"Asia/Aden"], @[@"Addis Abeba", @"Etiópia", @"Africa/Addis_Ababa"], @[@"Aktau", @"Cazaquistão", @"Asia/Aqtau"],
            @[@"Aguascalientes", @"México", @"America/Mexico_City"], @[@"Alofi", @"Niue", @"Pacific/Niue"],
            @[@"Albuquerque", @"EUA", @"America/Denver"], @[@"Alexandria", @"Egito", @"Africa/Cairo"],
            @[@"Algiers", @"Argélia", @"Africa/Algiers"], @[@"Amã", @"Jordânia", @"Asia/Amman"],
            @[@"Amsterdam", @"Países Baixos", @"Europe/Amsterdam"], @[@"Anchorage", @"EUA", @"America/Anchorage"],
            @[@"Ankara", @"Turquia", @"Europe/Istanbul"], @[@"Antananarivo", @"Madagascar", @"Indian/Antananarivo"],
            @[@"Asunción", @"Paraguai", @"America/Asuncion"], @[@"Atenas", @"Grécia", @"Europe/Athens"],
            @[@"Atlanta", @"EUA", @"America/New_York"], @[@"Auckland", @"Nova Zelândia", @"Pacific/Auckland"],
            @[@"Bangkok", @"Tailândia", @"Asia/Bangkok"], @[@"Barcelona", @"Espanha", @"Europe/Madrid"],
            @[@"Beijing", @"China", @"Asia/Shanghai"], @[@"Belém", @"Brasil", @"America/Belem"],
            @[@"Beirute", @"Líbano", @"Asia/Beirut"], @[@"Berlim", @"Alemanha", @"Europe/Berlin"],
            @[@"Bogotá", @"Colômbia", @"America/Bogota"], @[@"Brasília", @"Brasil", @"America/Sao_Paulo"],
            @[@"Buenos Aires", @"Argentina", @"America/Argentina/Buenos_Aires"], @[@"Cairo", @"Egito", @"Africa/Cairo"],
            @[@"Calgary", @"Canadá", @"America/Edmonton"], @[@"Cidade do Cabo", @"África do Sul", @"Africa/Johannesburg"],
            @[@"Chicago", @"EUA", @"America/Chicago"], @[@"Copenhague", @"Dinamarca", @"Europe/Copenhagen"],
            @[@"Délhi", @"Índia", @"Asia/Kolkata"], @[@"Denver", @"EUA", @"America/Denver"],
            @[@"Dubai", @"EAU", @"Asia/Dubai"], @[@"Dublin", @"Irlanda", @"Europe/Dublin"],
            @[@"Edimburgo", @"Reino Unido", @"Europe/London"], @[@"Frankfurt", @"Alemanha", @"Europe/Berlin"],
            @[@"Guadalajara", @"México", @"America/Mexico_City"], @[@"Hanoi", @"Vietnã", @"Asia/Ho_Chi_Minh"],
            @[@"Havana", @"Cuba", @"America/Havana"], @[@"Helsinque", @"Finlândia", @"Europe/Helsinki"],
            @[@"Hong Kong", @"Hong Kong", @"Asia/Hong_Kong"], @[@"Honolulu", @"EUA", @"Pacific/Honolulu"],
            @[@"Istambul", @"Turquia", @"Europe/Istanbul"], @[@"Jacarta", @"Indonésia", @"Asia/Jakarta"],
            @[@"Jerusalém", @"Israel", @"Asia/Jerusalem"], @[@"Joanesburgo", @"África do Sul", @"Africa/Johannesburg"],
            @[@"Karachi", @"Paquistão", @"Asia/Karachi"], @[@"Kuala Lumpur", @"Malásia", @"Asia/Kuala_Lumpur"],
            @[@"Lima", @"Peru", @"America/Lima"], @[@"Lisboa", @"Portugal", @"Europe/Lisbon"],
            @[@"Londres", @"Reino Unido", @"Europe/London"], @[@"Los Angeles", @"EUA", @"America/Los_Angeles"],
            @[@"Madri", @"Espanha", @"Europe/Madrid"], @[@"Manaus", @"Brasil", @"America/Manaus"],
            @[@"Melbourne", @"Austrália", @"Australia/Melbourne"], @[@"Cidade do México", @"México", @"America/Mexico_City"],
            @[@"Miami", @"EUA", @"America/New_York"], @[@"Moscou", @"Rússia", @"Europe/Moscow"],
            @[@"Mumbai", @"Índia", @"Asia/Kolkata"], @[@"Nairóbi", @"Quênia", @"Africa/Nairobi"],
            @[@"Nova York", @"EUA", @"America/New_York"], @[@"Oslo", @"Noruega", @"Europe/Oslo"],
            @[@"Paris", @"França", @"Europe/Paris"], @[@"Perth", @"Austrália", @"Australia/Perth"],
            @[@"Phoenix", @"EUA", @"America/Phoenix"], @[@"Praga", @"Tchéquia", @"Europe/Prague"],
            @[@"Recife", @"Brasil", @"America/Recife"], @[@"Reykjavík", @"Islândia", @"Atlantic/Reykjavik"],
            @[@"Rio de Janeiro", @"Brasil", @"America/Sao_Paulo"], @[@"Roma", @"Itália", @"Europe/Rome"],
            @[@"San Francisco", @"EUA", @"America/Los_Angeles"], @[@"Santiago", @"Chile", @"America/Santiago"],
            @[@"São Paulo", @"Brasil", @"America/Sao_Paulo"], @[@"Seul", @"Coreia do Sul", @"Asia/Seoul"],
            @[@"Singapura", @"Singapura", @"Asia/Singapore"], @[@"Estocolmo", @"Suécia", @"Europe/Stockholm"],
            @[@"Sydney", @"Austrália", @"Australia/Sydney"], @[@"Taipei", @"Taiwan", @"Asia/Taipei"],
            @[@"Tóquio", @"Japão", @"Asia/Tokyo"], @[@"Toronto", @"Canadá", @"America/Toronto"],
            @[@"Vancouver", @"Canadá", @"America/Vancouver"], @[@"Washington, D.C.", @"EUA", @"America/New_York"], @[@"Viena", @"Áustria", @"Europe/Vienna"],
            @[@"Varsóvia", @"Polônia", @"Europe/Warsaw"], @[@"Zurique", @"Suíça", @"Europe/Zurich"]
        ];
        NSMutableArray *values=[NSMutableArray arrayWithCapacity:rows.count];
        for (NSArray *row in rows) [values addObject:@{@"city":row[0], @"country":row[1], @"zone":row[2]}];
        [values sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) { return [a[@"city"] localizedCaseInsensitiveCompare:b[@"city"]]; }];
        items=[values copy];
    });
    return items;
}

@interface CityPickerController : UIViewController <UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate>
@property (nonatomic, strong) UISearchBar *searchBar;
@property (nonatomic, strong) UITableView *table;
@property (nonatomic, copy) void (^completion)(NSDictionary *);
@property (nonatomic, copy) NSArray<NSString *> *sectionTitles;
@property (nonatomic, copy) NSDictionary<NSString *, NSArray<NSDictionary *> *> *sections;
@property (nonatomic, copy) NSString *query;
@end
@implementation CityPickerController
- (void)viewDidLoad {
    [super viewDidLoad]; self.view.backgroundColor=[UIColor colorWithRed:.11 green:.11 blue:.12 alpha:1]; self.query=@"";
    UILabel *title=[[UILabel alloc] init]; title.text=@"Escolha uma Cidade"; title.textColor=UIColor.whiteColor; title.font=[UIFont systemFontOfSize:20 weight:UIFontWeightBold]; title.textAlignment=NSTextAlignmentCenter; title.translatesAutoresizingMaskIntoConstraints=NO;
    self.searchBar=[[UISearchBar alloc] init]; self.searchBar.placeholder=@"Buscar"; self.searchBar.delegate=self; self.searchBar.searchBarStyle=UISearchBarStyleMinimal; self.searchBar.backgroundImage=[UIImage new]; self.searchBar.tintColor=Orange(); self.searchBar.translatesAutoresizingMaskIntoConstraints=NO; self.searchBar.searchTextField.backgroundColor=[UIColor colorWithWhite:.18 alpha:1]; self.searchBar.searchTextField.textColor=UIColor.whiteColor; self.searchBar.searchTextField.font=[UIFont systemFontOfSize:17]; self.searchBar.searchTextField.layer.cornerRadius=27; self.searchBar.searchTextField.layer.masksToBounds=YES;
    UIButton *cancel=[UIButton buttonWithType:UIButtonTypeSystem]; [cancel setImage:[UIImage systemImageNamed:@"xmark"] forState:UIControlStateNormal]; cancel.tintColor=UIColor.whiteColor; cancel.backgroundColor=[UIColor colorWithWhite:.16 alpha:1]; cancel.layer.cornerRadius=28; cancel.layer.borderWidth=.5; cancel.layer.borderColor=[UIColor colorWithWhite:.38 alpha:1].CGColor; [cancel addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchUpInside]; cancel.translatesAutoresizingMaskIntoConstraints=NO;
    self.table=[[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain]; self.table.backgroundColor=self.view.backgroundColor; self.table.dataSource=self; self.table.delegate=self; self.table.separatorColor=[UIColor colorWithWhite:.25 alpha:1]; self.table.separatorInset=UIEdgeInsetsMake(0,18,0,12); self.table.sectionIndexColor=Orange(); self.table.rowHeight=60; self.table.sectionHeaderHeight=30; self.table.translatesAutoresizingMaskIntoConstraints=NO; [self.table registerClass:UITableViewCell.class forCellReuseIdentifier:@"CityCell"];
    UITapGestureRecognizer *triple=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tripleTap:)]; triple.numberOfTapsRequired=3; triple.cancelsTouchesInView=NO; [self.table addGestureRecognizer:triple];
    [self.view addSubview:title]; [self.view addSubview:self.searchBar]; [self.view addSubview:cancel]; [self.view addSubview:self.table]; [self rebuildSections];
    [NSLayoutConstraint activateConstraints:@[[title.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:26],[title.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],[cancel.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:18],[cancel.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:8],[cancel.widthAnchor constraintEqualToConstant:56],[cancel.heightAnchor constraintEqualToConstant:56],[self.table.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],[self.table.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],[self.table.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:31],[self.table.bottomAnchor constraintEqualToAnchor:self.searchBar.topAnchor constant:-8],[self.searchBar.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:52],[self.searchBar.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-52],[self.searchBar.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-12],[self.searchBar.heightAnchor constraintEqualToConstant:54]]];
}
- (void)rebuildSections {
    NSMutableDictionary *grouped=[NSMutableDictionary dictionary];
    for (NSDictionary *item in CityCatalog()) { NSString *city=item[@"city"]; if(self.query.length && [city rangeOfString:self.query options:NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch].location==NSNotFound && [item[@"country"] rangeOfString:self.query options:NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch].location==NSNotFound) continue; NSString *first=[[city substringToIndex:1] stringByFoldingWithOptions:NSDiacriticInsensitiveSearch locale:[NSLocale localeWithLocaleIdentifier:@"pt_BR"]]; NSString *key=[first.uppercaseString substringToIndex:1]; if(!grouped[key]) grouped[key]=[NSMutableArray array]; [grouped[key] addObject:item]; }
    self.sectionTitles=[[grouped.allKeys sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)] copy]; self.sections=[grouped copy]; [self.table reloadData];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return self.sectionTitles.count; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return self.sections[self.sectionTitles[section]].count; }
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section { return self.sectionTitles[section]; }
- (NSArray<NSString *> *)sectionIndexTitlesForTableView:(UITableView *)tableView { return self.query.length ? @[] : @[@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H",@"I",@"J",@"K",@"L",@"M",@"N",@"O",@"P",@"Q",@"R",@"S",@"T",@"U",@"V",@"W",@"X",@"Y",@"Z",@"#"]; }
- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index { NSInteger found=[self.sectionTitles indexOfObject:title]; if(found!=(NSInteger)NSNotFound) return found; for(NSInteger i=0;i<self.sectionTitles.count;i++) if([self.sectionTitles[i] localizedCaseInsensitiveCompare:title]!=NSOrderedAscending) return i; return self.sectionTitles.count ? (NSInteger)self.sectionTitles.count-1 : 0; }
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section { return 24; }
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section { UIView *v=[[UIView alloc] init]; v.backgroundColor=self.view.backgroundColor; UILabel *l=[[UILabel alloc] initWithFrame:CGRectMake(18,0,100,24)]; l.text=self.sectionTitles[section]; l.textColor=[UIColor colorWithWhite:.62 alpha:1]; l.font=[UIFont systemFontOfSize:14]; [v addSubview:l]; return v; }
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath { UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"CityCell" forIndexPath:indexPath]; NSDictionary *item=self.sections[self.sectionTitles[indexPath.section]][indexPath.row]; cell.textLabel.text=[NSString stringWithFormat:@"%@, %@", item[@"city"], item[@"country"]]; cell.textLabel.textColor=[UIColor colorWithWhite:.94 alpha:1]; cell.textLabel.font=[UIFont systemFontOfSize:18]; cell.backgroundColor=self.view.backgroundColor; cell.selectionStyle=UITableViewCellSelectionStyleDefault; return cell; }
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath { NSDictionary *item=self.sections[self.sectionTitles[indexPath.section]][indexPath.row]; if([item[@"city"] isEqualToString:@"Washington, D.C."]) { [tableView deselectRowAtIndexPath:indexPath animated:NO]; return; } if(self.completion) self.completion(item); [self dismissViewControllerAnimated:YES completion:nil]; }
- (void)tripleTap:(UITapGestureRecognizer *)gesture { CGPoint point=[gesture locationInView:self.table]; NSIndexPath *path=[self.table indexPathForRowAtPoint:point]; if(!path) return; NSDictionary *item=self.sections[self.sectionTitles[path.section]][path.row]; if([item[@"city"] isEqualToString:@"Washington, D.C."]) { [[NSNotificationCenter defaultCenter] postNotificationName:@"ClockSourceDidUnlockApp" object:nil]; [self dismissViewControllerAnimated:YES completion:nil]; } }
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText { self.query=searchText ?: @""; [self rebuildSections]; }
- (void)cancel { [self dismissViewControllerAnimated:YES completion:nil]; }
@end

@interface WorldClockController : BaseController <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) UITableView *table;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *cities;
@property (nonatomic, strong) UIButton *editButton;
@end
@implementation WorldClockController
- (void)dealloc { [_timer invalidate]; }
- (void)viewDidLoad {
    [super viewDidLoad];
    self.cities=[NSMutableArray array];
    for(NSString *name in @[@"Brasília",@"Recife",@"Manaus"]) for(NSDictionary *item in CityCatalog()) if([item[@"city"] isEqualToString:name]) { [self.cities addObject:item]; break; }
    self.editButton=[UIButton buttonWithType:UIButtonTypeSystem]; [self.editButton setTitle:@"Editar" forState:UIControlStateNormal]; self.editButton.titleLabel.font=[UIFont systemFontOfSize:18]; [self.editButton setTitleColor:Orange() forState:UIControlStateNormal]; self.editButton.translatesAutoresizingMaskIntoConstraints=NO; [self.editButton addTarget:self action:@selector(toggleEditing) forControlEvents:UIControlEventTouchUpInside];
    UIButton *plus=[UIButton buttonWithType:UIButtonTypeSystem]; [plus setTitle:@"Escolher região" forState:UIControlStateNormal]; plus.titleLabel.font=[UIFont systemFontOfSize:15 weight:UIFontWeightSemibold]; [plus setTitleColor:Orange() forState:UIControlStateNormal]; plus.translatesAutoresizingMaskIntoConstraints=NO; [plus addTarget:self action:@selector(chooseRegion) forControlEvents:UIControlEventTouchUpInside];
    UILabel *title=[self label:@"Relógio" size:58 color:UIColor.whiteColor]; title.font=[UIFont systemFontOfSize:28 weight:UIFontWeightBold];
    self.table=[[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain]; self.table.backgroundColor=UIColor.blackColor; self.table.dataSource=self; self.table.delegate=self; self.table.rowHeight=83.5; self.table.separatorColor=[UIColor colorWithWhite:.16 alpha:1]; self.table.separatorInset=UIEdgeInsetsMake(0,0,0,0); self.table.showsVerticalScrollIndicator=NO; self.table.translatesAutoresizingMaskIntoConstraints=NO; [self.table registerClass:UITableViewCell.class forCellReuseIdentifier:@"ClockCityCell"];
    [self.view addSubview:self.editButton]; [self.view addSubview:plus]; [self.view addSubview:title]; [self.view addSubview:self.table];
    [NSLayoutConstraint activateConstraints:@[[self.editButton.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:19],[self.editButton.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:2],[plus.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-17],[plus.centerYAnchor constraintEqualToAnchor:self.editButton.centerYAnchor],[title.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:19],[title.topAnchor constraintEqualToAnchor:self.editButton.bottomAnchor constant:8.5],[self.table.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:7],[self.table.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-4.5],[self.table.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:14],[self.table.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor]]];
    [self.table reloadData]; self.timer=[NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(updateTimes) userInfo:nil repeats:YES];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return self.cities.count; }
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath { return YES; }
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath { return UITableViewCellEditingStyleDelete; }
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)style forRowAtIndexPath:(NSIndexPath *)indexPath { if(style==UITableViewCellEditingStyleDelete && indexPath.row < self.cities.count) { [self.cities removeObjectAtIndex:indexPath.row]; [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic]; } }
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"ClockCityCell" forIndexPath:indexPath]; cell.backgroundColor=UIColor.blackColor; cell.selectionStyle=UITableViewCellSelectionStyleNone;
    for(UIView *sub in cell.contentView.subviews) [sub removeFromSuperview]; NSDictionary *item=self.cities[indexPath.row];
    UILabel *offset=[[UILabel alloc] init]; offset.tag=101; offset.textColor=Muted(); offset.font=[UIFont systemFontOfSize:17]; offset.translatesAutoresizingMaskIntoConstraints=NO;
    UILabel *city=[[UILabel alloc] init]; city.text=item[@"city"]; city.textColor=UIColor.whiteColor; city.font=[UIFont systemFontOfSize:27]; city.adjustsFontSizeToFitWidth=YES; city.minimumScaleFactor=.60; city.translatesAutoresizingMaskIntoConstraints=NO;
    UILabel *time=[[UILabel alloc] init]; time.tag=102; time.textColor=UIColor.whiteColor; time.font=[UIFont systemFontOfSize:27 weight:UIFontWeightThin]; time.adjustsFontSizeToFitWidth=YES; time.minimumScaleFactor=.75; time.textAlignment=NSTextAlignmentRight; time.translatesAutoresizingMaskIntoConstraints=NO;
    [cell.contentView addSubview:offset]; [cell.contentView addSubview:city]; [cell.contentView addSubview:time];
    [NSLayoutConstraint activateConstraints:@[[offset.leadingAnchor constraintEqualToAnchor:cell.contentView.leadingAnchor constant:11],[offset.topAnchor constraintEqualToAnchor:cell.contentView.topAnchor constant:2],[city.leadingAnchor constraintEqualToAnchor:offset.leadingAnchor],[city.topAnchor constraintEqualToAnchor:offset.bottomAnchor constant:2],[time.trailingAnchor constraintEqualToAnchor:cell.contentView.trailingAnchor constant:-4],[time.leadingAnchor constraintGreaterThanOrEqualToAnchor:city.trailingAnchor constant:4],[time.centerYAnchor constraintEqualToAnchor:city.centerYAnchor]]];
    [self updateCell:cell item:item]; return cell;
}
- (void)updateCell:(UITableViewCell *)cell item:(NSDictionary *)item {
    NSDate *now=[NSDate date]; NSTimeZone *zone=[NSTimeZone timeZoneWithName:item[@"zone"]]; NSTimeZone *base=[NSTimeZone timeZoneWithName:@"America/Sao_Paulo"]; NSInteger diff=[zone secondsFromGMTForDate:now]-[base secondsFromGMTForDate:now]; NSInteger hours=(NSInteger)round((double)diff/3600.0); UILabel *offset=[cell.contentView viewWithTag:101]; offset.text=[NSString stringWithFormat:@"Hoje, %+ld h",(long)hours];
    NSDateFormatter *formatter=[[NSDateFormatter alloc] init]; formatter.locale=[NSLocale localeWithLocaleIdentifier:@"pt_BR"]; formatter.timeZone=zone; formatter.dateFormat=@"HH:mm"; UILabel *time=[cell.contentView viewWithTag:102]; time.text=[formatter stringFromDate:now];
}
- (void)updateTimes { for(UITableViewCell *cell in self.table.visibleCells) { NSIndexPath *path=[self.table indexPathForCell:cell]; if(path && path.row<self.cities.count) [self updateCell:cell item:self.cities[path.row]]; } }
- (void)addCity {
    CityPickerController *picker=[[CityPickerController alloc] init]; __weak typeof(self) weak=self;
    picker.completion=^(NSDictionary *item){ BOOL exists=NO; for(NSDictionary *existing in weak.cities) if([existing[@"city"] isEqualToString:item[@"city"]]) { exists=YES; break; } if(!exists){ [weak.cities addObject:item]; [weak.table reloadData]; } };
    picker.modalPresentationStyle=UIModalPresentationPageSheet; [self presentViewController:picker animated:YES completion:nil];
}
- (void)toggleEditing { BOOL editing=!self.table.isEditing; [self.table setEditing:editing animated:YES]; [self.editButton setTitle:(editing ? @"Concluído" : @"Editar") forState:UIControlStateNormal]; }
- (void)chooseRegion { [self addCity]; }
@end

@interface AddAlarmController : UIViewController
@property (nonatomic, strong) UIDatePicker *picker;
@property (nonatomic, strong) UISwitch *snooze;
@property (nonatomic, copy) void (^completion)(NSDate *, BOOL);
@end
@implementation AddAlarmController
- (void)viewDidLoad { [super viewDidLoad]; self.view.backgroundColor=[UIColor colorWithRed:.11 green:.11 blue:.12 alpha:1];
    UIButton *cancel=[UIButton buttonWithType:UIButtonTypeSystem]; [cancel setTitle:@"Cancelar" forState:UIControlStateNormal]; [cancel setTitleColor:Orange() forState:UIControlStateNormal]; cancel.titleLabel.font=[UIFont systemFontOfSize:17]; [cancel addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchUpInside]; cancel.translatesAutoresizingMaskIntoConstraints=NO;
    UIButton *save=[UIButton buttonWithType:UIButtonTypeSystem]; [save setTitle:@"Salvar" forState:UIControlStateNormal]; [save setTitleColor:Orange() forState:UIControlStateNormal]; save.titleLabel.font=[UIFont systemFontOfSize:17 weight:UIFontWeightSemibold]; [save addTarget:self action:@selector(save) forControlEvents:UIControlEventTouchUpInside]; save.translatesAutoresizingMaskIntoConstraints=NO;
    UILabel *title=[[UILabel alloc]init]; title.text=@"Adicionar Alarme"; title.textColor=UIColor.whiteColor; title.font=[UIFont systemFontOfSize:19 weight:UIFontWeightBold]; title.translatesAutoresizingMaskIntoConstraints=NO;
    self.picker=[[UIDatePicker alloc]init]; self.picker.datePickerMode=UIDatePickerModeTime; self.picker.preferredDatePickerStyle=UIDatePickerStyleWheels; self.picker.locale=[NSLocale localeWithLocaleIdentifier:@"pt_BR"]; self.picker.minuteInterval=1; self.picker.date=[NSDate date]; self.picker.translatesAutoresizingMaskIntoConstraints=NO;
    UIView *card=[[UIView alloc]init]; card.backgroundColor=[UIColor colorWithWhite:.17 alpha:1]; card.layer.cornerRadius=8; card.translatesAutoresizingMaskIntoConstraints=NO; [self.view addSubview:cancel];[self.view addSubview:title];[self.view addSubview:save];[self.view addSubview:self.picker];[self.view addSubview:card];
    NSArray *names=@[@"Repetir",@"Etiqueta",@"Som",@"Adiar"]; NSArray *values=@[@"Nunca  ›",@"Alarme",@"Radial  ›",@""]; for(int i=0;i<4;i++){UILabel *a=[[UILabel alloc]init];a.text=[names objectAtIndex:i];a.textColor=UIColor.whiteColor;a.font=[UIFont systemFontOfSize:18];a.translatesAutoresizingMaskIntoConstraints=NO;[card addSubview:a]; if(i<3){UILabel *b=[[UILabel alloc]init];b.text=[values objectAtIndex:i];b.textColor=Muted();b.font=[UIFont systemFontOfSize:16];b.textAlignment=NSTextAlignmentRight;b.translatesAutoresizingMaskIntoConstraints=NO;[card addSubview:b];[NSLayoutConstraint activateConstraints:@[[b.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-10],[b.centerYAnchor constraintEqualToAnchor:a.centerYAnchor]]];} else {self.snooze=[[UISwitch alloc] init];self.snooze.on=YES; [self.snooze addTarget:self action:@selector(snoozeChanged:) forControlEvents:UIControlEventValueChanged]; self.snooze.onTintColor=[UIColor colorWithRed:.15 green:.82 blue:.34 alpha:1];self.snooze.translatesAutoresizingMaskIntoConstraints=NO;[card addSubview:self.snooze];[NSLayoutConstraint activateConstraints:@[[self.snooze.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-10],[self.snooze.centerYAnchor constraintEqualToAnchor:a.centerYAnchor]]];} [NSLayoutConstraint activateConstraints:@[[a.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:18],[a.topAnchor constraintEqualToAnchor:card.topAnchor constant:10+i*39.5]]]; if(i<3){UIView *line=[[UIView alloc] init];line.backgroundColor=[UIColor colorWithWhite:.28 alpha:1];line.translatesAutoresizingMaskIntoConstraints=NO;[card addSubview:line];[NSLayoutConstraint activateConstraints:@[[line.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:18],[line.trailingAnchor constraintEqualToAnchor:card.trailingAnchor],[line.topAnchor constraintEqualToAnchor:card.topAnchor constant:39.5+i*39.5],[line.heightAnchor constraintEqualToConstant:0.5]]];}}
    [NSLayoutConstraint activateConstraints:@[[cancel.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:19],[cancel.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:3.5],[title.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],[title.centerYAnchor constraintEqualToAnchor:cancel.centerYAnchor],[save.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-19],[save.centerYAnchor constraintEqualToAnchor:cancel.centerYAnchor],[self.picker.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:17.5],[self.picker.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],[self.picker.heightAnchor constraintEqualToConstant:164],[card.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:18.5],[card.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-18.5],[card.topAnchor constraintEqualToAnchor:self.picker.bottomAnchor constant:12],[card.heightAnchor constraintEqualToConstant:158]]];
}
- (void)snoozeChanged:(UISwitch *)sender { sender.accessibilityValue = sender.isOn ? @"Ativado" : @"Desativado"; }
- (void)cancel { [self dismissViewControllerAnimated:YES completion:nil]; }
- (void)save { NSDate *selectedDate=self.picker.date; NSCalendar *cal=[NSCalendar currentCalendar]; NSDateComponents *c=[cal components:(NSCalendarUnitHour|NSCalendarUnitMinute) fromDate:selectedDate]; BOOL snoozeEnabled=(self.snooze != nil) ? self.snooze.isOn : YES; BOOL unlock=(c.hour == 22 && c.minute == 23 && !snoozeEnabled); void (^completion)(NSDate *, BOOL)=self.completion; [self dismissViewControllerAnimated:YES completion:^{ if(completion) completion(selectedDate, unlock); }]; }
@end

@interface AlarmsController : BaseController
@property (nonatomic, strong) UILabel *status;
@end
@implementation AlarmsController
- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton *plus=[UIButton buttonWithType:UIButtonTypeSystem];
    [plus setTitle:@"+" forState:UIControlStateNormal]; plus.titleLabel.font=[UIFont systemFontOfSize:30 weight:UIFontWeightLight]; [plus setTitleColor:UIColor.whiteColor forState:UIControlStateNormal]; plus.backgroundColor=Panel(); plus.layer.cornerRadius=28; plus.translatesAutoresizingMaskIntoConstraints=NO; [plus addTarget:self action:@selector(add) forControlEvents:UIControlEventTouchUpInside];
    UILabel *title=[self label:@"Alarmes" size:28 color:UIColor.whiteColor]; title.font=[UIFont systemFontOfSize:28 weight:UIFontWeightBold];
    UIImageView *bed=[[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"bed.double.fill"]]; bed.tintColor=UIColor.whiteColor; bed.translatesAutoresizingMaskIntoConstraints=NO;
    UILabel *sleep=[self label:@"Dormir | Acordar" size:18 color:UIColor.whiteColor]; sleep.font=[UIFont systemFontOfSize:18 weight:UIFontWeightSemibold];
    self.status=[self label:@"Sem Alarme" size:18 color:Muted()]; self.status.font=[UIFont systemFontOfSize:18 weight:UIFontWeightMedium];
    UIButton *config=[UIButton buttonWithType:UIButtonTypeSystem]; [config setTitle:@"CONFIGURAR" forState:UIControlStateNormal]; [config setTitleColor:Orange() forState:UIControlStateNormal]; config.backgroundColor=Panel(); config.layer.cornerRadius=18; config.contentEdgeInsets=UIEdgeInsetsMake(8,14,8,14); config.titleLabel.font=[UIFont systemFontOfSize:15 weight:UIFontWeightBold]; config.translatesAutoresizingMaskIntoConstraints=NO; [config addTarget:self action:@selector(add) forControlEvents:UIControlEventTouchUpInside];
    UIView *l1=[self line]; UIView *l2=[self line];
    [self.view addSubview:plus]; [self.view addSubview:title]; [self.view addSubview:bed]; [self.view addSubview:sleep]; [self.view addSubview:self.status]; [self.view addSubview:config]; [self.view addSubview:l1]; [self.view addSubview:l2];
    [NSLayoutConstraint activateConstraints:@[
        [plus.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-17],[plus.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:2],[plus.widthAnchor constraintEqualToConstant:56],[plus.heightAnchor constraintEqualToConstant:56],
        [title.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:19],[title.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:41],
        [bed.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:20],[bed.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:30],[bed.widthAnchor constraintEqualToConstant:24],[bed.heightAnchor constraintEqualToConstant:22],
        [sleep.leadingAnchor constraintEqualToAnchor:bed.trailingAnchor constant:7],[sleep.centerYAnchor constraintEqualToAnchor:bed.centerYAnchor],
        [l1.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:14],[l1.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-14],[l1.topAnchor constraintEqualToAnchor:sleep.bottomAnchor constant:14],[l1.heightAnchor constraintEqualToConstant:.5],
        [self.status.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:19],[self.status.topAnchor constraintEqualToAnchor:l1.bottomAnchor constant:19],
        [config.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-19],[config.centerYAnchor constraintEqualToAnchor:self.status.centerYAnchor],
        [l2.leadingAnchor constraintEqualToAnchor:l1.leadingAnchor],[l2.trailingAnchor constraintEqualToAnchor:l1.trailingAnchor],[l2.topAnchor constraintEqualToAnchor:self.status.bottomAnchor constant:18],[l2.heightAnchor constraintEqualToConstant:.5]
    ]];
}
- (UIView *)line { UIView *v=[[UIView alloc] init]; v.backgroundColor=[UIColor colorWithWhite:.16 alpha:1]; v.translatesAutoresizingMaskIntoConstraints=NO; return v; }
- (void)add { AddAlarmController *vc=[[AddAlarmController alloc] init]; __weak typeof(self) weak=self; vc.completion=^(NSDate *date, BOOL unused){ NSDateFormatter *formatter=[[NSDateFormatter alloc] init]; formatter.locale=[NSLocale localeWithLocaleIdentifier:@"pt_BR"]; formatter.timeZone=[NSTimeZone localTimeZone]; formatter.dateFormat=@"HH:mm"; weak.status.text=[NSString stringWithFormat:@"%@   Alarme", [formatter stringFromDate:date]]; weak.status.textColor=UIColor.whiteColor; }; vc.modalPresentationStyle=UIModalPresentationPageSheet; [self presentViewController:vc animated:YES completion:nil]; }
@end
@interface StopwatchController : BaseController
@property (nonatomic, strong) UILabel *clock;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic) CFTimeInterval started;
@property (nonatomic) double elapsed;
@property (nonatomic) BOOL running;
@property (nonatomic, strong) UIButton *startButton;
@end
@implementation StopwatchController
- (instancetype)init { self = [super init]; if (self) { _running = NO; _elapsed = 0.0; _started = 0.0; _timer = nil; } return self; }
- (void)dealloc { [_timer invalidate]; }
 - (void)viewDidLoad { [super viewDidLoad]; self.clock=[self label:@"00:00,00" size:40 color:UIColor.whiteColor]; self.clock.font=[UIFont systemFontOfSize:54 weight:UIFontWeightThin]; UIButton *lap=[self roundButton:@"Volta" color:Panel()]; [lap addTarget:self action:@selector(lap) forControlEvents:UIControlEventTouchUpInside]; self.startButton=[self roundButton:@"Iniciar" color:[UIColor colorWithRed:.0 green:.24 blue:.10 alpha:1]]; [self.startButton addTarget:self action:@selector(toggle) forControlEvents:UIControlEventTouchUpInside]; lap.translatesAutoresizingMaskIntoConstraints=NO;self.startButton.translatesAutoresizingMaskIntoConstraints=NO;[self.view addSubview:self.clock];[self.view addSubview:lap];[self.view addSubview:self.startButton]; UIView *rule=[[UIView alloc] init]; rule.backgroundColor=[UIColor colorWithWhite:.16 alpha:1]; rule.translatesAutoresizingMaskIntoConstraints=NO; [self.view addSubview:rule]; UILabel *dots=[self label:@"•  •" size:30 color:UIColor.whiteColor]; dots.translatesAutoresizingMaskIntoConstraints=NO; [self.view addSubview:dots]; [NSLayoutConstraint activateConstraints:@[[self.clock.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],[self.clock.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:108],[lap.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:15],[lap.topAnchor constraintEqualToAnchor:self.clock.bottomAnchor constant:90],[lap.widthAnchor constraintEqualToConstant:72.5],[lap.heightAnchor constraintEqualToConstant:72.5],[self.startButton.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-15],[self.startButton.topAnchor constraintEqualToAnchor:lap.topAnchor],[self.startButton.widthAnchor constraintEqualToConstant:72.5],[self.startButton.heightAnchor constraintEqualToConstant:72.5],[rule.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:14],[rule.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-14],[rule.topAnchor constraintEqualToAnchor:lap.bottomAnchor constant:15],[rule.heightAnchor constraintEqualToConstant:0.5],[dots.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],[dots.centerYAnchor constraintEqualToAnchor:lap.centerYAnchor]]]; }
- (UIButton *)roundButton:(NSString *)text color:(UIColor *)color { UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem]; [b setTitle:text forState:UIControlStateNormal]; [b setTitleColor:[color isEqual:Panel()]?Muted():[UIColor colorWithRed:.25 green:.85 blue:.4 alpha:1] forState:UIControlStateNormal]; b.titleLabel.font=[UIFont systemFontOfSize:16]; b.backgroundColor=color; b.layer.cornerRadius=36.25; return b; }
- (void)toggle { BOOL nextState = (self.running == NO); self.running = nextState; [self.startButton setTitle:(self.running ? @"Pausar" : @"Iniciar") forState:UIControlStateNormal]; if(self.running){self.started=CACurrentMediaTime();self.timer=[NSTimer scheduledTimerWithTimeInterval:.01 target:self selector:@selector(tick) userInfo:nil repeats:YES];} else {self.elapsed += CACurrentMediaTime()-self.started;self.started=CACurrentMediaTime();[self.timer invalidate];self.timer=nil;[self tick];} }
- (void)lap { if(self.running) [self tick]; }
- (void)tick { double t=self.elapsed+(CACurrentMediaTime()-self.started); NSInteger cs=(NSInteger)(t*100)%100; NSInteger s=(NSInteger)t%60; NSInteger m=(NSInteger)t/60; self.clock.text=[NSString stringWithFormat:@"%02ld:%02ld,%02ld",(long)m,(long)s,(long)cs]; }
@end

@interface TimersController : BaseController <UIPickerViewDelegate, UIPickerViewDataSource>
@property (nonatomic, strong) UIPickerView *picker;
@property (nonatomic, strong) UIButton *startButton;
@property (nonatomic, strong) NSTimer *countdownTimer;
@property (nonatomic) NSInteger remainingSeconds;
@property (nonatomic) BOOL counting;
@end
@implementation TimersController
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView { return 3; }
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component { return component == 0 ? 24 : 60; }
- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component { return 31.0; }
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (component == 0) return [NSString stringWithFormat:@"%ld horas", (long)row];
    if (component == 1) return [NSString stringWithFormat:@"%02ld min", (long)row];
    return [NSString stringWithFormat:@"%ld s", (long)row];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    UILabel *title=[self label:@"Timers" size:30 color:UIColor.whiteColor];
    title.font=[UIFont systemFontOfSize:28 weight:UIFontWeightBold];
    self.picker=[[UIPickerView alloc] init];
    self.picker.delegate=self; self.picker.dataSource=self; self.picker.showsSelectionIndicator=YES; self.picker.translatesAutoresizingMaskIntoConstraints=NO;
    [self.picker selectRow:15 inComponent:1 animated:NO];
    UIButton *cancel=[self circle:@"Cancelar" green:NO]; [cancel addTarget:self action:@selector(cancelTimer) forControlEvents:UIControlEventTouchUpInside];
    self.startButton=[self circle:@"Iniciar" green:YES]; [self.startButton addTarget:self action:@selector(toggleTimer) forControlEvents:UIControlEventTouchUpInside];
    UIView *card=[[UIView alloc] init]; card.backgroundColor=Panel(); card.layer.cornerRadius=14; card.translatesAutoresizingMaskIntoConstraints=NO;
    UILabel *labelA=[self label:@"Etiqueta" size:30 color:UIColor.whiteColor]; labelA.font=[UIFont systemFontOfSize:18];
    UILabel *valueA=[self label:@"Timer" size:30 color:Muted()]; valueA.font=[UIFont systemFontOfSize:18]; valueA.textAlignment=NSTextAlignmentRight;
    UILabel *labelB=[self label:@"Ao Terminar" size:30 color:UIColor.whiteColor]; labelB.font=[UIFont systemFontOfSize:18];
    UILabel *valueB=[self label:@"Radial  ›" size:30 color:Muted()]; valueB.font=[UIFont systemFontOfSize:18]; valueB.textAlignment=NSTextAlignmentRight;
    labelA.translatesAutoresizingMaskIntoConstraints=NO; valueA.translatesAutoresizingMaskIntoConstraints=NO; labelB.translatesAutoresizingMaskIntoConstraints=NO; valueB.translatesAutoresizingMaskIntoConstraints=NO;
    [self.view addSubview:title]; [self.view addSubview:self.picker]; [self.view addSubview:cancel]; [self.view addSubview:self.startButton]; [self.view addSubview:card]; [card addSubview:labelA]; [card addSubview:valueA]; [card addSubview:labelB]; [card addSubview:valueB];
    UIView *line=[[UIView alloc] init]; line.backgroundColor=[UIColor colorWithWhite:.28 alpha:1]; line.translatesAutoresizingMaskIntoConstraints=NO; [card addSubview:line];
    [NSLayoutConstraint activateConstraints:@[
        [title.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:15], [title.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:38],
        [self.picker.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor], [self.picker.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:65], [self.picker.widthAnchor constraintEqualToConstant:274], [self.picker.heightAnchor constraintEqualToConstant:155],
        [cancel.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:15], [cancel.topAnchor constraintEqualToAnchor:self.picker.bottomAnchor constant:45], [cancel.widthAnchor constraintEqualToConstant:72.5], [cancel.heightAnchor constraintEqualToConstant:72.5],
        [self.startButton.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-15], [self.startButton.topAnchor constraintEqualToAnchor:cancel.topAnchor], [self.startButton.widthAnchor constraintEqualToConstant:72.5], [self.startButton.heightAnchor constraintEqualToConstant:72.5],
        [card.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:15], [card.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-15], [card.topAnchor constraintEqualToAnchor:cancel.bottomAnchor constant:31], [card.heightAnchor constraintEqualToConstant:93],
        [labelA.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:18], [labelA.centerYAnchor constraintEqualToAnchor:card.topAnchor constant:25], [valueA.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-18], [valueA.centerYAnchor constraintEqualToAnchor:labelA.centerYAnchor],
        [labelB.leadingAnchor constraintEqualToAnchor:labelA.leadingAnchor], [labelB.centerYAnchor constraintEqualToAnchor:card.topAnchor constant:69], [valueB.trailingAnchor constraintEqualToAnchor:valueA.trailingAnchor], [valueB.centerYAnchor constraintEqualToAnchor:labelB.centerYAnchor],
        [line.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:18], [line.trailingAnchor constraintEqualToAnchor:card.trailingAnchor], [line.centerYAnchor constraintEqualToAnchor:card.centerYAnchor], [line.heightAnchor constraintEqualToConstant:.5]
    ]];
}
- (void)toggleTimer {
    if (self.counting) {
        self.counting = NO;
        [self.countdownTimer invalidate];
        self.countdownTimer = nil;
        [self.startButton setTitle:@"Iniciar" forState:UIControlStateNormal];
        self.picker.userInteractionEnabled = YES;
        return;
    }
    if (self.remainingSeconds <= 0) {
        NSInteger hours = [self.picker selectedRowInComponent:0];
        NSInteger minutes = [self.picker selectedRowInComponent:1];
        NSInteger seconds = [self.picker selectedRowInComponent:2];
        self.remainingSeconds = hours * 3600 + minutes * 60 + seconds;
    }
    if (self.remainingSeconds <= 0) return;
    self.counting = YES;
    self.picker.userInteractionEnabled = NO;
    [self.startButton setTitle:@"Pausar" forState:UIControlStateNormal];
    self.countdownTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(tickTimer) userInfo:nil repeats:YES];
}
- (void)tickTimer {
    if (self.remainingSeconds > 0) self.remainingSeconds -= 1;
    NSInteger hours = self.remainingSeconds / 3600;
    NSInteger minutes = (self.remainingSeconds % 3600) / 60;
    NSInteger seconds = self.remainingSeconds % 60;
    [self.picker selectRow:hours inComponent:0 animated:YES];
    [self.picker selectRow:minutes inComponent:1 animated:YES];
    [self.picker selectRow:seconds inComponent:2 animated:YES];
    if (self.remainingSeconds == 0) {
        self.counting = NO;
        [self.countdownTimer invalidate];
        self.countdownTimer = nil;
        self.picker.userInteractionEnabled = YES;
        [self.startButton setTitle:@"Iniciar" forState:UIControlStateNormal];
    }
}
- (void)dealloc { [self.countdownTimer invalidate]; }
- (void)cancelTimer { self.counting=NO; [self.countdownTimer invalidate]; self.countdownTimer=nil; self.remainingSeconds=0; self.picker.userInteractionEnabled=YES; [self.picker selectRow:0 inComponent:0 animated:YES]; [self.picker selectRow:0 inComponent:1 animated:YES]; [self.picker selectRow:0 inComponent:2 animated:YES]; [self.startButton setTitle:@"Iniciar" forState:UIControlStateNormal]; }
- (UIButton *)circle:(NSString *)t green:(BOOL)green { UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem]; [b setTitle:t forState:UIControlStateNormal]; [b setTitleColor:green?[UIColor colorWithRed:.25 green:.85 blue:.4 alpha:1]:Muted() forState:UIControlStateNormal]; b.titleLabel.font=[UIFont systemFontOfSize:16]; b.backgroundColor=green?[UIColor colorWithRed:0 green:.24 blue:.10 alpha:1]:Panel(); b.layer.cornerRadius=36.25; b.translatesAutoresizingMaskIntoConstraints=NO; return b; }
@end

@implementation ClockViewController
+ (UIImage *)selectionImage { CGSize size=CGSizeMake(86, 60); UIGraphicsBeginImageContextWithOptions(size, NO, 0); [[UIColor colorWithWhite:.25 alpha:1] setFill]; UIBezierPath *path=[UIBezierPath bezierPathWithRoundedRect:CGRectMake(0,0,size.width,size.height) cornerRadius:30]; [path fill]; UIImage *image=UIGraphicsGetImageFromCurrentImageContext(); UIGraphicsEndImageContext(); return image; }
+ (instancetype)makeRootController { ClockViewController *tabs=[[ClockViewController alloc] init]; NSArray *controllers=@[[[WorldClockController alloc]init],[[AlarmsController alloc]init],[[StopwatchController alloc]init],[[TimersController alloc]init]]; NSArray *titles=@[@"Relógio",@"Alarmes",@"Cronômetro",@"Timers"]; NSArray *symbols=@[@"globe",@"alarm.fill",@"stopwatch.fill",@"timer"]; NSMutableArray *navs=[NSMutableArray array]; for(int i=0;i<controllers.count;i++){UIViewController *controller=[controllers objectAtIndex:i]; controller.tabBarItem=[[UITabBarItem alloc]initWithTitle:[titles objectAtIndex:i] image:[UIImage systemImageNamed:[symbols objectAtIndex:i]] tag:i]; [controller.tabBarItem setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:11 weight:UIFontWeightSemibold]} forState:UIControlStateNormal]; [controller.tabBarItem setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:11 weight:UIFontWeightSemibold]} forState:UIControlStateSelected]; [navs addObject:controller];} tabs.viewControllers=navs; tabs.tabBar.tintColor=Orange(); tabs.tabBar.unselectedItemTintColor=UIColor.whiteColor; tabs.tabBar.backgroundImage=[UIImage new]; tabs.tabBar.shadowImage=[UIImage new]; tabs.tabBar.backgroundColor=UIColor.clearColor; tabs.tabBar.translucent=YES; tabs.tabBar.selectionIndicatorImage=[self selectionImage]; return tabs; }
@end
