#import <UIKit/UIKit.h>

@interface ClockViewController : UITabBarController
+ (instancetype)makeRootController;
@end
