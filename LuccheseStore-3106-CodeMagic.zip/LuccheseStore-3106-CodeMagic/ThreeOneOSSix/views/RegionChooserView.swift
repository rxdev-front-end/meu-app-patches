import SwiftUI

/// Fluxo visual pedido para abrir a interface completa da source do Relógio.
/// O usuário entra em "Escolher a região", toca três vezes em Estados Unidos,
/// vê a etapa de verificação/PADAK e então a tela UIKit original é apresentada.
struct RegionChooserView: View {
    @Environment(\.appLanguage) private var language
    @State private var tapCount = 0
    @State private var phase: RegionUnlockPhase = .idle
    @State private var isLaunching = false

    private enum RegionUnlockPhase: Equatable {
        case idle
        case counting(Int)
        case verifying
        case ready
    }

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 8) {
                    Label("Escolher a região", systemImage: "globe")
                        .font(.headline)
                    Text("Selecione uma região para continuar. Toque três vezes em Estados Unidos para abrir a interface integrada.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 6)
            }

            Section("Regiões") {
                regionRow(
                    flag: "🇺🇸",
                    title: "Estados Unidos",
                    subtitle: "United States · LL / LL/A",
                    isActive: phase != .idle
                )
                .contentShape(Rectangle())
                .onTapGesture(count: 3) {
                    startVerification()
                }
                .onTapGesture {
                    registerSingleTap()
                }
            }

            if phase != .idle {
                Section("Status") {
                    statusView
                }
            }
        }
        .navigationTitle("Escolher a região")
        .navigationBarTitleDisplayMode(.inline)
        .animation(.easeInOut(duration: 0.2), value: phase)
    }

    private func regionRow(flag: String, title: String, subtitle: String, isActive: Bool) -> some View {
        HStack(spacing: 12) {
            Text(flag)
                .font(.system(size: 30))
                .frame(width: 42, height: 42)
                .background(Color(uiColor: .secondarySystemBackground), in: Circle())
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.body.weight(.semibold))
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if isActive {
                Image(systemName: phase == .ready ? "checkmark.circle.fill" : "ellipsis.circle")
                    .foregroundStyle(phase == .ready ? .green : .orange)
            } else {
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.tertiary)
            }
        }
        .padding(.vertical, 5)
    }

    @ViewBuilder
    private var statusView: some View {
        switch phase {
        case .idle:
            EmptyView()
        case .counting(let count):
            Label("Toque \(count) de 3 registrado", systemImage: "hand.tap")
                .foregroundStyle(.orange)
        case .verifying:
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 10) {
                    ProgressView()
                    Text("Verificando…")
                        .font(.body.weight(.semibold))
                }
                Text("PADAK · preparando a interface da source")
                    .font(.caption.monospaced())
                    .foregroundStyle(.secondary)
            }
        case .ready:
            Label("Source pronta", systemImage: "checkmark.circle.fill")
                .foregroundStyle(.green)
        }
    }

    private func registerSingleTap() {
        guard !isLaunching else { return }
        tapCount = min(tapCount + 1, 2)
        phase = .counting(tapCount)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.65) {
            guard !isLaunching else { return }
            if phase != .verifying && phase != .ready {
                tapCount = 0
                phase = .idle
            }
        }
    }

    private func startVerification() {
        guard !isLaunching else { return }
        isLaunching = true
        tapCount = 3
        phase = .verifying
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.85) {
            phase = .ready
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                ClockEasterEgg.toggle()
                isLaunching = false
            }
        }
    }
}
