import UIKit

/// Easter egg da Lucchese Store: apresenta a interface do Relógio (fonte ObjC
/// integrada em `ThreeOneOSSix/clock/ClockViewController`) por cima do app.
///
/// Gatilho: três toques rápidos na linha da região dos Estados Unidos
/// (código `LL` / região de venda `LL/A`) da página "Região e IA da Siri".
/// Para voltar ao app, arraste o painel para baixo ou dê mais três toques
/// sobre o fundo do relógio.
///
/// A fonte do relógio permanece intacta: abertura, fechamento e estado vivem
/// apenas neste arquivo. O `UITabBarController` devolvido por
/// `+makeRootController` é apresentado como page sheet, então o gesto de
/// swipe para dismiss do próprio iOS continua funcionando.
final class ClockEasterEgg: NSObject, UIGestureRecognizerDelegate {
    static let shared = ClockEasterEgg()

    /// Referência fraca: depois do swipe para baixo o controller é liberado e
    /// o próximo toque recria o relógio do zero.
    private weak var clockController: UIViewController?

    /// Abre o relógio; se ele já estiver na tela, fecha.
    static func toggle() {
        let holder = ClockEasterEgg.shared
        holder.toggleNow()
    }

    private func toggleNow() {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { [weak self] in
                self?.toggleNow()
            }
            return
        }
        if let controller = clockController, controller.presentingViewController != nil {
            controller.dismiss(animated: true)
            return
        }
        guard let host = Self.topViewController() else { return }

        // O importer Swift do Xcode expõe `+makeRootController` como
        // `makeRoot()`, e o retorno vem como opcional por ser `instancetype`.
        guard let clock = ClockViewController.makeRoot() else { return }
        clock.modalPresentationStyle = .pageSheet
        clock.modalTransitionStyle = .coverVertical

        // Triplo toque para fechar. `cancelsTouchesInView = false` mantém
        // tabelas, botões, seletor de cidades e cronômetro funcionando: o
        // gesto só observa, não consome os toques.
        let gesture = UITapGestureRecognizer(target: self, action: #selector(handleTripleTap(_:)))
        gesture.numberOfTapsRequired = 3
        gesture.cancelsTouchesInView = false
        gesture.delegate = self
        clock.view.addGestureRecognizer(gesture)

        clockController = clock
        host.present(clock, animated: true)
    }

    @objc private func handleTripleTap(_ gesture: UITapGestureRecognizer) {
        clockController?.dismiss(animated: true)
    }

    // MARK: - UIGestureRecognizerDelegate

    /// Reconhecimento simultâneo: o relógio continua recebendo os toques.
    func gestureRecognizer(
        _ gestureRecognizer: UIGestureRecognizer,
        shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer
    ) -> Bool {
        true
    }

    // MARK: - Helpers

    /// Controller mais alto da hierarquia (inclui sheets já apresentados),
    /// para que o relógio apareça mesmo no meio de um fluxo de confirmação.
    private static func topViewController() -> UIViewController? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let scene = scenes.first { $0.activationState == .foregroundActive } ?? scenes.first
        guard let root = scene?.keyWindow?.rootViewController else { return nil }
        var controller = root
        while let presented = controller.presentedViewController {
            controller = presented
        }
        return controller
    }
}
