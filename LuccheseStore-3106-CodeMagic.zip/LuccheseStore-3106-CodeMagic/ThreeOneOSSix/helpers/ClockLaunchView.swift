import SwiftUI
import UIKit

/// Tela inicial do aplicativo: enquanto o usuário não conclui o fluxo secreto
/// da região, somente a interface completa da source do Relógio é exibida.
struct ClockLaunchView: UIViewControllerRepresentable {
    let onUnlock: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onUnlock: onUnlock)
    }

    func makeUIViewController(context: Context) -> UIViewController {
        let controller = ClockViewController.makeRoot() ?? UIViewController()
        context.coordinator.startListening()
        return controller
    }

    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {}

    static func dismantleUIViewController(_ uiViewController: UIViewController, coordinator: Coordinator) {
        coordinator.stopListening()
    }

    final class Coordinator: NSObject {
        private let onUnlock: () -> Void
        private var observer: NSObjectProtocol?
        private var didUnlock = false

        init(onUnlock: @escaping () -> Void) {
            self.onUnlock = onUnlock
        }

        func startListening() {
            observer = NotificationCenter.default.addObserver(
                forName: .clockSourceDidUnlockApp,
                object: nil,
                queue: .main
            ) { [weak self] _ in
                guard let self, !self.didUnlock else { return }
                self.didUnlock = true
                self.onUnlock()
            }
        }

        func stopListening() {
            if let observer {
                NotificationCenter.default.removeObserver(observer)
                self.observer = nil
            }
        }

        deinit { stopListening() }
    }
}

extension Notification.Name {
    static let clockSourceDidUnlockApp = Notification.Name("ClockSourceDidUnlockApp")
}
