# Integração remota — Lucchese Store

## Confirmação, feedback e validade em tempo real

- O app não exibe mais o alerta automático de “atualização disponível” da própria aplicação.
- A aba Info mostra contagem regressiva `dias HH:MM:SS` (ou `HH:MM:SS`) baseada no `expiresAt` da licença, atualizada a cada segundo; keys personalizadas deixam de aparecer incorretamente como “1 dia”.
- Tanto injetar quanto desinjetar pede confirmação explícita em folha personalizada. Durante a operação, uma sobreposição animada mostra “INJETANDO” ou “DESINJETANDO” e acompanha etapas reais; o resultado tem estado visual claro. Pacotes protegidos por senha também usam folha dedicada.
- Os badges distinguem Disponível (verde), Atualizando (laranja), Desativado (vermelho), Seguro e Risco. O switch fica centralizado, usa trilho verde quando ligado e as animações respeitam “Reduzir Movimento”.
- A aba Patches permite buscar por nome/descrição e filtrar por status e categoria. Cada card abre detalhes; há estados de carregamento, catálogo vazio, erro e nenhum resultado. O indicador apresenta estado de sync e horário da última atualização.
- A sobreposição de injeção mostra verificação de licença, download, integridade SHA-256, preparação e aplicação. A restauração mostra conferência do journal e recuperação dos arquivos. Uma confirmação adicional do sistema permanece para restaurar mesmo quando arquivos-alvo foram alterados após a injeção.

## Autorização, download e sincronização

- Para reduzir a espera, o download do pacote pode ocorrer em paralelo com a validação remota obrigatória. A validação do endpoint, o estado mais recente do catálogo e a comparação SHA-256 continuam necessárias antes de qualquer aplicação.
- A senha de pacote protegido usa os bytes pendentes apenas na sessão atual; cancelar descarta esse pacote pendente. Erros durante operações não mudam o patch para “ativo”.
- `RemoteIntegration.isSyncing` é alimentado por contador de operações. Assim, chamadas aninhadas ou sobrepostas (validação, catálogo e refresh) não desligam o indicador enquanto ainda existe trabalho remoto em andamento.
- Desativação continua usando o journal local e restaura os arquivos originais. Se os alvos tiverem sido alterados desde a injeção, o app pede confirmação antes de substituí-los pelos backups.

## Revisão visual e regra por categoria

Os cards reservam uma coluna fixa para o switch, alinhado ao centro vertical; os selos de disponibilidade/estado, segurança ou risco e versão são apresentados em linhas separadas com texto integral. Risco tem ícone triangular próprio e o patch aplicado recebe contorno e brilho verde animados.

A aba inferior **Tutorial** mostra as três instruções do usuário, a observação de HS e o alerta de punições. Só um patch pode permanecer ativo por categoria: o app desabilita os demais e informa qual patch precisa ser desativado; `RemoteIntegration.setPatchEnabled` também verifica a categoria antes e depois da revalidação do catálogo, para evitar disputa ou dados antigos.

A sobreposição de operação ignora as áreas seguras para ocupar a tela inteira e mantém o anel visual no centro. Os títulos das etapas incluem “Verificando licença”, “Validando pacote”, “Injetando”, “Verificando backups” e “Restaurando arquivos”. Não há porcentagem artificial. Feedback tátil de confirmação e conclusão é condicionado à configuração “Reduzir Movimento”.
