import Combine
import CryptoKit
import Foundation
import Security
import UIKit

struct RemotePatch: Decodable, Identifiable {
    let id: String
    var name: String
    var category: String?
    var categorySortOrder: Int
    var maxActivePatches: Int
    var description: String?
    var version: String?
    var status: String
    var risk: Bool
    var downloadURL: URL?
    var sha256: String?

    private enum CodingKeys: String, CodingKey {
        case id, name, category, categoryId, categorySortOrder, sortOrder, maxActivePatches, description, note, version, status, risk
        case downloadURL, fileURL, download, file, sha256
    }

    init(
        id: String,
        name: String,
        category: String? = nil,
        categorySortOrder: Int = Int.max,
        maxActivePatches: Int = 1,
        description: String? = nil,
        version: String? = nil,
        status: String = "desativado",
        risk: Bool = false,
        downloadURL: URL? = nil,
        sha256: String? = nil
    ) {
        self.id = id
        self.name = name
        self.category = category
        self.categorySortOrder = categorySortOrder
        self.maxActivePatches = max(1, maxActivePatches)
        self.description = description
        self.version = version
        self.status = status
        self.risk = risk
        self.downloadURL = downloadURL
        self.sha256 = sha256
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = (try? container.decode(String.self, forKey: .id))
            ?? (try? container.decode(Int.self, forKey: .id)).map(String.init)
            ?? ""
        name = (try? container.decode(String.self, forKey: .name)) ?? "Patch \(id)"
        category = (try? container.decode(String.self, forKey: .category))
            ?? (try? container.decode(String.self, forKey: .categoryId))
            ?? (try? container.decode(Int.self, forKey: .categoryId)).map(String.init)
        categorySortOrder = (try? container.decode(Int.self, forKey: .categorySortOrder))
            ?? (try? container.decode(Int.self, forKey: .sortOrder))
            ?? Int.max
        maxActivePatches = max(1, (try? container.decode(Int.self, forKey: .maxActivePatches)) ?? 1)
        description = (try? container.decode(String.self, forKey: .description))
            ?? (try? container.decode(String.self, forKey: .note))
        version = try? container.decode(String.self, forKey: .version)
        status = (try? container.decode(String.self, forKey: .status)) ?? "desativado"
        risk = (try? container.decode(Bool.self, forKey: .risk)) ?? false
        sha256 = try? container.decode(String.self, forKey: .sha256)
        let rawURL = (try? container.decode(String.self, forKey: .fileURL))
            ?? (try? container.decode(String.self, forKey: .downloadURL))
            ?? (try? container.decode(String.self, forKey: .download))
            ?? (try? container.decode(String.self, forKey: .file))
        downloadURL = rawURL.flatMap(URL.init(string:))
    }
}

struct RemoteAnnouncement: Decodable, Identifiable {
    let id: String
    let title: String
    let message: String
    let createdAt: String?

    private enum CodingKeys: String, CodingKey { case id, title, message, body, content, createdAt, date }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = (try? container.decode(String.self, forKey: .id))
            ?? (try? container.decode(Int.self, forKey: .id)).map(String.init)
            ?? UUID().uuidString
        title = (try? container.decode(String.self, forKey: .title)) ?? "Aviso"
        message = (try? container.decode(String.self, forKey: .message))
            ?? (try? container.decode(String.self, forKey: .body))
            ?? (try? container.decode(String.self, forKey: .content))
            ?? ""
        createdAt = (try? container.decode(String.self, forKey: .createdAt))
            ?? (try? container.decode(String.self, forKey: .date))
    }
}

private struct ActiveRemotePatchRecord: Codable {
    let projectID: UUID
    var name: String
    var category: String?
    var version: String?
    var risk: Bool
    let installedAt: Date
    var phase: String? = nil
}

enum RemotePatchToggleResult {
    case completed
    case requiresRiskConfirmation
    case requiresPassword
    case restoreNeedsConfirmation([String])
    case failed(String)
}

enum RemotePatchToggleProgress: Int, CaseIterable, Hashable {
    case checkingAccess
    case downloadingPackage
    case verifyingPackage
    case preparingPatch
    case applyingPatch
    case checkingBackup
    case restoringFiles

    var title: String {
        switch self {
        case .checkingAccess: return "Verificando licença"
        case .downloadingPackage: return "Baixando pacote"
        case .verifyingPackage: return "Validando pacote"
        case .preparingPatch: return "Preparando patch"
        case .applyingPatch: return "Injetando"
        case .checkingBackup: return "Verificando backups"
        case .restoringFiles: return "Restaurando arquivos"
        }
    }

    var detail: String {
        switch self {
        case .checkingAccess: return "Confirmando a licença; o download do pacote começa em paralelo."
        case .downloadingPackage: return "Pacote autorizado sendo baixado para este aparelho."
        case .verifyingPackage: return "Conferindo a versão publicada e o hash SHA-256 do arquivo."
        case .preparingPatch: return "Validando a estrutura e preparando a transação local."
        case .applyingPatch: return "Aplicando as alterações pelo mecanismo nativo do app."
        case .checkingBackup: return "Verificando o journal e os arquivos que serão restaurados."
        case .restoringFiles: return "Repondo os arquivos originais salvos neste aparelho."
        }
    }

    var symbol: String {
        switch self {
        case .checkingAccess: return "checkmark.shield"
        case .downloadingPackage: return "arrow.down.circle"
        case .verifyingPackage: return "checkmark.seal"
        case .preparingPatch: return "slider.horizontal.3"
        case .applyingPatch: return "bolt.fill"
        case .checkingBackup: return "doc.text.magnifyingglass"
        case .restoringFiles: return "arrow.uturn.backward.circle"
        }
    }
}

@MainActor
final class RemoteIntegration: ObservableObject {
    static let shared = RemoteIntegration()

    @Published private(set) var licensed = false
    @Published private(set) var serviceAllowed = false
    @Published private(set) var isRestoringSession = false
    @Published private(set) var isSyncing = false
    @Published private(set) var gateMessage: String?
    @Published private(set) var patches: [RemotePatch] = []
    @Published private(set) var announcements: [RemoteAnnouncement] = []
    @Published private(set) var isLoading = false
    @Published private(set) var lastVerifiedAt: Date?
    @Published private(set) var lastCatalogSync: Date?
    @Published private(set) var licensePlanDays: Int?
    @Published private(set) var licenseExpiresAt: String?
    @Published private(set) var licenseMaxDevices: Int?
    @Published private(set) var licenseErrorCode: String?
    @Published private(set) var hasServiceResponse = false
    @Published private(set) var storeName = "Lucchese Store"
    @Published private(set) var discordURL: URL?
    @Published private(set) var bannerGifURL: URL?
    @Published private(set) var activePatchIDs: Set<String> = []
    @Published private(set) var busyPatchIDs: Set<String> = []
    @Published var errorMessage: String?
    @Published var licenseKey = ""
    @Published private(set) var globalStatus = "checking"

    private let session = URLSession(configuration: .ephemeral)
    private let keychainService = "com.lucchese.3106.remote"
    private let licenseAccount = "license.key"
    private let deviceAccount = "device.hwid"
    private let licenseStorageKey = "3106.remote.license"
    private let activePatchStorageKey = "com.lucchese.store.active-patches.v1"
    private var activePatchRecords: [String: ActiveRemotePatchRecord] = [:]
    private var pendingPackageData: [String: Data] = [:]
    private var lastCatalogRefresh = Date.distantPast
    private var authorizationCheckInProgress = false
    private var catalogRefreshInProgress = false
    private var syncOperationCount = 0
    private var restoreAttempted = false

    private var baseURL: URL? {
        guard let raw = Bundle.main.object(forInfoDictionaryKey: "LUCCHESE_API_BASE_URL") as? String else { return nil }
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: value),
              let components = URLComponents(url: url, resolvingAgainstBaseURL: false),
              components.scheme?.lowercased() == "https",
              components.host != nil,
              components.user == nil,
              components.password == nil,
              components.query == nil,
              components.fragment == nil,
              components.path.isEmpty || components.path == "/" else { return nil }
        return url
    }

    var isConfigured: Bool { baseURL != nil }
    private var savedKey: String? { readKeychain(account: licenseAccount) }
    var deviceModelName: String {
        let identifier = AppInfo.displayMachineName
        return GestaltRegionService.siriNativeModels.first(where: { $0.id == identifier })?.name ?? identifier
    }
    var iosVersion: String { UIDevice.current.systemVersion }
    var deviceIdentifierSuffix: String { String(hwid.suffix(8)) }
    var activePatchCount: Int { activePatchIDs.count }

    var maskedLicenseKey: String {
        let value = savedKey ?? licenseKey
        guard !value.isEmpty else { return "—" }
        let pieces = value.split(separator: "-", maxSplits: 1, omittingEmptySubsequences: false)
        guard pieces.count == 2 else { return "••••••••" }
        let suffix = String(pieces[1].suffix(4))
        let hiddenCount = max(4, pieces[1].count - suffix.count)
        return "\(pieces[0])-\(String(repeating: "•", count: hiddenCount))\(suffix)"
    }

    var patchesForDisplay: [RemotePatch] {
        let visibleIDs = Set(patches.map(\.id))
        let archived = activePatchRecords.keys.sorted().compactMap { id -> RemotePatch? in
            guard !visibleIDs.contains(id), let record = activePatchRecords[id] else { return nil }
            return RemotePatch(
                id: id,
                name: record.name,
                category: record.category,
                description: "Retirado do catálogo. Você ainda pode desligar e restaurar este patch.",
                version: record.version,
                status: "desativado",
                risk: record.risk
            )
        }
        return patches + archived
    }

    var recoveryPatches: [RemotePatch] {
        patchesForDisplay.filter { activePatchIDs.contains($0.id) }
    }

    private var hwid: String {
        if let stored = readKeychain(account: deviceAccount), !stored.isEmpty { return stored }
        let generated = UUID().uuidString.uppercased()
        guard writeKeychain(generated, account: deviceAccount), readKeychain(account: deviceAccount) == generated else {
            return ""
        }
        return generated
    }

    private init() {
        licenseKey = readKeychain(account: licenseAccount) ?? ""
        if let legacy = UserDefaults.standard.string(forKey: licenseStorageKey), !legacy.isEmpty {
            if writeKeychain(legacy, account: licenseAccount) {
                licenseKey = legacy
                UserDefaults.standard.removeObject(forKey: licenseStorageKey)
            }
        }
        if let data = UserDefaults.standard.data(forKey: activePatchStorageKey),
           let records = try? JSONDecoder().decode([String: ActiveRemotePatchRecord].self, from: data) {
            activePatchRecords = records
            activePatchIDs = Set(records.keys)
        }
        isRestoringSession = !licenseKey.isEmpty
    }

    private func readKeychain(account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    @discardableResult
    private func writeKeychain(_ value: String, account: String) -> Bool {
        guard let data = value.data(using: .utf8) else { return false }
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: account,
        ]
        let attributes: [String: Any] = [
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
        ]
        let update = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if update == errSecSuccess { return true }
        guard update == errSecItemNotFound else { return false }
        var item = query
        attributes.forEach { item[$0.key] = $0.value }
        return SecItemAdd(item as CFDictionary, nil) == errSecSuccess
    }

    private func deleteKeychain(account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: account,
        ]
        SecItemDelete(query as CFDictionary)
    }

    private func clearStoredLicense() {
        deleteKeychain(account: licenseAccount)
        UserDefaults.standard.removeObject(forKey: licenseStorageKey)
        licenseKey = ""
        licensed = false
        licensePlanDays = nil
        licenseExpiresAt = nil
        licenseMaxDevices = nil
        lastVerifiedAt = nil
    }

    func prepareForKeyEntry() {
        if savedKey == nil { licenseKey = "" }
        licenseErrorCode = nil
        errorMessage = nil
        gateMessage = nil
    }

    private func endpoint(_ path: String) throws -> URL {
        guard let baseURL, let url = URL(string: path, relativeTo: baseURL)?.absoluteURL else {
            throw RemoteError.configuration
        }
        return url
    }

    private func attachMobileCredentials(to request: inout URLRequest) {
        guard let key = savedKey, !key.isEmpty, !hwid.isEmpty else { return }
        request.setValue(key, forHTTPHeaderField: "X-License-Key")
        request.setValue(hwid, forHTTPHeaderField: "X-Device-ID")
        request.setValue(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0", forHTTPHeaderField: "X-App-Version")
        request.setValue(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "0", forHTTPHeaderField: "X-App-Build")
    }

    private enum RemoteError: LocalizedError {
        case configuration
        case response(String, code: String?, status: Int)
        case malformed

        var code: String? {
            if case .response(_, let code, _) = self { return code?.lowercased() }
            return nil
        }

        var errorDescription: String? {
            switch self {
            case .configuration:
                return "Servidor remoto não configurado. Defina LUCCHESE_API_BASE_URL com a origem HTTPS publicada."
            case .response(let text, _, _):
                return text
            case .malformed:
                return "Resposta inesperada do servidor. Tente novamente."
            }
        }
    }

    private func send(
        _ path: String,
        method: String = "GET",
        body: [String: Any]? = nil,
        includeMobileCredentials: Bool = true
    ) async throws -> [String: Any] {
        var request = URLRequest(url: try endpoint(path), timeoutInterval: 25)
        request.httpMethod = method
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
        if let body {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        if includeMobileCredentials { attachMobileCredentials(to: &request) }
        // Não usar x-api-key: uma credencial estática distribuída no app não é segredo.
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw RemoteError.malformed }
        let payload = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
        guard (200..<300).contains(http.statusCode) else {
            let message = (payload["message"] as? String)
                ?? (payload["error"] as? String)
                ?? "Falha HTTP \(http.statusCode). Verifique a conexão e tente novamente."
            let code = (payload["code"] as? String) ?? (payload["error"] as? String)
            throw RemoteError.response(message, code: code, status: http.statusCode)
        }
        return payload
    }

    private func devicePayload() -> [String: Any] {
        [
            "hwid": hwid,
            "deviceModel": deviceModelName,
            "iosVersion": iosVersion,
            "appVersion": Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "0",
            "buildNumber": Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "0",
        ]
    }

    private func isLicenseRejection(_ error: Error) -> Bool {
        guard let remote = error as? RemoteError, let code = remote.code else { return false }
        return ["key_not_found", "key_expired", "key_revoked", "license_invalid", "license_inactive", "hwid_mismatch"]
            .contains(code)
    }

    @discardableResult
    func checkBootstrap(includeMobileCredentials: Bool = true) async -> Bool {
        guard isConfigured else {
            hasServiceResponse = false
            globalStatus = "offline"
            serviceAllowed = false
            licensed = false
            gateMessage = RemoteError.configuration.localizedDescription
            return false
        }
        guard !hwid.isEmpty else {
            hasServiceResponse = false
            globalStatus = "offline"
            serviceAllowed = false
            licensed = false
            gateMessage = "Não foi possível criar o identificador seguro deste dispositivo."
            return false
        }
        do {
            let result = try await send(
                "/api/app/bootstrap",
                method: "POST",
                body: devicePayload(),
                includeMobileCredentials: includeMobileCredentials
            )
            updateStatus(result)
            serviceAllowed = isServicePermitted(result)
            if !serviceAllowed {
                licensed = false
                gateMessage = preferredMessage(for: result)
            } else {
                gateMessage = nil
            }
            return serviceAllowed
        } catch {
            hasServiceResponse = false
            let remote = error as? RemoteError
            licenseErrorCode = remote?.code
            if isLicenseRejection(error) { clearStoredLicense() }
            if let code = remote?.code {
                globalStatus = code
            } else {
                globalStatus = "offline"
            }
            serviceAllowed = false
            licensed = false
            gateMessage = error.localizedDescription
            return false
        }
    }

    func restoreSavedSession() async {
        guard !restoreAttempted else { return }
        restoreAttempted = true
        guard let key = savedKey, !key.isEmpty else {
            isRestoringSession = false
            _ = await checkBootstrap()
            return
        }
        licenseKey = key
        isRestoringSession = true
        await refreshAuthorization()
        isRestoringSession = false
    }

    func activateOrValidate(key: String? = nil) async {
        guard !isLoading else { return }
        isLoading = true
        errorMessage = nil
        licenseErrorCode = nil
        defer {
            isLoading = false
            isRestoringSession = false
        }

        let candidate = (key ?? licenseKey).trimmingCharacters(in: .whitespacesAndNewlines)
        let currentKey = savedKey
        let chosenKey = candidate.isEmpty ? currentKey : candidate
        guard let chosenKey, !chosenKey.isEmpty else {
            errorMessage = "Informe sua chave de licença."
            return
        }
        guard !hwid.isEmpty else {
            errorMessage = "Não foi possível identificar este dispositivo com segurança."
            return
        }
        let isNewKey = currentKey == nil || currentKey?.caseInsensitiveCompare(chosenKey) != .orderedSame
        guard await checkBootstrap(includeMobileCredentials: !isNewKey) else { return }
        let payload: [String: Any] = ["key": chosenKey, "hwid": hwid]
        do {
            let response = try await send(
                isNewKey ? "/api/license/activate" : "/api/license/validate",
                method: "POST",
                body: payload,
                includeMobileCredentials: !isNewKey
            )
            guard isLicenseValid(response) else {
                licenseErrorCode = (response["code"] as? String)?.lowercased()
                let message = (response["message"] as? String)
                    ?? "A licença não está ativa. Confira a key e tente novamente."
                if !isNewKey {
                    clearStoredLicense()
                } else if let currentKey {
                    licenseKey = currentKey
                    await refreshAuthorization()
                } else {
                    licensed = false
                }
                errorMessage = message
                return
            }
            guard writeKeychain(chosenKey, account: licenseAccount) else {
                if let currentKey {
                    licenseKey = currentKey
                    await refreshAuthorization()
                } else {
                    licensed = false
                }
                errorMessage = "Não foi possível proteger a key no Keychain deste aparelho."
                return
            }
            licenseKey = chosenKey
            licenseErrorCode = nil
            updateLicenseDetails(response)
            restoreAttempted = true
            guard await checkBootstrap() else {
                errorMessage = gateMessage ?? "O serviço ou dispositivo não está liberado."
                return
            }
            licensed = true
            serviceAllowed = true
            lastVerifiedAt = Date()
            gateMessage = nil
            errorMessage = nil
            await refreshCatalog(force: true)
        } catch {
            let message = error.localizedDescription
            let failureCode = (error as? RemoteError)?.code
            if !isNewKey && isLicenseRejection(error) {
                clearStoredLicense()
            } else if isNewKey, let currentKey {
                licenseKey = currentKey
                await refreshAuthorization()
            } else {
                licensed = false
            }
            licenseErrorCode = failureCode
            errorMessage = message
            if !licensed { gateMessage = message }
        }
    }
    func unlink() async {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        guard let key = savedKey, !key.isEmpty else {
            errorMessage = "Não há uma licença salva neste aparelho."
            return
        }
        do {
            _ = try await send("/api/license/unlink-hwid", method: "POST", body: ["hwid": hwid, "key": key])
            clearStoredLicense()
            gateMessage = "Dispositivo desvinculado. Ative uma licença para continuar."
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func isLicenseValid(_ object: [String: Any]) -> Bool {
        guard (object["ok"] as? Bool) == true,
              let license = object["license"] as? [String: Any],
              let rawStatus = license["status"] as? String else { return false }
        return ["active", "valid", "ok"].contains(rawStatus.lowercased())
    }

    private func updateLicenseDetails(_ object: [String: Any]) {
        guard let license = object["license"] as? [String: Any] else { return }
        licensePlanDays = license["planDays"] as? Int
        licenseExpiresAt = license["expiresAt"] as? String
        licenseMaxDevices = license["maxDevices"] as? Int
    }

    private func serviceMode(from object: [String: Any]) -> String {
        let raw = (object["mode"] as? String)
            ?? (object["globalStatus"] as? String)
            ?? (object["status"] as? String)
            ?? "normal"
        let normalized = raw.lowercased()
        if ["active", "normal", "ok"].contains(normalized) { return "normal" }
        if ["disabled", "shutdown", "off"].contains(normalized) { return "offline" }
        if ["update"].contains(normalized) { return "updating" }
        return normalized
    }

    private func updateStatus(_ object: [String: Any]) {
        hasServiceResponse = true
        let branding = object["branding"] as? [String: Any] ?? [:]
        if let configuredName = branding["storeName"] as? String {
            let trimmed = configuredName.trimmingCharacters(in: .whitespacesAndNewlines)
            if !trimmed.isEmpty { storeName = trimmed }
        }
        if let rawDiscord = branding["discordUrl"] as? String,
           let components = URLComponents(string: rawDiscord),
           components.scheme?.lowercased() == "https",
           components.user == nil,
           components.password == nil,
           components.port == nil || components.port == 443,
           let host = components.host?.lowercased(),
           ["discord.gg", "discord.com", "www.discord.com"].contains(host) {
            discordURL = components.url
        } else {
            discordURL = nil
        }
        if let rawBanner = branding["bannerGifUrl"] as? String,
           let bannerURL = URL(string: rawBanner, relativeTo: baseURL)?.absoluteURL,
           let components = URLComponents(url: bannerURL, resolvingAgainstBaseURL: false),
           components.scheme?.lowercased() == "https",
           components.user == nil,
           components.password == nil,
           components.port == nil || components.port == 443,
           let host = components.host,
           !host.isEmpty {
            bannerGifURL = components.url
        } else {
            bannerGifURL = nil
        }
        let device = object["device"] as? [String: Any] ?? object
        if (device["banned"] as? Bool) == true {
            globalStatus = "banned"
            licenseErrorCode = "device_banned"
        } else {
            globalStatus = serviceMode(from: object)
            if ["normal", "active", "ok"].contains(globalStatus) { licenseErrorCode = nil }
        }
        let reason = device["banReason"] as? String
        let message = object["message"] as? String
        if globalStatus == "banned", let reason, !reason.isEmpty {
            gateMessage = "Este dispositivo foi bloqueado. \(reason)"
        } else if let message, !message.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            gateMessage = message
        }
    }

    private func isServicePermitted(_ object: [String: Any]) -> Bool {
        let device = object["device"] as? [String: Any] ?? object
        let banned = (device["banned"] as? Bool) == true
        return !banned && ["normal", "active", "ok"].contains(serviceMode(from: object))
    }

    private func preferredMessage(for object: [String: Any]) -> String {
        let device = object["device"] as? [String: Any] ?? object
        if (device["banned"] as? Bool) == true {
            let reason = (device["banReason"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines)
            return reason?.isEmpty == false ? "Este dispositivo foi bloqueado. \(reason!)" : "Este dispositivo foi bloqueado. Contate o suporte."
        }
        if let message = object["message"] as? String, !message.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return message
        }
        switch serviceMode(from: object) {
        case "maintenance": return "Serviço em manutenção. Tente novamente mais tarde."
        case "offline": return "Serviço temporariamente desligado. Tente novamente mais tarde."
        case "updating": return "Serviço em atualização. Tente novamente em alguns minutos."
        case "old_version", "old-version": return "Esta versão do app está desatualizada. Atualize para continuar."
        default: return "Não foi possível liberar o acesso. Tente novamente."
        }
    }

    private func decodeArray<T: Decodable>(_ type: T.Type, from object: Any?) -> [T] {
        guard let object, JSONSerialization.isValidJSONObject(object),
              let data = try? JSONSerialization.data(withJSONObject: object) else { return [] }
        if let direct = try? JSONDecoder().decode([T].self, from: data) { return direct }
        for key in ["data", "items", "catalog", "patches", "announcements", "results"] {
            if let nested = (object as? [String: Any])?[key],
               let nestedData = try? JSONSerialization.data(withJSONObject: nested),
               let decoded = try? JSONDecoder().decode([T].self, from: nestedData) { return decoded }
        }
        return []
    }

    func refreshCatalog(force: Bool = false) async {
        guard licensed, !catalogRefreshInProgress else { return }
        guard force || Date().timeIntervalSince(lastCatalogRefresh) >= 15 else { return }
        catalogRefreshInProgress = true
        beginSync()
        defer {
            catalogRefreshInProgress = false
            endSync()
        }
        do {
            async let catalogTask = send("/api/mobile/catalog")
            async let announcementsTask = send("/api/mobile/announcements")
            let (catalog, news) = try await (catalogTask, announcementsTask)
            let categoryRows = catalog["categories"] as? [[String: Any]] ?? []
            struct CategoryMetadata {
                let name: String
                let sortOrder: Int
                let maxActivePatches: Int
            }
            var categoryMetadata: [String: CategoryMetadata] = [:]
            for row in categoryRows {
                let id: String?
                if let stringID = row["id"] as? String {
                    id = stringID
                } else if let numericID = row["id"] as? Int {
                    id = String(numericID)
                } else {
                    id = nil
                }
                guard let id, let name = row["name"] as? String, categoryMetadata[id] == nil else { continue }
                categoryMetadata[id] = CategoryMetadata(
                    name: name,
                    sortOrder: row["sortOrder"] as? Int ?? Int.max,
                    maxActivePatches: max(1, min(10, row["maxActivePatches"] as? Int ?? 1))
                )
            }
            let decoded = decodeArray(RemotePatch.self, from: catalog["patches"] ?? catalog["data"] ?? catalog)
            patches = decoded.map { patch in
                var value = patch
                if let categoryID = patch.category, let category = categoryMetadata[categoryID] {
                    value.category = category.name
                    value.categorySortOrder = category.sortOrder
                    value.maxActivePatches = category.maxActivePatches
                } else if let categoryID = patch.category,
                          categoryID.range(of: "^[0-9a-fA-F]{32}$", options: .regularExpression) != nil {
                    value.category = nil
                }
                return value
            }
            announcements = decodeArray(RemoteAnnouncement.self, from: news["announcements"] ?? news["data"] ?? news)
            for patch in patches {
                guard var record = activePatchRecords[patch.id] else { continue }
                record.name = patch.name
                record.category = patch.category ?? record.category
                record.version = patch.version ?? record.version
                record.risk = patch.risk
                activePatchRecords[patch.id] = record
            }
            persistActivePatchRecords()
            lastCatalogRefresh = Date()
            lastCatalogSync = Date()
            errorMessage = nil
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func isPatchActive(_ id: String) -> Bool { activePatchIDs.contains(id) }
    func isPatchBusy(_ id: String) -> Bool { busyPatchIDs.contains(id) }

    func activePatchConflict(for patch: RemotePatch) -> String? {
        activePatchConflicts(for: patch).first
    }

    func activePatchConflicts(for patch: RemotePatch) -> [String] {
        let category = normalizedPatchCategory(patch.category)
        let activeNames = activePatchRecords
            .filter { $0.key != patch.id && normalizedPatchCategory($0.value.category) == category }
            .map { $0.value.name }
        return activeNames.count >= max(1, patch.maxActivePatches) ? activeNames : []
    }

    func activePatchLimit(for patch: RemotePatch) -> Int {
        max(1, patch.maxActivePatches)
    }

    private func normalizedPatchCategory(_ category: String?) -> String {
        let value = (category ?? "").trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return value.isEmpty ? "__sem_categoria__" : value
    }

    func discardPendingPackage(for patchID: String) {
        pendingPackageData.removeValue(forKey: patchID)
    }

    private func beginSync() {
        syncOperationCount += 1
        isSyncing = true
    }

    private func endSync() {
        syncOperationCount = max(0, syncOperationCount - 1)
        isSyncing = syncOperationCount > 0
    }

    private func persistActivePatchRecords() {
        activePatchIDs = Set(activePatchRecords.keys)
        guard let data = try? JSONEncoder().encode(activePatchRecords) else { return }
        UserDefaults.standard.set(data, forKey: activePatchStorageKey)
    }

    private func packageIDIsSafe(_ id: String) -> Bool {
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_")
        return !id.isEmpty && id.unicodeScalars.allSatisfy(allowed.contains)
    }

    private func downloadPackage(for patch: RemotePatch) async throws -> Data {
        guard isConfigured, packageIDIsSafe(patch.id) else {
            throw RemoteError.response("Identificador do patch inválido.", code: nil, status: 400)
        }
        var request = URLRequest(
            url: try endpoint("/api/mobile/patches/\(patch.id)/file"),
            timeoutInterval: 90
        )
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/octet-stream", forHTTPHeaderField: "Accept")
        attachMobileCredentials(to: &request)
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode) else {
            let http = response as? HTTPURLResponse
            throw RemoteError.response(
                "Não foi possível baixar o pacote. Verifique a conexão e o status no painel.",
                code: nil,
                status: http?.statusCode ?? 0
            )
        }
        guard !data.isEmpty, data.count <= 25 * 1_024 * 1_024 else {
            throw RemoteError.response("Arquivo vazio ou maior que o limite compatível de 25 MiB.", code: nil, status: 413)
        }
        if let expected = patch.sha256?.lowercased(), !expected.isEmpty {
            let actual = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
            guard actual == expected else {
                throw RemoteError.response("A verificação SHA-256 do pacote falhou. O patch não foi aplicado.", code: nil, status: 422)
            }
        }
        return data
    }

    func setPatchEnabled(
        _ patch: RemotePatch,
        enabled: Bool,
        password: String? = nil,
        riskConfirmed: Bool = false,
        allowChangedTargets: Bool = false,
        progress: (@MainActor (RemotePatchToggleProgress) -> Void)? = nil
    ) async -> RemotePatchToggleResult {
        guard busyPatchIDs.isEmpty else { return .failed("Aguarde a operação de patch em andamento terminar.") }
        busyPatchIDs.insert(patch.id)
        defer { busyPatchIDs.remove(patch.id) }

        if enabled {
            guard let candidatePatch = patches.first(where: { $0.id == patch.id }) else {
                return .failed("Este patch não está mais publicado no catálogo.")
            }
            guard candidatePatch.status.lowercased() == "ativo" else {
                let message = candidatePatch.status.lowercased() == "atualizando"
                    ? "Este patch está sendo atualizado e não pode ser ativado agora."
                    : "Este patch está desativado no painel."
                return .failed(message)
            }
            if candidatePatch.risk && !riskConfirmed { return .requiresRiskConfirmation }
            if isPatchActive(candidatePatch.id) { return .completed }
            if let conflict = activePatchConflict(for: candidatePatch) {
                return .failed("Já existe um patch ativo nesta categoria: \(conflict). Desative-o antes de ativar outro.")
            }

            // The download endpoint independently checks the license/device.
            // Start it alongside the mandatory fresh authorization check, but
            // still verify the latest catalog status/hash before using bytes.
            let pendingData = pendingPackageData[candidatePatch.id]
            progress?(.checkingAccess)
            let packageDownloadTask: Task<Data, Error>? = pendingData == nil
                ? Task { try await self.downloadPackage(for: candidatePatch) }
                : nil
            defer { packageDownloadTask?.cancel() }
            let authorizationIsCurrent = await refreshPatchAuthorization()
            guard authorizationIsCurrent, licensed, serviceAllowed else {
                return .failed(errorMessage ?? "Valide uma licença ativa neste dispositivo antes de ativar um patch.")
            }
            guard let currentPatch = patches.first(where: { $0.id == patch.id }) else {
                return .failed("Este patch não está mais publicado no catálogo.")
            }
            guard currentPatch.status.lowercased() == "ativo" else {
                let message = currentPatch.status.lowercased() == "atualizando"
                    ? "Este patch está sendo atualizado e não pode ser ativado agora."
                    : "Este patch está desativado no painel."
                return .failed(message)
            }
            guard currentPatch.sha256?.lowercased() == candidatePatch.sha256?.lowercased() else {
                return .failed("O pacote foi atualizado durante a verificação. Atualize o catálogo e tente novamente.")
            }
            if currentPatch.risk && !riskConfirmed { return .requiresRiskConfirmation }
            if isPatchActive(currentPatch.id) { return .completed }
            if let conflict = activePatchConflict(for: currentPatch) {
                return .failed("Já existe um patch ativo nesta categoria: \(conflict). Desative-o antes de ativar outro.")
            }
            if pendingData == nil { progress?(.downloadingPackage) }
            do {
                let data: Data
                if let pendingData {
                    data = pendingData
                } else if let packageDownloadTask {
                    data = try await packageDownloadTask.value
                } else {
                    return .failed("Não foi possível iniciar o download do pacote.")
                }
                progress?(.verifyingPackage)
                guard let expectedHash = currentPatch.sha256?.lowercased(), !expectedHash.isEmpty else {
                    pendingPackageData.removeValue(forKey: currentPatch.id)
                    return .failed("O catálogo não forneceu o SHA-256; o pacote não será aplicado.")
                }
                // Fresh downloads were already SHA-256 checked by downloadPackage.
                // Password retries reuse cached bytes, so re-check those against the current catalog hash.
                if pendingData != nil {
                    let actualHash = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
                    guard actualHash == expectedHash else {
                        pendingPackageData.removeValue(forKey: currentPatch.id)
                        return .failed("O pacote foi alterado desde o download. Atualize o catálogo e tente novamente.")
                    }
                }
                progress?(.preparingPatch)
                let summary = try await Task.detached(priority: .userInitiated) {
                    try PatchPackageCodec.inspect(data)
                }.value
                if summary.isPasswordProtected && password == nil {
                    pendingPackageData[currentPatch.id] = data
                    return .requiresPassword
                }
                let package = try await Task.detached(priority: .userInitiated) {
                    let decoded = try PatchPackageCodec.decode(data, password: password)
                    try PatchPackageCodec.validate(decoded.project)
                    guard !decoded.project.rules.isEmpty || !decoded.project.directories.isEmpty else {
                        throw PatchPackageError.invalidProject
                    }
                    return decoded
                }.value
                if let conflict = activePatchRecords.first(where: {
                    $0.key != currentPatch.id && $0.value.projectID == package.project.id
                }) {
                    return .failed("Este projeto já está vinculado ao patch ativo ‘\(conflict.value.name)’. Desative esse toggle primeiro.")
                }
                let record = ActiveRemotePatchRecord(
                    projectID: package.project.id,
                    name: currentPatch.name,
                    category: currentPatch.category,
                    version: currentPatch.version,
                    risk: currentPatch.risk,
                    installedAt: Date(),
                    phase: "applying"
                )
                let previousReceipt = try await Task.detached(priority: .userInitiated) {
                    try DevicePatchService.checkedLatestReceipt(projectID: package.project.id)
                }.value
                if previousReceipt != nil {
                    var recoverableRecord = record
                    recoverableRecord.phase = "active"
                    activePatchRecords[currentPatch.id] = recoverableRecord
                    persistActivePatchRecords()
                    return .failed("Há uma transação local anterior para este patch. O toggle foi mantido ligado; desligue-o para restaurar antes de tentar novamente.")
                }
                // Persist the mapping before the native transaction so a process interruption
                // can still recover a prepared/applied journal on the next launch.
                activePatchRecords[currentPatch.id] = record
                persistActivePatchRecords()
                do {
                    progress?(.applyingPatch)
                    _ = try await Task.detached(priority: .userInitiated) {
                        try DevicePatchService.apply(project: package.project)
                    }.value
                } catch {
                    let applyError = error
                    do {
                        let residualReceipt = try await Task.detached(priority: .userInitiated) {
                            try DevicePatchService.checkedLatestReceipt(projectID: package.project.id)
                        }.value
                        if residualReceipt == nil {
                            activePatchRecords.removeValue(forKey: currentPatch.id)
                        } else {
                            var recoverableRecord = record
                            recoverableRecord.phase = "active"
                            activePatchRecords[currentPatch.id] = recoverableRecord
                        }
                    } catch {
                        // Keep the applying record if we cannot prove that no journal exists.
                    }
                    persistActivePatchRecords()
                    throw applyError
                }
                var activeRecord = record
                activeRecord.phase = "active"
                activePatchRecords[currentPatch.id] = activeRecord
                persistActivePatchRecords()
                pendingPackageData.removeValue(forKey: currentPatch.id)
                return .completed
            } catch {
                pendingPackageData.removeValue(forKey: currentPatch.id)
                return .failed((error as? LocalizedError)?.errorDescription ?? error.localizedDescription)
            }
        }
        guard let record = activePatchRecords[patch.id] else { return .completed }
        do {
            progress?(.checkingBackup)
            let latestReceipt = try await Task.detached(priority: .userInitiated) {
                try DevicePatchService.checkedLatestReceipt(projectID: record.projectID)
            }.value
            guard let receipt = latestReceipt else {
                if record.phase == "applying" {
                    activePatchRecords.removeValue(forKey: patch.id)
                    persistActivePatchRecords()
                    return .completed
                }
                return .failed("O journal de restauração não está disponível. O patch foi mantido na lista para recuperação; tente novamente ou confira o armazenamento local.")
            }
            let inspection = try await Task.detached(priority: .userInitiated) {
                try DevicePatchService.inspectRestore(receipt: receipt)
            }.value
            if !inspection.changedTargets.isEmpty && !allowChangedTargets {
                return .restoreNeedsConfirmation(inspection.changedTargets.map(\.displayPath))
            }
            progress?(.restoringFiles)
            try await Task.detached(priority: .userInitiated) {
                try DevicePatchService.restore(receipt: receipt, allowChangedTargets: allowChangedTargets)
            }.value
            activePatchRecords.removeValue(forKey: patch.id)
            persistActivePatchRecords()
            return .completed
        } catch {
            return .failed((error as? LocalizedError)?.errorDescription ?? error.localizedDescription)
        }
    }
    private func refreshPatchAuthorization() async -> Bool {
        while authorizationCheckInProgress {
            if Task.isCancelled { return false }
            try? await Task.sleep(nanoseconds: 50_000_000)
        }
        guard !Task.isCancelled else { return false }
        authorizationCheckInProgress = true
        beginSync()
        defer {
            authorizationCheckInProgress = false
            endSync()
        }
        guard isConfigured, let key = savedKey, !key.isEmpty else {
            licensed = false
            serviceAllowed = false
            errorMessage = "Valide uma licença ativa neste dispositivo antes de ativar um patch."
            return false
        }
        do {
            // Este GET único confirma licença, vínculo do aparelho, banimento, status do serviço
            // e versão/build mínimos antes de qualquer operação local do motor de patches.
            _ = try await send("/api/mobile/catalog")
            licenseKey = key
            licenseErrorCode = nil
            licensed = true
            serviceAllowed = true
            globalStatus = "normal"
            gateMessage = nil
            errorMessage = nil
            lastVerifiedAt = Date()
            hasServiceResponse = true
            return true
        } catch {
            let remote = error as? RemoteError
            licenseErrorCode = remote?.code
            if isLicenseRejection(error) { clearStoredLicense() }
            licensed = false
            serviceAllowed = false
            globalStatus = remote?.code ?? "offline"
            errorMessage = error.localizedDescription
            gateMessage = error.localizedDescription
            return false
        }
    }
    private func refreshAuthorization() async {
        while authorizationCheckInProgress {
            if Task.isCancelled { return }
            try? await Task.sleep(nanoseconds: 50_000_000)
        }
        guard !Task.isCancelled else { return }
        authorizationCheckInProgress = true
        beginSync()
        defer {
            authorizationCheckInProgress = false
            endSync()
        }

        guard await checkBootstrap() else { return }
        guard let key = savedKey, !key.isEmpty else {
            licensed = false
            return
        }
        do {
            let response = try await send("/api/license/validate", method: "POST", body: ["key": key, "hwid": hwid])
            guard isLicenseValid(response) else {
                licenseErrorCode = (response["code"] as? String)?.lowercased()
                clearStoredLicense()
                errorMessage = (response["message"] as? String) ?? "A licença não está mais ativa."
                return
            }
            guard await checkBootstrap() else { return }
            licenseKey = key
            licenseErrorCode = nil
            updateLicenseDetails(response)
            licensed = true
            serviceAllowed = true
            gateMessage = nil
            errorMessage = nil
            lastVerifiedAt = Date()
            await refreshCatalog()
        } catch {
            licenseErrorCode = (error as? RemoteError)?.code
            if isLicenseRejection(error) { clearStoredLicense() }
            licensed = false
            errorMessage = error.localizedDescription
            gateMessage = error.localizedDescription
        }
    }

    func refreshSessionNow() async {
        beginSync()
        defer { endSync() }
        await refreshAuthorization()
        if licensed { await refreshCatalog(force: true) }
    }

    func monitor() async {
        await restoreSavedSession()
        while !Task.isCancelled {
            let cycleStartedAt = Date()
            if UIApplication.shared.applicationState == .active, isConfigured {
                await refreshAuthorization()
            }
            let remaining = max(0, 15 - Date().timeIntervalSince(cycleStartedAt))
            if remaining > 0 {
                try? await Task.sleep(nanoseconds: UInt64(remaining * 1_000_000_000))
            }
        }
    }
}
