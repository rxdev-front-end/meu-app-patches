import SwiftUI
import UIKit

private enum LucchesePalette {
    static let background = Color(red: 0.035, green: 0.039, blue: 0.047)
    static let surface = Color(red: 0.085, green: 0.090, blue: 0.102)
    static let raised = Color(red: 0.125, green: 0.133, blue: 0.149)
    static let line = Color.white.opacity(0.085)
    static let muted = Color(red: 0.57, green: 0.59, blue: 0.63)
    static let soft = Color(red: 0.77, green: 0.78, blue: 0.81)
    static let white = Color(red: 0.96, green: 0.96, blue: 0.97)
}

private enum StoreTab: String, CaseIterable, Identifiable {
    case patches
    case global
    case info

    var id: String { rawValue }
    var title: String {
        switch self {
        case .patches: return "Patches"
        case .global: return "Global"
        case .info: return "Info"
        }
    }
    var icon: String {
        switch self {
        case .patches: return "square.stack.3d.up.fill"
        case .global: return "bell.badge.fill"
        case .info: return "info.circle.fill"
        }
    }
    var subtitle: String {
        switch self {
        case .patches: return "Seu catálogo, organizado por categoria."
        case .global: return "Comunicados publicados pela Lucchese Store."
        case .info: return "Licença, dispositivo e estado da sessão."
        }
    }
}

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @ObservedObject private var remoteIntegration = RemoteIntegration.shared

    @State private var selectedTab: StoreTab = .patches
    @State private var patchForRisk: RemotePatch?
    @State private var showRiskConfirmation = false
    @State private var passwordPatch: RemotePatch?
    @State private var passwordValue = ""
    @State private var showPasswordPrompt = false
    @State private var restorePatch: RemotePatch?
    @State private var restoreChangedPaths: [String] = []
    @State private var showRestoreConfirmation = false
    @State private var actionError: String?
    @State private var showActionError = false
    @State private var showUnlinkConfirmation = false

    var body: some View {
        ZStack {
            LucchesePalette.background.ignoresSafeArea()
            if remoteIntegration.isRestoringSession {
                restoringSession
                    .transition(.opacity)
            } else if let state = accessGateKind {
                AccessStatusView(state: state, service: remoteIntegration) {
                    Task { await remoteIntegration.refreshSessionNow() }
                }
                .transition(reduceMotion ? .opacity : .opacity.combined(with: .move(edge: .bottom)))
            } else if remoteIntegration.licensed {
                authenticatedStore
                    .transition(reduceMotion ? .opacity : .opacity.combined(with: .move(edge: .bottom)))
            } else {
                LuccheseKeyEntryView(service: remoteIntegration) { patch in
                    requestToggle(patch, enabled: false)
                }
                .transition(reduceMotion ? .opacity : .opacity.combined(with: .scale(scale: 0.985)))
            }
        }
        .preferredColorScheme(.dark)
        .tint(LucchesePalette.white)
        .task {
            await remoteIntegration.restoreSavedSession()
            await remoteIntegration.monitor()
        }
        .onChange(of: remoteIntegration.licensed) { isLicensed in
            guard isLicensed else { return }
            withAnimation(reduceMotion ? nil : .spring(response: 0.36, dampingFraction: 0.86)) {
                selectedTab = .patches
            }
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            Task { await remoteIntegration.refreshSessionNow() }
        }
        .confirmationDialog(
            "Patch marcado como risco",
            isPresented: $showRiskConfirmation,
            titleVisibility: .visible
        ) {
            Button("Continuar e ativar", role: .destructive) {
                guard let patch = patchForRisk else { return }
                Task { await performToggle(patch, enabled: true, riskConfirmed: true) }
            }
            Button("Cancelar", role: .cancel) { patchForRisk = nil }
        } message: {
            Text("O painel marcou este pacote como Risco. Confira o nome e a descrição antes de continuar. O app validará o formato e o SHA-256 antes de aplicar.")
        }
        .alert("Arquivos alterados", isPresented: $showRestoreConfirmation) {
            Button("Cancelar", role: .cancel) { restorePatch = nil }
            Button("Restaurar mesmo assim", role: .destructive) {
                guard let patch = restorePatch else { return }
                Task { await performToggle(patch, enabled: false, allowChangedTargets: true) }
            }
        } message: {
            Text(restoreChangedPaths.prefix(5).joined(separator: "\n") + (restoreChangedPaths.count > 5 ? "\n…" : "") + "\n\nAlguns arquivos mudaram depois da aplicação. Restaurar substituirá essas alterações pelos backups originais.")
        }
        .alert("Não foi possível concluir", isPresented: $showActionError) {
            Button("OK", role: .cancel) { actionError = nil }
        } message: {
            Text(actionError ?? "Tente novamente.")
        }
        .alert("Desvincular dispositivo?", isPresented: $showUnlinkConfirmation) {
            Button("Cancelar", role: .cancel) {}
            Button("Desvincular", role: .destructive) {
                Task { await remoteIntegration.unlink() }
            }
        } message: {
            Text("A key deixará de estar vinculada a este aparelho. Os patches já aplicados permanecerão disponíveis para restauração local.")
        }
        .sheet(isPresented: $showPasswordPrompt, onDismiss: {
            if let patch = passwordPatch { remoteIntegration.discardPendingPackage(for: patch.id) }
            passwordPatch = nil
            passwordValue = ""
        }) {
            if let patch = passwordPatch {
                PatchPasswordSheet(
                    patchName: patch.name,
                    password: $passwordValue,
                    onCancel: { showPasswordPrompt = false },
                    onUnlock: {
                        let value = passwordValue
                        Task {
                            await performToggle(patch, enabled: true, password: value, riskConfirmed: true)
                            if remoteIntegration.isPatchActive(patch.id) {
                                passwordPatch = nil
                                passwordValue = ""
                                showPasswordPrompt = false
                            }
                        }
                    }
                )
                .presentationDetents([.medium])
                .presentationDragIndicator(.visible)
            }
        }
    }

    private var accessGateKind: AccessGateKind? {
        let status = remoteIntegration.globalStatus.lowercased()
        let code = remoteIntegration.licenseErrorCode?.lowercased()
        if status == "banned" || code == "device_banned" { return .banned }
        switch code {
        case "key_expired", "license_expired": return .keyExpired
        case "key_revoked", "license_revoked": return .keyRevoked
        case "key_not_found", "license_not_found", "key_deleted": return .keyMissing
        case "device_limit_reached", "max_devices_reached": return .deviceLimit
        case "hwid_mismatch", "device_mismatch": return .deviceMismatch
        case "license_inactive": return .keyDisabled
        case "invalid_key", "license_invalid": return .invalidKey
        case "maintenance": return .maintenance
        case "offline", "service_offline": return .offline
        case "updating", "update": return .updating
        case "old_version", "old-version": return .oldVersion
        default: break
        }
        if !remoteIntegration.isConfigured { return .configuration }
        if !remoteIntegration.hasServiceResponse { return .connection }
        guard !remoteIntegration.serviceAllowed else { return nil }
        switch status {
        case "maintenance": return .maintenance
        case "offline": return .offline
        case "updating", "update": return .updating
        case "old_version", "old-version": return .oldVersion
        case "banned": return .banned
        default: return .offline
        }
    }

    private var restoringSession: some View {
        VStack(spacing: 22) {
            LuccheseBrandMark(size: 68)
            ProgressView().tint(LucchesePalette.white).scaleEffect(1.05)
            VStack(spacing: 5) {
                Text("Verificando sua licença")
                    .font(.system(size: 19, weight: .semibold, design: .rounded))
                    .foregroundStyle(LucchesePalette.white)
                Text("\(remoteIntegration.storeName) · sessão protegida")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(LucchesePalette.muted)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(28)
    }

    private var authenticatedStore: some View {
        VStack(spacing: 0) {
            storeHeader
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 22) {
                    switch selectedTab {
                    case .patches: patchCatalog
                    case .global: globalFeed
                    case .info: licenseInfo
                    }
                    Text("DESENVOLVIDO POR @lucchese")
                        .font(.system(size: 10, weight: .semibold, design: .rounded))
                        .tracking(2.2)
                        .foregroundStyle(LucchesePalette.muted.opacity(0.8))
                        .frame(maxWidth: .infinity)
                        .padding(.top, 8)
                        .padding(.bottom, 12)
                }
                .padding(.horizontal, 20)
                .padding(.top, 8)
            }
            .refreshable { await remoteIntegration.refreshCatalog(force: true) }
            bottomNavigation
        }
    }

    private var storeHeader: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(spacing: 10) {
                LuccheseBrandMark(size: 40)
                VStack(alignment: .leading, spacing: 2) {
                    Text(remoteIntegration.storeName)
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                        .foregroundStyle(LucchesePalette.white)
                    Text("LOJA DIGITAL")
                        .font(.system(size: 8, weight: .semibold, design: .rounded))
                        .tracking(2.2)
                        .foregroundStyle(LucchesePalette.muted)
                }
                Spacer(minLength: 4)
                HStack(spacing: 6) {
                    Circle().fill(remoteIntegration.serviceAllowed ? LucchesePalette.white : LucchesePalette.muted)
                        .frame(width: 5, height: 5)
                    Text(remoteIntegration.serviceAllowed ? "OK" : "SYNC")
                        .font(.system(size: 8, weight: .bold, design: .monospaced))
                        .tracking(0.8)
                        .foregroundStyle(LucchesePalette.soft)
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 7)
                .background(LucchesePalette.raised, in: Capsule())
                if let discordURL = remoteIntegration.discordURL {
                    Link(destination: discordURL) {
                        DiscordGlyph(size: 18)
                            .frame(width: 36, height: 36)
                            .background(LucchesePalette.surface, in: Circle())
                            .overlay(Circle().stroke(LucchesePalette.line, lineWidth: 1))
                    }
                    .accessibilityLabel("Abrir comunidade no Discord")
                }
            }
            HStack(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 5) {
                    Text(selectedTab.title)
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .tracking(-0.8)
                        .foregroundStyle(LucchesePalette.white)
                    Text(selectedTab == .global
                         ? "Comunicados publicados por \(remoteIntegration.storeName)."
                         : selectedTab.subtitle)
                        .font(.system(size: 13, weight: .regular))
                        .foregroundStyle(LucchesePalette.muted)
                }
                Spacer(minLength: 12)
                Button {
                    Task { await remoteIntegration.refreshSessionNow() }
                } label: {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(LucchesePalette.white)
                        .frame(width: 42, height: 42)
                        .background(LucchesePalette.surface, in: Circle())
                        .overlay(Circle().stroke(LucchesePalette.line, lineWidth: 1))
                }
                .accessibilityLabel("Sincronizar agora")
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 14)
        .padding(.bottom, 18)
    }

    private var patchCatalog: some View {
        VStack(alignment: .leading, spacing: 19) {
            HStack(alignment: .center) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("CATÁLOGO \(remoteIntegration.storeName.uppercased())")
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .tracking(2.2)
                        .foregroundStyle(LucchesePalette.muted)
                    Text("\(remoteIntegration.patchesForDisplay.count) patches")
                        .font(.system(size: 17, weight: .semibold, design: .rounded))
                        .foregroundStyle(LucchesePalette.white)
                }
                Spacer()
                HStack(spacing: 6) {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 12, weight: .semibold))
                    Text("iOS \(remoteIntegration.iosVersion)")
                        .font(.system(size: 10, weight: .semibold, design: .rounded))
                }
                .foregroundStyle(LucchesePalette.soft)
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
                .background(LucchesePalette.surface, in: Capsule())
            }

            if let message = remoteIntegration.gateMessage, !message.isEmpty {
                statusNotice(message, symbol: "exclamationmark.circle")
            }
            if let error = remoteIntegration.errorMessage, !error.isEmpty {
                statusNotice(error, symbol: "arrow.triangle.2.circlepath")
            }

            if remoteIntegration.patchesForDisplay.isEmpty {
                emptyState(
                    symbol: "square.stack.3d.up",
                    title: "Seu catálogo está vazio",
                    message: "Quando um patch for publicado no painel, ele aparecerá aqui, organizado pela categoria escolhida."
                )
            } else {
                ForEach(categoryNames, id: \.self) { category in
                    categorySection(category, patches: sortedPatches.filter { categoryName($0) == category })
                }
            }
        }
    }

    private var globalFeed: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Text("MURAL GLOBAL")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(2.2)
                    .foregroundStyle(LucchesePalette.muted)
                Spacer()
                Text("\(remoteIntegration.announcements.count) avisos")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(LucchesePalette.soft)
            }
            if remoteIntegration.announcements.isEmpty {
                emptyState(
                    symbol: "bell.slash",
                    title: "Nenhum aviso por enquanto",
                    message: "Anúncios publicados no painel aparecerão nesta aba."
                )
            } else {
                ForEach(remoteIntegration.announcements) { item in
                    VStack(alignment: .leading, spacing: 13) {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: "bell.badge.fill")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundStyle(LucchesePalette.white)
                                .frame(width: 36, height: 36)
                                .background(LucchesePalette.raised, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            VStack(alignment: .leading, spacing: 5) {
                                Text(item.title)
                                    .font(.system(size: 16, weight: .semibold, design: .rounded))
                                    .foregroundStyle(LucchesePalette.white)
                                if let createdAt = item.createdAt {
                                    Text(formattedDate(createdAt))
                                        .font(.system(size: 10, weight: .medium, design: .monospaced))
                                        .foregroundStyle(LucchesePalette.muted)
                                }
                            }
                            Spacer(minLength: 0)
                        }
                        Rectangle().fill(LucchesePalette.line).frame(height: 1)
                        Text(item.message)
                            .font(.system(size: 14, weight: .regular))
                            .lineSpacing(4)
                            .foregroundStyle(LucchesePalette.soft)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(17)
                    .background(LucchesePalette.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
                }
            }
        }
    }

    private var licenseInfo: some View {
        VStack(alignment: .leading, spacing: 17) {
            VStack(alignment: .leading, spacing: 4) {
                Text("SESSÃO E DISPOSITIVO")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(2.2)
                    .foregroundStyle(LucchesePalette.muted)
                Text("Tudo em um só lugar")
                    .font(.system(size: 17, weight: .semibold, design: .rounded))
                    .foregroundStyle(LucchesePalette.white)
            }
            VStack(spacing: 0) {
                infoRow(symbol: "storefront.fill", title: "Loja", value: remoteIntegration.storeName)
                infoDivider
                infoRow(symbol: "checkmark.shield.fill", title: "Licença", value: remoteIntegration.licensed ? "Ativa neste aparelho" : "Aguardando validação")
                infoDivider
                infoRow(symbol: "key.fill", title: "Key", value: remoteIntegration.maskedLicenseKey, monospaced: true)
                infoDivider
                infoRow(symbol: "calendar", title: "Expira em", value: formattedDate(remoteIntegration.licenseExpiresAt))
                if let days = remoteIntegration.licensePlanDays {
                    infoDivider
                    infoRow(symbol: "clock", title: "Plano", value: "\(days) dias")
                }
                if let maxDevices = remoteIntegration.licenseMaxDevices {
                    infoDivider
                    infoRow(symbol: "iphone.gen3", title: "Limite de aparelhos", value: "\(maxDevices) \(maxDevices == 1 ? "aparelho" : "aparelhos")")
                }
                infoDivider
                infoRow(symbol: "iphone", title: "Modelo", value: remoteIntegration.deviceModelName)
                infoDivider
                infoRow(symbol: "gearshape", title: "Versão do iOS", value: remoteIntegration.iosVersion)
                infoDivider
                infoRow(symbol: "number", title: "ID do aparelho", value: "••••\(remoteIntegration.deviceIdentifierSuffix)", monospaced: true)
                infoDivider
                infoRow(symbol: "arrow.triangle.2.circlepath", title: "Última verificação", value: formattedDate(remoteIntegration.lastVerifiedAt))
            }
            .padding(.horizontal, 16)
            .background(LucchesePalette.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))

            if let discordURL = remoteIntegration.discordURL {
                Link(destination: discordURL) {
                    HStack(spacing: 12) {
                        DiscordGlyph(size: 20)
                            .frame(width: 40, height: 40)
                            .background(LucchesePalette.raised, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Comunidade no Discord")
                                .font(.system(size: 13, weight: .semibold, design: .rounded))
                                .foregroundStyle(LucchesePalette.white)
                            Text("Suporte e novidades da loja")
                                .font(.system(size: 10, weight: .medium))
                                .foregroundStyle(LucchesePalette.muted)
                        }
                        Spacer()
                        Image(systemName: "arrow.up.right")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(LucchesePalette.muted)
                    }
                    .padding(13)
                    .background(LucchesePalette.surface, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 17, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
                }
            }

            Button {
                showUnlinkConfirmation = true
            } label: {
                HStack(spacing: 9) {
                    Image(systemName: "rectangle.portrait.and.arrow.right")
                    Text("Desvincular dispositivo")
                    Spacer()
                    Image(systemName: "arrow.up.right")
                        .font(.system(size: 10, weight: .semibold))
                }
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(LucchesePalette.soft)
                .padding(.horizontal, 16)
                .padding(.vertical, 15)
                .background(LucchesePalette.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
            }
            .disabled(remoteIntegration.isLoading)
        }
    }

    private var bottomNavigation: some View {
        HStack(spacing: 4) {
            ForEach(StoreTab.allCases) { tab in
                Button {
                    withAnimation(reduceMotion ? nil : .spring(response: 0.34, dampingFraction: 0.82)) {
                        selectedTab = tab
                    }
                } label: {
                    VStack(spacing: 6) {
                        Image(systemName: tab.icon)
                            .font(.system(size: 18, weight: .semibold))
                            .frame(height: 20)
                        Text(tab.title)
                            .font(.system(size: 10, weight: .semibold, design: .rounded))
                    }
                    .foregroundStyle(selectedTab == tab ? LucchesePalette.background : LucchesePalette.muted)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 11)
                    .background {
                        if selectedTab == tab {
                            Capsule().fill(LucchesePalette.white)
                        }
                    }
                    .contentShape(Capsule())
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(selectedTab == tab ? .isSelected : [])
            }
        }
        .padding(6)
        .background(LucchesePalette.surface, in: Capsule())
        .overlay(Capsule().stroke(LucchesePalette.line, lineWidth: 1))
        .padding(.horizontal, 20)
        .padding(.top, 9)
        .padding(.bottom, 8)
        .background(LucchesePalette.background.opacity(0.96))
    }

    private var sortedPatches: [RemotePatch] {
        remoteIntegration.patchesForDisplay.sorted {
            let left = categoryName($0)
            let right = categoryName($1)
            if left != right { return left.localizedStandardCompare(right) == .orderedAscending }
            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }

    private var categoryNames: [String] {
        Array(Set(sortedPatches.map(categoryName))).sorted()
    }

    private func categoryName(_ patch: RemotePatch) -> String {
        guard let value = patch.category?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty else {
            return "Geral"
        }
        return value
    }

    private func categorySection(_ title: String, patches: [RemotePatch]) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                Text(title.uppercased())
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(LucchesePalette.muted)
                Spacer()
                Text(String(format: "%02d", patches.count))
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundStyle(LucchesePalette.muted.opacity(0.8))
            }
            ForEach(patches) { patch in patchCard(patch) }
        }
    }

    private func patchCard(_ patch: RemotePatch) -> some View {
        let isActive = remoteIntegration.isPatchActive(patch.id)
        let isAvailable = patch.status.lowercased() == "ativo"
        let isBusy = remoteIntegration.isPatchBusy(patch.id)
        return HStack(alignment: .center, spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(LucchesePalette.raised)
                    .frame(width: 46, height: 46)
                Image(systemName: "square.stack.3d.up.fill")
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(LucchesePalette.white)
            }
            VStack(alignment: .leading, spacing: 7) {
                Text(patch.name)
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                    .foregroundStyle(LucchesePalette.white)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 6) {
                    patchBadge(title: statusTitle(for: patch, isActive: isActive), emphasized: isActive || isAvailable)
                    patchBadge(title: patch.risk ? "RISCO" : "SEGURO", emphasized: patch.risk)
                    if let version = patch.version, !version.isEmpty {
                        patchBadge(title: "v\(version)", emphasized: false)
                    }
                }
                if let description = patch.description, !description.isEmpty {
                    Text(description)
                        .font(.system(size: 11, weight: .regular))
                        .lineSpacing(2)
                        .foregroundStyle(LucchesePalette.muted)
                        .lineLimit(2)
                }
            }
            Spacer(minLength: 2)
            VStack(spacing: 5) {
                if isBusy {
                    ProgressView().tint(LucchesePalette.white).frame(width: 44, height: 31)
                } else {
                    Toggle(
                        "",
                        isOn: Binding(
                            get: { remoteIntegration.isPatchActive(patch.id) },
                            set: { requestToggle(patch, enabled: $0) }
                        )
                    )
                    .labelsHidden()
                    .toggleStyle(SwitchToggleStyle(tint: LucchesePalette.white))
                    .scaleEffect(0.88, anchor: .trailing)
                    .accessibilityLabel(isActive ? "Desativar e restaurar \(patch.name)" : "Ativar \(patch.name)")
                    .accessibilityHint(patch.risk ? "Marcado como risco; será solicitada confirmação." : "Aplica ou restaura o pacote nativo.")
                    .disabled((!isActive && !isAvailable) || (!isActive && !remoteIntegration.licensed))
                }
                Text(isActive ? "LIGADO" : "")
                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                    .tracking(1.2)
                    .foregroundStyle(LucchesePalette.muted)
                    .frame(height: 10)
            }
            .frame(width: 48)
        }
        .padding(14)
        .background(LucchesePalette.surface, in: RoundedRectangle(cornerRadius: 19, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 19, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
        .opacity((!isAvailable && !isActive) ? 0.64 : 1)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: isActive)
    }

    private func patchBadge(title: String, emphasized: Bool) -> some View {
        Text(title)
            .font(.system(size: 8, weight: .bold, design: .rounded))
            .tracking(0.45)
            .foregroundStyle(emphasized ? LucchesePalette.white : LucchesePalette.soft)
            .padding(.horizontal, 7)
            .padding(.vertical, 5)
            .background(emphasized ? LucchesePalette.raised : LucchesePalette.raised.opacity(0.58), in: Capsule())
    }

    private func statusTitle(for patch: RemotePatch, isActive: Bool) -> String {
        if isActive { return "ATIVO" }
        switch patch.status.lowercased() {
        case "ativo": return "DISPONÍVEL"
        case "atualizando": return "ATUALIZANDO"
        default: return "DESLIGADO"
        }
    }

    private func requestToggle(_ patch: RemotePatch, enabled: Bool) {
        if enabled && patch.risk {
            patchForRisk = patch
            showRiskConfirmation = true
            return
        }
        Task { await performToggle(patch, enabled: enabled) }
    }

    private func performToggle(
        _ patch: RemotePatch,
        enabled: Bool,
        password: String? = nil,
        riskConfirmed: Bool = false,
        allowChangedTargets: Bool = false
    ) async {
        let result = await remoteIntegration.setPatchEnabled(
            patch,
            enabled: enabled,
            password: password,
            riskConfirmed: riskConfirmed,
            allowChangedTargets: allowChangedTargets
        )
        switch result {
        case .completed:
            patchForRisk = nil
            restorePatch = nil
        case .requiresRiskConfirmation:
            patchForRisk = patch
            showRiskConfirmation = true
        case .requiresPassword:
            passwordPatch = patch
            passwordValue = ""
            showPasswordPrompt = true
        case .restoreNeedsConfirmation(let paths):
            restorePatch = patch
            restoreChangedPaths = paths
            showRestoreConfirmation = true
        case .failed(let message):
            actionError = message
            showActionError = true
        }
    }

    private func infoRow(symbol: String, title: String, value: String, monospaced: Bool = false) -> some View {
        HStack(alignment: .center, spacing: 11) {
            Image(systemName: symbol)
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(LucchesePalette.soft)
                .frame(width: 18)
            Text(title)
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(LucchesePalette.muted)
            Spacer(minLength: 6)
            Text(value)
                .font(monospaced ? .system(size: 11, weight: .medium, design: .monospaced) : .system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(LucchesePalette.white)
                .multilineTextAlignment(.trailing)
                .lineLimit(2)
        }
        .padding(.vertical, 14)
    }

    private var infoDivider: some View {
        Rectangle().fill(LucchesePalette.line).frame(height: 1)
    }

    private func statusNotice(_ message: String, symbol: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: symbol).font(.system(size: 13, weight: .semibold)).foregroundStyle(LucchesePalette.white)
            Text(message).font(.system(size: 12, weight: .medium)).foregroundStyle(LucchesePalette.soft).fixedSize(horizontal: false, vertical: true)
        }
        .padding(13)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LucchesePalette.raised, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
    }

    private func emptyState(symbol: String, title: String, message: String) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 21, weight: .medium))
                .foregroundStyle(LucchesePalette.soft)
            Text(title)
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(LucchesePalette.white)
            Text(message)
                .font(.system(size: 12, weight: .regular))
                .lineSpacing(3)
                .foregroundStyle(LucchesePalette.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background(LucchesePalette.surface, in: RoundedRectangle(cornerRadius: 19, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 19, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
    }

    private func formattedDate(_ raw: String?) -> String {
        guard let raw, !raw.isEmpty else { return "Não informada" }
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let date = fractional.date(from: raw) ?? ISO8601DateFormatter().date(from: raw)
        guard let date else { return raw }
        return DateFormatter.localizedString(from: date, dateStyle: .medium, timeStyle: .short)
    }

    private func formattedDate(_ date: Date?) -> String {
        guard let date else { return "Aguardando" }
        return DateFormatter.localizedString(from: date, dateStyle: .none, timeStyle: .short)
    }
}


private enum AccessGateKind {
    case configuration, connection, maintenance, offline, updating, oldVersion, banned
    case keyMissing, keyRevoked, keyExpired, keyDisabled, invalidKey, deviceLimit, deviceMismatch

    var symbol: String {
        switch self {
        case .configuration: return "gearshape.2.fill"
        case .connection: return "wifi.slash"
        case .maintenance: return "wrench.and.screwdriver.fill"
        case .offline: return "power"
        case .updating: return "arrow.triangle.2.circlepath"
        case .oldVersion: return "arrow.down.app.fill"
        case .banned: return "iphone.slash"
        case .keyMissing: return "key.slash.fill"
        case .keyRevoked: return "xmark.shield.fill"
        case .keyExpired: return "calendar.badge.exclamationmark"
        case .keyDisabled: return "pause.circle.fill"
        case .invalidKey: return "key.fill"
        case .deviceLimit: return "iphone.gen3.radiowaves.left.and.right"
        case .deviceMismatch: return "iphone.and.arrow.forward"
        }
    }

    var title: String {
        switch self {
        case .configuration: return "Serviço não configurado"
        case .connection: return "Sem conexão com a loja"
        case .maintenance: return "Estamos em manutenção"
        case .offline: return "Serviço temporariamente desligado"
        case .updating: return "Loja em atualização"
        case .oldVersion: return "Atualize o aplicativo"
        case .banned: return "Dispositivo bloqueado"
        case .keyMissing: return "Key não encontrada"
        case .keyRevoked: return "Acesso revogado"
        case .keyExpired: return "Key expirada"
        case .keyDisabled: return "Key desativada"
        case .invalidKey: return "Não foi possível validar a key"
        case .deviceLimit: return "Limite de aparelhos atingido"
        case .deviceMismatch: return "Key vinculada a outro aparelho"
        }
    }

    var requiresNewKey: Bool {
        switch self {
        case .keyMissing, .keyRevoked, .keyExpired, .keyDisabled, .invalidKey, .deviceLimit, .deviceMismatch: return true
        default: return false
        }
    }

    @MainActor
    func message(service: RemoteIntegration) -> String {
        switch self {
        case .configuration:
            return service.gateMessage ?? "Esta versão ainda não está conectada à origem da API."
        case .connection:
            return service.errorMessage ?? "Verifique sua conexão e tente novamente."
        case .maintenance:
            return service.gateMessage ?? "A equipe está realizando uma manutenção. Tente novamente mais tarde."
        case .offline:
            return service.gateMessage ?? "O acesso à loja está temporariamente pausado."
        case .updating:
            return service.gateMessage ?? "Estamos atualizando o serviço. Tente novamente em alguns minutos."
        case .oldVersion:
            return service.gateMessage ?? "Instale a versão mais recente para continuar."
        case .banned:
            return service.gateMessage ?? "Este aparelho foi bloqueado pelo administrador. Entre em contato com o suporte."
        case .keyMissing:
            return "Esta key não existe ou foi excluída. Confira o código ou solicite uma nova key ao administrador."
        case .keyRevoked:
            return "O acesso desta key foi revogado. Solicite uma nova licença ao administrador da loja."
        case .keyExpired:
            return "O período desta key terminou. Solicite uma nova licença para continuar."
        case .keyDisabled:
            return "O administrador desativou esta licença. Entre em contato com a loja para confirmar o acesso."
        case .invalidKey:
            return service.errorMessage ?? "Confira todos os caracteres da key e tente novamente."
        case .deviceLimit:
            return "Esta key já alcançou o limite de aparelhos permitido. Peça ao administrador para liberar um vínculo ou use outra key."
        case .deviceMismatch:
            return "Esta key está vinculada a outro aparelho. Fale com o administrador para revisar o vínculo."
        }
    }
}

private struct AccessStatusView: View {
    let state: AccessGateKind
    @ObservedObject var service: RemoteIntegration
    let onRetry: () -> Void

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 24) {
                HStack(spacing: 13) {
                    LuccheseBrandMark(size: 52)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(service.storeName)
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)
                            .foregroundStyle(LucchesePalette.white)
                        Text("STATUS DO ACESSO")
                            .font(.system(size: 9, weight: .semibold, design: .rounded))
                            .tracking(2.2)
                            .foregroundStyle(LucchesePalette.muted)
                    }
                }
                .padding(.top, 34)

                VStack(alignment: .leading, spacing: 18) {
                    Image(systemName: state.symbol)
                        .font(.system(size: 24, weight: .medium))
                        .foregroundStyle(LucchesePalette.white)
                        .frame(width: 58, height: 58)
                        .background(LucchesePalette.raised, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    VStack(alignment: .leading, spacing: 9) {
                        Text(state.title)
                            .font(.system(size: 27, weight: .bold, design: .rounded))
                            .tracking(-0.7)
                            .foregroundStyle(LucchesePalette.white)
                        Text(state.message(service: service))
                            .font(.system(size: 14, weight: .regular))
                            .lineSpacing(4)
                            .foregroundStyle(LucchesePalette.muted)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    if !service.maskedLicenseKey.isEmpty && service.maskedLicenseKey != "—" {
                        Text(service.maskedLicenseKey)
                            .font(.system(size: 11, weight: .medium, design: .monospaced))
                            .foregroundStyle(LucchesePalette.soft)
                            .padding(.horizontal, 11)
                            .padding(.vertical, 8)
                            .background(LucchesePalette.raised, in: Capsule())
                    }
                }
                .padding(20)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(LucchesePalette.surface, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))

                if state.requiresNewKey {
                    Button {
                        service.prepareForKeyEntry()
                    } label: {
                        HStack(spacing: 9) {
                            Text("Inserir outra key")
                            Image(systemName: "arrow.right")
                                .font(.system(size: 12, weight: .semibold))
                        }
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .foregroundStyle(LucchesePalette.background)
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(LucchesePalette.white, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                } else {
                    Button(action: onRetry) {
                        HStack(spacing: 9) {
                            if service.isLoading { ProgressView().tint(LucchesePalette.background) }
                            Text("Tentar novamente")
                            Image(systemName: "arrow.clockwise")
                                .font(.system(size: 12, weight: .semibold))
                        }
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .foregroundStyle(LucchesePalette.background)
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(LucchesePalette.white, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                    .disabled(service.isLoading)
                }

                if let discordURL = service.discordURL {
                    Link(destination: discordURL) {
                        HStack(spacing: 10) {
                            DiscordGlyph(size: 18)
                            Text("Falar com o suporte no Discord")
                                .font(.system(size: 12, weight: .semibold, design: .rounded))
                        }
                        .foregroundStyle(LucchesePalette.soft)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(LucchesePalette.surface, in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
                    }
                }

                Text("Desenvolvido por @lucchese")
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(LucchesePalette.muted.opacity(0.8))
                    .frame(maxWidth: .infinity)
                    .padding(.top, 2)
                    .padding(.bottom, 24)
            }
            .padding(.horizontal, 23)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .scrollDismissesKeyboard(.interactively)
    }
}

private struct DiscordGlyph: View {
    let size: CGFloat

    var body: some View {
        ZStack {
            DiscordControllerShape().fill(LucchesePalette.white)
            HStack(spacing: size * 0.16) {
                Circle().fill(LucchesePalette.background)
                    .frame(width: size * 0.105, height: size * 0.105)
                Circle().fill(LucchesePalette.background)
                    .frame(width: size * 0.105, height: size * 0.105)
            }
            .offset(y: size * 0.07)
        }
        .frame(width: size, height: size * 0.82)
        .accessibilityHidden(true)
    }
}

private struct DiscordControllerShape: Shape {
    func path(in rect: CGRect) -> Path {
        let w = rect.width
        let h = rect.height
        var path = Path()
        path.move(to: CGPoint(x: w * 0.27, y: h * 0.15))
        path.addQuadCurve(to: CGPoint(x: w * 0.73, y: h * 0.15), control: CGPoint(x: w * 0.50, y: -h * 0.04))
        path.addQuadCurve(to: CGPoint(x: w * 0.87, y: h * 0.71), control: CGPoint(x: w * 0.83, y: h * 0.30))
        path.addQuadCurve(to: CGPoint(x: w * 0.64, y: h * 0.84), control: CGPoint(x: w * 0.78, y: h * 0.91))
        path.addLine(to: CGPoint(x: w * 0.58, y: h * 0.70))
        path.addQuadCurve(to: CGPoint(x: w * 0.42, y: h * 0.70), control: CGPoint(x: w * 0.50, y: h * 0.75))
        path.addLine(to: CGPoint(x: w * 0.36, y: h * 0.84))
        path.addQuadCurve(to: CGPoint(x: w * 0.13, y: h * 0.71), control: CGPoint(x: w * 0.22, y: h * 0.91))
        path.addQuadCurve(to: CGPoint(x: w * 0.27, y: h * 0.15), control: CGPoint(x: w * 0.17, y: h * 0.30))
        path.closeSubpath()
        return path
    }
}

private struct LuccheseKeyEntryView: View {
    @ObservedObject var service: RemoteIntegration
    let onRestore: (RemotePatch) -> Void

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 25) {
                HStack(spacing: 13) {
                    LuccheseBrandMark(size: 54)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(service.storeName)
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .lineLimit(1)
                            .minimumScaleFactor(0.72)
                            .foregroundStyle(LucchesePalette.white)
                        Text("ACESSO PRIVADO")
                            .font(.system(size: 9, weight: .semibold, design: .rounded))
                            .tracking(2.5)
                            .foregroundStyle(LucchesePalette.muted)
                    }
                }
                .padding(.top, 34)

                VStack(alignment: .leading, spacing: 8) {
                    Text("Acesse sua loja")
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                        .tracking(-1.1)
                        .foregroundStyle(LucchesePalette.white)
                    Text("Use a chave fornecida pelo administrador para vincular este aparelho.")
                        .font(.system(size: 13, weight: .regular))
                        .lineSpacing(4)
                        .foregroundStyle(LucchesePalette.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(.top, 14)

                VStack(alignment: .leading, spacing: 10) {
                    Text("CHAVE DE ACESSO")
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .tracking(2)
                        .foregroundStyle(LucchesePalette.muted)
                    HStack(spacing: 11) {
                        Image(systemName: "key.horizontal.fill")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(LucchesePalette.soft)
                        TextField("Cole ou digite sua key", text: $service.licenseKey)
                            .font(.system(size: 13, weight: .medium, design: .monospaced))
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .keyboardType(.asciiCapable)
                            .submitLabel(.go)
                            .onSubmit { Task { await service.activateOrValidate(key: service.licenseKey) } }
                            .foregroundStyle(LucchesePalette.white)
                    }
                    .padding(.horizontal, 15)
                    .frame(height: 57)
                    .background(LucchesePalette.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))

                    if let message = service.errorMessage ?? service.gateMessage, !message.isEmpty {
                        HStack(alignment: .top, spacing: 8) {
                            Image(systemName: "exclamationmark.circle.fill")
                                .font(.system(size: 12))
                            Text(message)
                                .font(.system(size: 12, weight: .medium))
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .foregroundStyle(LucchesePalette.soft)
                        .padding(.top, 4)
                    }

                    if !service.isConfigured {
                        Text("O serviço ainda não está configurado para esta versão do app. Entre em contato com o suporte.")
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(LucchesePalette.muted)
                            .padding(.top, 5)
                    }
                }
                .padding(17)
                .background(LucchesePalette.surface.opacity(0.72), in: RoundedRectangle(cornerRadius: 21, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 21, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))

                Button {
                    Task { await service.activateOrValidate(key: service.licenseKey) }
                } label: {
                    HStack(spacing: 9) {
                        if service.isLoading {
                            ProgressView().tint(LucchesePalette.background)
                        } else {
                            Text("Validar e continuar")
                            Image(systemName: "arrow.right")
                                .font(.system(size: 13, weight: .semibold))
                        }
                    }
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(LucchesePalette.background)
                    .frame(maxWidth: .infinity)
                    .frame(height: 54)
                    .background(LucchesePalette.white, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .disabled(service.isLoading || !service.isConfigured || service.licenseKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                .opacity(service.isLoading || !service.isConfigured ? 0.65 : 1)

                if !service.recoveryPatches.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 8) {
                            Image(systemName: "arrow.uturn.backward.circle.fill")
                            Text("RESTAURAÇÃO LOCAL")
                                .tracking(1.8)
                        }
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .foregroundStyle(LucchesePalette.soft)
                        Text("A licença não está ativa. Você ainda pode desligar um patch aplicado para restaurar os arquivos originais.")
                            .font(.system(size: 11, weight: .regular))
                            .lineSpacing(3)
                            .foregroundStyle(LucchesePalette.muted)
                        ForEach(service.recoveryPatches) { patch in
                            HStack(spacing: 10) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(patch.name).font(.system(size: 12, weight: .semibold)).foregroundStyle(LucchesePalette.white)
                                    Text("Aplicado neste aparelho").font(.system(size: 10, weight: .medium)).foregroundStyle(LucchesePalette.muted)
                                }
                                Spacer()
                                Toggle(
                                    "",
                                    isOn: Binding(
                                        get: { service.isPatchActive(patch.id) },
                                        set: { if !$0 { onRestore(patch) } }
                                    )
                                )
                                .labelsHidden()
                                .toggleStyle(SwitchToggleStyle(tint: LucchesePalette.white))
                                .disabled(service.isPatchBusy(patch.id))
                            }
                            .padding(.vertical, 8)
                        }
                    }
                    .padding(16)
                    .background(LucchesePalette.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(LucchesePalette.line, lineWidth: 1))
                }

                Text("Desenvolvido por @lucchese")
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(LucchesePalette.muted.opacity(0.8))
                    .frame(maxWidth: .infinity)
                    .padding(.top, 4)
                    .padding(.bottom, 24)
            }
            .padding(.horizontal, 23)
        }
        .scrollDismissesKeyboard(.interactively)
    }
}

private struct LuccheseBrandMark: View {
    var size: CGFloat

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.32, style: .continuous)
                .fill(LucchesePalette.raised)
            RoundedRectangle(cornerRadius: size * 0.32, style: .continuous)
                .stroke(LucchesePalette.line, lineWidth: 1)
            Image(systemName: "person.fill")
                .font(.system(size: size * 0.39, weight: .medium))
                .foregroundStyle(LucchesePalette.white)
        }
        .frame(width: size, height: size)
        .accessibilityLabel("Perfil da licença")
    }
}

private struct PatchPasswordSheet: View {
    let patchName: String
    @Binding var password: String
    let onCancel: () -> Void
    let onUnlock: () -> Void
    @FocusState private var focused: Bool

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 18) {
                Text("Este pacote está protegido por senha.")
                    .font(.system(size: 16, weight: .semibold, design: .rounded))
                    .foregroundStyle(LucchesePalette.white)
                Text(patchName)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(LucchesePalette.muted)
                SecureField("Senha do pacote", text: $password)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .focused($focused)
                    .padding(14)
                    .background(LucchesePalette.raised, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                Button(action: onUnlock) {
                    Text("Desbloquear e continuar")
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .foregroundStyle(LucchesePalette.background)
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(LucchesePalette.white, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .disabled(password.isEmpty)
                Spacer(minLength: 0)
            }
            .padding(20)
            .background(LucchesePalette.background.ignoresSafeArea())
            .navigationTitle("Desbloquear pacote")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar", action: onCancel).foregroundStyle(LucchesePalette.soft)
                }
            }
            .onAppear { DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { focused = true } }
        }
        .preferredColorScheme(.dark)
    }
}
