

## Incremento: confirmação, feedback e validade em tempo real

- O app não exibe mais o alerta automático de “atualização disponível” da própria aplicação.
- A aba Info substitui a indicação aproximada de dias por uma contagem regressiva `dias HH:MM:SS` (ou `HH:MM:SS`) baseada no `expiresAt` da licença e atualizada a cada segundo; keys personalizadas deixam de aparecer incorretamente como “1 dia”.
- Tanto injetar quanto desinjetar pede confirmação explícita. Durante a operação, o controle mostra “INJETANDO” ou “DESINJETANDO” com progresso e transição; os badges de status do catálogo distinguem Disponível (verde), Atualizando (laranja), Desativado (vermelho), Seguro e Risco.
- O switch usa trilho verde quando ligado e layout estável/alinhado. O fundo do app ganha movimento sutil e respeita a configuração de Acessibilidade “Reduzir Movimento”.
- Para reduzir a espera, o download do pacote pode ocorrer em paralelo com a validação remota obrigatória. O app ainda confere licença, estado mais recente do catálogo e SHA-256 antes de aplicar; desativação continua usando o journal local.
