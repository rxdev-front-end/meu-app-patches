# Integração remota do cliente 3106 — Lucchese Store

## Configuração

A origem HTTPS da API unificada publicada é `https://lucchese-h5sphw9z.manus.space`. O projeto Xcode já define `LUCCHESE_API_BASE_URL` com essa origem nas configurações Debug e Release; não acrescente barra final, caminho `/api` ou credenciais. Se o domínio mudar, atualize o build setting do target. A tela inicial é a interface de key; com uma key salva e ainda válida, o app revalida automaticamente e abre as abas do Lucchese Store. Não existe `x-api-key` nem segredo estático no cliente.

O identificador do dispositivo é um UUID aleatório criado pelo app e persistido localmente; não é UDID nem identificador físico. O cliente informa apenas modelo do aparelho, versão do iOS, versão do app e build no bootstrap. A key de licença é armazenada no Keychain; HWID e key nunca são colocados em query string.

## Contrato implementado

- `POST /api/app/bootstrap` recebe `hwid`, `deviceModel`, `iosVersion`, `appVersion` e `buildNumber`; devolve modo global, mensagem e estado do dispositivo.
- `POST /api/license/activate` recebe `key` e `hwid` no JSON para primeiro vínculo; `POST /api/license/validate` revalida o vínculo salvo.
- `GET /api/license/status` recebe `X-License-Key` e `X-Device-ID` nos headers TLS.
- `POST /api/license/unlink-hwid` solicita desvinculação com `key` e `hwid` no JSON.
- `GET /api/mobile/catalog`, `GET /api/mobile/announcements` e `GET /api/mobile/patches/:id/file` também exigem `X-License-Key` e `X-Device-ID`.

Sucesso de licença: `{ "ok": true, "license": { "status": "active", "planDays": 7, "expiresAt": "ISO-8601 ou null" } }`. Erro móvel: `{ "ok": false, "code": "...", "message": "..." }`. Estados globais `normal`/`active` permitem prosseguir; `maintenance`, `offline`, `updating`, `old_version` e dispositivo banido bloqueiam o acesso com mensagem. Os endpoints de conteúdo também validam serviço ativo e versão/build mínimos, não apenas a UI.

O catálogo retorna `categories` e `patches`, incluindo `id`, `name`, `categoryId`, `note`, `status`, `risk`, `version`, URL do arquivo e `sha256`. Avisos publicados são retornados em `announcements`.

## Experiência no app e sincronização

A interface própria em preto, grafite, cinza e branco apresenta uma tela de key e, após validação, navegação inferior com **Patches**, **Global** e **Info**. A key fica no Keychain. Ao iniciar ou voltar ao primeiro plano, o app verifica licença/dispositivo; enquanto está ativo, sincroniza status, catálogo e avisos a cada 15 segundos. Revogação, expiração, bloqueio de dispositivo ou status global não permitido fecha as telas autenticadas. Se houver patches locais aplicados, a tela de key mantém os toggles de restauração acessíveis.

A aba **Patches** agrupa os itens pelas categorias configuradas no painel. Status `atualizando` ou `desativado` impede ligar um patch; um patch já aplicado continua podendo ser desligado. A marcação **Risco** exige confirmação antes da ativação. **Global** lista os anúncios publicados. **Info** mostra key mascarada, licença/expiração, versão do iOS e modelo do aparelho.

## Ativação, validação e restauração de patches

O toggle é a única ação que inicia uma aplicação; não há botão separado de aplicar. Ao ligar, o app baixa o `.3106`, confere o SHA-256 retornado pelo catálogo, inspeciona e valida o envelope por `PatchPackageCodec` e solicita senha localmente quando o pacote é protegido. Só então o `DevicePatchService` usa `PatchTransaction` para aplicar os alvos permitidos e registrar journal/backups. A API apenas distribui bytes e metadados; não executa scripts ou comandos no iPhone.

Ao desligar, o app restaura pelo journal local. Se os arquivos-alvo mudaram depois da aplicação, informa os caminhos e exige confirmação antes de substituir essas alterações pelos backups originais. Metadados mínimos do patch aplicado ficam no aparelho para permitir desligar/restaurar mesmo após revogação da key ou retirada do item do catálogo. Senha de pacote não é enviada nem salva pelo servidor.

A integração não substitui motores, importador, sandbox, mecanismos de patch ou demais sistemas próprios do 3106 pelos do 3105. `LICENSE` e `NOTICE.md` da fonte original são preservados.

## Build

Abra `ThreeOneOSSix.xcodeproj` e compile/assine no Xcode; Debug e Release já apontam para a origem publicada acima. O identificador de bundle e o versionamento da fonte original foram preservados; o nome exibido é “Lucchese Store” e a assinatura visual é “@lucchese”. Este pacote contém código-fonte, não uma IPA assinada. O ambiente de preparação Linux não possui `xcodebuild`.


## Incremento: estados de acesso, identidade e aparelhos

- A tela inicial usa placeholder neutro `Cole ou digite sua key`, sem prefixo fixo e sem o slogan antigo. Quando já não há sessão válida, o cliente apresenta mensagens e telas dedicadas para key removida/inexistente, revogada ou expirada; limite de aparelhos ou vínculo incompatível; dispositivo banido; manutenção, serviço offline/desligado, atualização, versão antiga e falha de conexão. O botão para trocar key só aparece para erros de licença; os demais oferecem nova tentativa e, se configurado, o Discord.
- O bootstrap envia o nome da loja e o link do Discord para a sessão do app. O nome é atualizado dentro da experiência do cliente; o cabeçalho usa um símbolo genérico de perfil, sem o monograma LC. Um botão com ícone estilizado de Discord abre o convite configurado pelo owner.
- A resposta da licença inclui `maxDevices`; a aba Info apresenta o limite e o servidor impõe esse limite por key na ativação. O painel escolhe de 1 a 10 aparelhos (padrão 1).
- As keys completas continuam sendo exibidas somente no resultado de emissão, com botões de copiar uma key ou o lote. Keys preexistentes não podem ser recuperadas porque só o hash é persistido.
- A validade é própria de cada key e começa na primeira ativação. A cobertura Vitest reproduz a sequência de ativar uma key de 10 segundos, aguardar sua expiração e ativar outra de 1 dia; essa segunda expiração não herda estado da primeira.
