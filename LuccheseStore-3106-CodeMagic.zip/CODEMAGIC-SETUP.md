# CodeMagic — projeto Lucchese Store 3106

O log anterior falhou porque o repositório tinha apenas `LuccheseStore-3106-CodeMagic.zip` e `codemagic.yaml`; o CodeMagic não procura projetos dentro de arquivos ZIP automaticamente.

O YAML agora faz isso. O ID executável é `ios-workflow` (nome mostrado: “Lucchese Store 3106 - unsigned IPA”). Primeiro procura `ThreeOneOSSix.xcodeproj` no repositório. Se não encontrar, procura `LuccheseStore-3106-CodeMagic.zip`, valida e extrai para `.codemagic-ios-source`, depois verifica o scheme compartilhado `3106` e arquiva o app.

## Layout esperado do repositório

Para o layout que você descreveu, deixe estes dois arquivos na raiz do repositório:

```text
codemagic.yaml
LuccheseStore-3106-CodeMagic.zip
```

Faça commit e push dos dois para a mesma branch que o CodeMagic compila. O ZIP deve manter exatamente esse nome. A raiz do repositório também pode conter o projeto já extraído; o YAML detecta ambos os formatos. O CodeMagic exige que `codemagic.yaml` esteja na raiz do repositório: https://docs.codemagic.io/yaml-basic-configuration/yaml-getting-started/.

O pacote extraído usa `ThreeOneOSSix.xcodeproj`, scheme `3106`, e a API já configurada em Debug e Release como `https://lucchese-h5sphw9z.manus.space`.

## Diagnóstico se falhar

Se o ZIP não estiver no clone, o passo imprime os arquivos `.zip` encontrados. Se não contiver `ThreeOneOSSix.xcodeproj`, o log diz isso explicitamente. Se o projeto for encontrado, o passo imprime o caminho e lista os schemes; se a verificação do scheme falhar, confira se `ThreeOneOSSix.xcodeproj/xcshareddata/xcschemes/3106.xcscheme` está dentro do ZIP.

## Assinatura

O workflow segue o modo unsigned do log (`CODE_SIGNING_ALLOWED=NO`). Ele empacota `LuccheseStore-unsigned.ipa`, mas não é assinado e não está pronto para instalar em iPhone nem para TestFlight. Para isso, configure certificado e provisioning profile válidos para `com.qingtang.3106` e use um workflow assinado. Se o identificador não pertence à sua equipe Apple, escolha um identificador seu e crie o perfil correspondente. Consulte o [guia oficial CodeMagic de assinatura iOS](https://docs.codemagic.io/yaml-code-signing/signing-ios/).

A sintaxe YAML e os scripts shell foram validados. Não foi possível compilar o app com Xcode neste ambiente Linux.
