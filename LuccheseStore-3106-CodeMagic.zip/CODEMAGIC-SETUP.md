# CodeMagic — projeto Lucchese Store 3106

O log anterior tentou compilar `ThreeOneOSFive.xcodeproj` com scheme `3105`, mas a fonte entregue é o projeto `ThreeOneOSSix.xcodeproj`, com scheme compartilhado `3106`.

## Importação e configuração

Use o ZIP iOS isolado. Ele contém o projeto e `codemagic.yaml`. O YAML precisa ser commitado na raiz do repositório para o CodeMagic detectá-lo: https://docs.codemagic.io/yaml-basic-configuration/yaml-getting-started/.

O ID executável do workflow é `ios-workflow` (nome exibido: “Lucchese Store 3106 - unsigned IPA”). O script procura `ThreeOneOSSix.xcodeproj` até oito níveis abaixo da raiz, imprime o caminho escolhido e tenta resolver o scheme `3106` antes de arquivar. Assim, o projeto pode estar dentro de uma pasta extraída sem precisar ajustar o caminho.

A API já está configurada nos build settings Debug e Release como `https://lucchese-h5sphw9z.manus.space`.

## Se a verificação falhar novamente

O passo imprime o caminho do repositório e os `.xcodeproj` encontrados. Se imprimir `ThreeOneOSSix.xcodeproj not found`, os arquivos do app não estão no repositório/branch que o build está usando. Se encontrar o projeto mas `xcodebuild -showBuildSettings` falhar, confira se o scheme compartilhado `ThreeOneOSSix.xcodeproj/xcshareddata/xcschemes/3106.xcscheme` foi commitado. Nesse caso, o trecho útil do log é a mensagem imediatamente acima de `exited with status code 1`.

## Limite de assinatura

O workflow segue o modo unsigned do log (`CODE_SIGNING_ALLOWED=NO`). Ele empacota `LuccheseStore-unsigned.ipa`, mas não é assinado e não está pronto para instalação em iPhone nem para TestFlight. Para isso, configure certificado e provisioning profile válidos para `com.qingtang.3106` e use um workflow assinado. Se o identificador não pertence à sua equipe Apple, escolha um identificador seu e crie o perfil correspondente. A assinatura iOS exige esses ativos ([guia oficial CodeMagic](https://docs.codemagic.io/yaml-code-signing/signing-ios/)).

O YAML corrige os nomes do projeto/scheme e adiciona diagnóstico para esse erro de verificação. Não garante que não surjam erros de compilação Swift quando o build Xcode começar; este ambiente Linux não pode executar `xcodebuild`.
