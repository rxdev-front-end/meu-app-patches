# CodeMagic — projeto Lucchese Store 3106

O log anexado tentou compilar `ThreeOneOSFive.xcodeproj` com scheme `3105`, mas essa fonte não existe no projeto 3106. O projeto correto é `ThreeOneOSSix.xcodeproj` e o target/scheme compartilhado é `3106`.

## Importação e configuração

Use o ZIP iOS isolado, que coloca `ThreeOneOSSix.xcodeproj` e `codemagic.yaml` na raiz. No CodeMagic, conecte um repositório com os arquivos do projeto no diretório raiz e faça commit de `codemagic.yaml` nesse mesmo nível. O CodeMagic detecta YAML quando o arquivo está na raiz do repositório: https://docs.codemagic.io/yaml-basic-configuration/yaml-getting-started/.

O workflow incluído chama `lucchese-ios-unsigned`. Ele verifica o `.xcodeproj`, lista os schemes, arquiva o scheme `3106` para `generic/platform=iOS` sem assinatura e empacota o artefato como `LuccheseStore-unsigned.ipa`. A API está definida em Debug e Release como `https://lucchese-h5sphw9z.manus.space`.

Se mantiver os arquivos dentro de um repositório maior, ajuste `XCODE_PROJECT` no YAML para o caminho relativo real — por exemplo, `app-ios/3106-main/ThreeOneOSSix.xcodeproj` — e deixe `codemagic.yaml` na raiz desse repositório.

## Limite de assinatura

O YAML segue o modo unsigned do log (`CODE_SIGNING_ALLOWED=NO`). Ele empacota um IPA sem assinatura, útil para validar a compilação ou assinar depois, mas **não é pronto para instalar em iPhone nem enviar ao TestFlight**. Para isso, configure no CodeMagic um certificado e um provisioning profile válidos para `com.qingtang.3106` e use um workflow assinado. Se esse Bundle Identifier não pertence à sua equipe Apple, escolha um identificador seu e crie o perfil correspondente. A assinatura iOS requer esses ativos de assinatura ([guia oficial CodeMagic](https://docs.codemagic.io/yaml-code-signing/signing-ios/)).

Este YAML corrige o erro de caminho/scheme do log; não garante que não surjam outros erros de compilação Swift ou assinatura quando o build realmente começar. Não foi possível compilar com Xcode neste ambiente Linux.
